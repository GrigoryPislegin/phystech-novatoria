# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class VacancyManagementApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def add_vacancy_to_archive(self, employer_id, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Archiving vacancies  # noqa: E501

        Move a vacancy to the archive  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_vacancy_to_archive(employer_id, vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer's ID (required)
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.add_vacancy_to_archive_with_http_info(employer_id, vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.add_vacancy_to_archive_with_http_info(employer_id, vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def add_vacancy_to_archive_with_http_info(self, employer_id, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Archiving vacancies  # noqa: E501

        Move a vacancy to the archive  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_vacancy_to_archive_with_http_info(employer_id, vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer's ID (required)
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method add_vacancy_to_archive" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `add_vacancy_to_archive`")  # noqa: E501
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `add_vacancy_to_archive`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `add_vacancy_to_archive`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/vacancies/archived/{vacancy_id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def add_vacancy_to_hidden(self, employer_id, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting vacancies  # noqa: E501

        You can delete only an archived vacancy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_vacancy_to_hidden(employer_id, vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.add_vacancy_to_hidden_with_http_info(employer_id, vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.add_vacancy_to_hidden_with_http_info(employer_id, vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def add_vacancy_to_hidden_with_http_info(self, employer_id, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting vacancies  # noqa: E501

        You can delete only an archived vacancy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_vacancy_to_hidden_with_http_info(employer_id, vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method add_vacancy_to_hidden" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `add_vacancy_to_hidden`")  # noqa: E501
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `add_vacancy_to_hidden`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `add_vacancy_to_hidden`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/vacancies/hidden/{vacancy_id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def edit_vacancy(self, body, hh_user_agent, vacancy_id, **kwargs):  # noqa: E501
        """Editing vacancies  # noqa: E501

        Changes vacancy fields specified in a request body.  Compound fields (such as `salary`, `contacts`, `professional_roles`) can be edited only as a whole. For example, to edit salary currency, you also have to change the salary value.  `billing_type` and `manager` fields should be sent in separate requests   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.edit_vacancy(body, hh_user_agent, vacancy_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param VacancyEdit body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str vacancy_id: Vacancy ID (required)
        :param bool ignore_duplicates: Ignore [duplicates](https://github.com/hhru/api/blob/master/docs_eng/employer_vacancies.md#edit-ignore-duplicates) after editing the vacancy. Default — `false`
        :param bool ignore_replacement_warning: Ignore replacement error. Default — `true`
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.edit_vacancy_with_http_info(body, hh_user_agent, vacancy_id, **kwargs)  # noqa: E501
        else:
            (data) = self.edit_vacancy_with_http_info(body, hh_user_agent, vacancy_id, **kwargs)  # noqa: E501
            return data

    def edit_vacancy_with_http_info(self, body, hh_user_agent, vacancy_id, **kwargs):  # noqa: E501
        """Editing vacancies  # noqa: E501

        Changes vacancy fields specified in a request body.  Compound fields (such as `salary`, `contacts`, `professional_roles`) can be edited only as a whole. For example, to edit salary currency, you also have to change the salary value.  `billing_type` and `manager` fields should be sent in separate requests   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.edit_vacancy_with_http_info(body, hh_user_agent, vacancy_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param VacancyEdit body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str vacancy_id: Vacancy ID (required)
        :param bool ignore_duplicates: Ignore [duplicates](https://github.com/hhru/api/blob/master/docs_eng/employer_vacancies.md#edit-ignore-duplicates) after editing the vacancy. Default — `false`
        :param bool ignore_replacement_warning: Ignore replacement error. Default — `true`
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'hh_user_agent', 'vacancy_id', 'ignore_duplicates', 'ignore_replacement_warning', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method edit_vacancy" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `edit_vacancy`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `edit_vacancy`")  # noqa: E501
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `edit_vacancy`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'ignore_duplicates' in params:
            query_params.append(('ignore_duplicates', params['ignore_duplicates']))  # noqa: E501
        if 'ignore_replacement_warning' in params:
            query_params.append(('ignore_replacement_warning', params['ignore_replacement_warning']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_active_vacancy_list(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """View a published vacancy list  # noqa: E501

        Returns a list of published vacancies.  If the `resume_id` parameter is specified, the returned list contains only those vacancies that match the specified resume. Also, the response contains additional fields   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_active_vacancy_list(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counted from 0, by default — 0)
        :param float per_page: Number of items per page (by default — 20, maximum — 50)
        :param str manager_id: Manager ID which vacancies will be obtained in response. By default, the system returns vacancies from the current user.  If you pass several `manager_id` parameters, only the last one will be used. To obtain manager IDs, use [the method](#tag/Employer-managers/operation/get-employer-managers) 
        :param str text: String for searching by vacancy name
        :param str area: ID of the region with vacancies. To obtain region IDs with active vacancies, use [the method](#tag/Employer-info/operation/get-employer-vacancy-areas)
        :param str resume_id: Resume ID. If the parameter is specified, the response contains only vacancies that match the corresponding resume. Also, additional fields are returned
        :param str order_by: Sorting of vacancies. Possible values are listed in the `employer_active_vacancies_order` field of the [dictionary](#tag/Public-directories/operation/get-dictionaries)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_active_vacancy_list_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_active_vacancy_list_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_active_vacancy_list_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """View a published vacancy list  # noqa: E501

        Returns a list of published vacancies.  If the `resume_id` parameter is specified, the returned list contains only those vacancies that match the specified resume. Also, the response contains additional fields   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_active_vacancy_list_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counted from 0, by default — 0)
        :param float per_page: Number of items per page (by default — 20, maximum — 50)
        :param str manager_id: Manager ID which vacancies will be obtained in response. By default, the system returns vacancies from the current user.  If you pass several `manager_id` parameters, only the last one will be used. To obtain manager IDs, use [the method](#tag/Employer-managers/operation/get-employer-managers) 
        :param str text: String for searching by vacancy name
        :param str area: ID of the region with vacancies. To obtain region IDs with active vacancies, use [the method](#tag/Employer-info/operation/get-employer-vacancy-areas)
        :param str resume_id: Resume ID. If the parameter is specified, the response contains only vacancies that match the corresponding resume. Also, additional fields are returned
        :param str order_by: Sorting of vacancies. Possible values are listed in the `employer_active_vacancies_order` field of the [dictionary](#tag/Public-directories/operation/get-dictionaries)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'page', 'per_page', 'manager_id', 'text', 'area', 'resume_id', 'order_by', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_active_vacancy_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_active_vacancy_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_active_vacancy_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'manager_id' in params:
            query_params.append(('manager_id', params['manager_id']))  # noqa: E501
        if 'text' in params:
            query_params.append(('text', params['text']))  # noqa: E501
        if 'area' in params:
            query_params.append(('area', params['area']))  # noqa: E501
        if 'resume_id' in params:
            query_params.append(('resume_id', params['resume_id']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/vacancies/active', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVacancyListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_archived_vacancies(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Archived vacancy list  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_archived_vacancies(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer's ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers). Specify it if you need vacancies from another manager.  If you pass several `manager_id` parameters, only the last one is used.  By default, the system returns vacancies from the current user 
        :param str order_by: Vacancy list sorting. Directory with possible values: `employer_archived_vacancies_order` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries) 
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). The maximum and default value is 1000 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from 0 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesArchivedVacancyListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_archived_vacancies_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_archived_vacancies_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_archived_vacancies_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Archived vacancy list  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_archived_vacancies_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer's ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers). Specify it if you need vacancies from another manager.  If you pass several `manager_id` parameters, only the last one is used.  By default, the system returns vacancies from the current user 
        :param str order_by: Vacancy list sorting. Directory with possible values: `employer_archived_vacancies_order` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries) 
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). The maximum and default value is 1000 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from 0 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesArchivedVacancyListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'manager_id', 'order_by', 'per_page', 'page', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_archived_vacancies" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_archived_vacancies`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_archived_vacancies`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'manager_id' in params:
            query_params.append(('manager_id', params['manager_id']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/vacancies/archived', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesArchivedVacancyListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_hidden_vacancies(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleted vacancy list  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_hidden_vacancies(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer's ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str manager_id: Manager's ID. Specify it if you need vacancies from another manager. If you pass several `manager_id` parameters, only the last one is used. By default, the system returns vacancies from the current user 
        :param str order_by: Vacancy list sorting. Directory with possible values: `employer_archived_vacancies_order` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries) 
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). The maximum and default value is 1000 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from 0 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesDeletedVacancyListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_hidden_vacancies_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_hidden_vacancies_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_hidden_vacancies_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleted vacancy list  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_hidden_vacancies_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer's ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str manager_id: Manager's ID. Specify it if you need vacancies from another manager. If you pass several `manager_id` parameters, only the last one is used. By default, the system returns vacancies from the current user 
        :param str order_by: Vacancy list sorting. Directory with possible values: `employer_archived_vacancies_order` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries) 
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). The maximum and default value is 1000 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from 0 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesDeletedVacancyListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'manager_id', 'order_by', 'per_page', 'page', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_hidden_vacancies" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_hidden_vacancies`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_hidden_vacancies`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'manager_id' in params:
            query_params.append(('manager_id', params['manager_id']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/vacancies/hidden', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesDeletedVacancyListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_prolongation_vacancy_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Information about vacancy prolongation possibility  # noqa: E501

        Rules of prolongation:      * The cost of vacancy prolongation is the same as of publishing a new vacancy.     * Standard vacancies can be prolonged if it has been at least 1 minute since the last prolongation.     * \"Standard Plus\" vacancies can be prolonged at least 7 days before the end of publication   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_prolongation_vacancy_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: ID of the vacancy (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyProlongate
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_prolongation_vacancy_info_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_prolongation_vacancy_info_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_prolongation_vacancy_info_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Information about vacancy prolongation possibility  # noqa: E501

        Rules of prolongation:      * The cost of vacancy prolongation is the same as of publishing a new vacancy.     * Standard vacancies can be prolonged if it has been at least 1 minute since the last prolongation.     * \"Standard Plus\" vacancies can be prolonged at least 7 days before the end of publication   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_prolongation_vacancy_info_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: ID of the vacancy (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyProlongate
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_prolongation_vacancy_info" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `get_prolongation_vacancy_info`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_prolongation_vacancy_info`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}/prolongate', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVacancyProlongate',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_vacancy(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """View a vacancy  # noqa: E501

        Returns detailed information for the specified vacancy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancy
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_vacancy_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_vacancy_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_vacancy_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """View a vacancy  # noqa: E501

        Returns detailed information for the specified vacancy  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancy
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_vacancy" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `get_vacancy`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_vacancy`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVacancy',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_vacancy_conditions(self, hh_user_agent, **kwargs):  # noqa: E501
        """Conditions for filling out fields when publishing and editing vacancies  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_conditions(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyConditions
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_vacancy_conditions_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_vacancy_conditions_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_vacancy_conditions_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Conditions for filling out fields when publishing and editing vacancies  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_conditions_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyConditions
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_vacancy_conditions" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_vacancy_conditions`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancy_conditions', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVacancyConditions',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_vacancy_stats(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Vacancy statistics  # noqa: E501

        Returns statistics for the last five days of the vacancy life.  Notes:  * If the vacancy is created less than five days ago, then the first date in the response is the vacancy creation date. For future dates the `responses` and `views` fields are `null`. * If the vacancy is archived or deleted, the archiving date is the last   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_stats(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyStatsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_vacancy_stats_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_vacancy_stats_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_vacancy_stats_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Vacancy statistics  # noqa: E501

        Returns statistics for the last five days of the vacancy life.  Notes:  * If the vacancy is created less than five days ago, then the first date in the response is the vacancy creation date. For future dates the `responses` and `views` fields are `null`. * If the vacancy is archived or deleted, the archiving date is the last   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_stats_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyStatsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_vacancy_stats" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `get_vacancy_stats`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_vacancy_stats`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}/stats', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVacancyStatsResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_vacancy_upgrade_list(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """List of vacancy upgrades  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_upgrade_list(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyUpgradeListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_vacancy_upgrade_list_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_vacancy_upgrade_list_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_vacancy_upgrade_list_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """List of vacancy upgrades  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_upgrade_list_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVacancyUpgradeListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_vacancy_upgrade_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `get_vacancy_upgrade_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_vacancy_upgrade_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}/upgrades', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVacancyUpgradeListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_vacancy_visitors(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Vacancy visitors  # noqa: E501

        Returns a list of short resumes of users who viewed the vacancy in the last week. List sorted by viewing date descending. If the user has multiple resumes, then a resume with the latest update date is returned.  If the applicant has deleted a resume or has hidden it from the employer, these resumes will be omitted from the `items` list. But they will be taken into account during pagination (`per_page`) and in the number of resumes found (`found`). The `hidden_on_page` field indicates the number of such omitted resumes per page   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_visitors(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (from 0)
        :param float per_page: Number of elements per page
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVisitorsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_vacancy_visitors_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_vacancy_visitors_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_vacancy_visitors_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Vacancy visitors  # noqa: E501

        Returns a list of short resumes of users who viewed the vacancy in the last week. List sorted by viewing date descending. If the user has multiple resumes, then a resume with the latest update date is returned.  If the applicant has deleted a resume or has hidden it from the employer, these resumes will be omitted from the `items` list. But they will be taken into account during pagination (`per_page`) and in the number of resumes found (`found`). The `hidden_on_page` field indicates the number of such omitted resumes per page   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_vacancy_visitors_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (from 0)
        :param float per_page: Number of elements per page
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesVisitorsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'page', 'per_page', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_vacancy_visitors" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `get_vacancy_visitors`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_vacancy_visitors`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}/visitors', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesVisitorsResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def publish_vacancy(self, body, hh_user_agent, **kwargs):  # noqa: E501
        """Publishing job vacancies  # noqa: E501

        Creates a new vacancy with fields specified in the request body.  According to the [Federal Law of the Russian Federation No. 1032-1 dated April 19, 1991, as revised on July 2, 2013](https://hh.ru/article/13967) it is prohibited to place information restricting rights or providing advantages to certain candidates according to their gender, age, family status, and other qualities unrelated to their professional aptitudes.  Notes:  * In case of a successful publication the cost of corresponding services will be withdrawn. * All job vacancies are subject to manual moderation. * Within a few minutes after publication, the vacancy becomes visible in search results.  Useful links:  * [Conditions of publishing vacancies](https://hh.ru/article/341) * [How to write a good vacancy description](https://hh.ru/article/16239)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.publish_vacancy(body, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param VacancyCreate body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool ignore_duplicates: Force adding duplicate
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: IncludesId
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.publish_vacancy_with_http_info(body, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.publish_vacancy_with_http_info(body, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def publish_vacancy_with_http_info(self, body, hh_user_agent, **kwargs):  # noqa: E501
        """Publishing job vacancies  # noqa: E501

        Creates a new vacancy with fields specified in the request body.  According to the [Federal Law of the Russian Federation No. 1032-1 dated April 19, 1991, as revised on July 2, 2013](https://hh.ru/article/13967) it is prohibited to place information restricting rights or providing advantages to certain candidates according to their gender, age, family status, and other qualities unrelated to their professional aptitudes.  Notes:  * In case of a successful publication the cost of corresponding services will be withdrawn. * All job vacancies are subject to manual moderation. * Within a few minutes after publication, the vacancy becomes visible in search results.  Useful links:  * [Conditions of publishing vacancies](https://hh.ru/article/341) * [How to write a good vacancy description](https://hh.ru/article/16239)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.publish_vacancy_with_http_info(body, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param VacancyCreate body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool ignore_duplicates: Force adding duplicate
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: IncludesId
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'hh_user_agent', 'ignore_duplicates', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method publish_vacancy" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `publish_vacancy`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `publish_vacancy`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'ignore_duplicates' in params:
            query_params.append(('ignore_duplicates', params['ignore_duplicates']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='IncludesId',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def restore_vacancy_from_hidden(self, employer_id, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Restoring deleted vacancies  # noqa: E501

        You can restore only a vacancy deleted from the archive. Vacancy returns into the archive  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.restore_vacancy_from_hidden(employer_id, vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.restore_vacancy_from_hidden_with_http_info(employer_id, vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.restore_vacancy_from_hidden_with_http_info(employer_id, vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def restore_vacancy_from_hidden_with_http_info(self, employer_id, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Restoring deleted vacancies  # noqa: E501

        You can restore only a vacancy deleted from the archive. Vacancy returns into the archive  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.restore_vacancy_from_hidden_with_http_info(employer_id, vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method restore_vacancy_from_hidden" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `restore_vacancy_from_hidden`")  # noqa: E501
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `restore_vacancy_from_hidden`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `restore_vacancy_from_hidden`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/vacancies/hidden/{vacancy_id}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def vacancy_prolongation(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Vacancy prolongation  # noqa: E501

        Prolongs the vacancy period.  Rules of prolongation:  * The cost of vacancy prolongation is the same as of publishing a new vacancy. * Standard vacancies can be prolonged if it has been at least 1 minute since the last prolongation. * \"Standard Plus\" vacancies can be prolonged at least 7 days before the end of publication   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.vacancy_prolongation(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: ID of the vacancy (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.vacancy_prolongation_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.vacancy_prolongation_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def vacancy_prolongation_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Vacancy prolongation  # noqa: E501

        Prolongs the vacancy period.  Rules of prolongation:  * The cost of vacancy prolongation is the same as of publishing a new vacancy. * Standard vacancies can be prolonged if it has been at least 1 minute since the last prolongation. * \"Standard Plus\" vacancies can be prolonged at least 7 days before the end of publication   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.vacancy_prolongation_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: ID of the vacancy (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method vacancy_prolongation" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `vacancy_prolongation`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `vacancy_prolongation`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'vacancy_id' in params:
            path_params['vacancy_id'] = params['vacancy_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{vacancy_id}/prolongate', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
