# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class SavedVacancySearchesApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def create_saved_vacancy_search(self, hh_user_agent, **kwargs):  # noqa: E501
        """Creating new saved vacancy search  # noqa: E501

        Some parameters take multiple values: `key=value&key=value`.  When indicating paging parameters (`page`, `per_page`), a restriction takes effect: the number of results returned can not exceed `2000`. For instance, a request `per_page=10&page=199` (displaying vacancies from `1991` to `2000`) is possible, but a request with `per_page=10&page=200` returns an error (displaying vacancies from `2001` to `2010`)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.create_saved_vacancy_search(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counts from 0, by default — 0)
        :param float per_page: Number of elements (by default — 10, maximum value — 100)
        :param str text: Text field. The sent value is searched in the vacancy fields specified in the search_field parameter.  As with the main website, a query language is available: https://hh.ru/article/1175. There is [autosuggest](#tag/Suggestions/operation/get-vacancy-search-keywords) especially for this field 
        :param str name: Name of the new autosearch
        :param str search_field: An area of search. Directory with possible values: `vacancy_search_fields` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). By default, all fields are used. Several values can be indicated 
        :param str experience: Work experience. Directory with possible values: `experience` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param str employment: Employment type. Directory with possible values: `employment` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param str schedule: Work schedule. Directory with possible values: `schedule` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param str area: A region. Directory with possible values: [/areas](#tag/Public-directories/operation/get-areas). Several values can be indicated 
        :param str metro: A metro line or station. Directory with possible values: [/metro](#tag/Public-directories/operation/get-metro-stations). Several values can be indicated 
        :param str professional_role: A professional role. Directory with possible values: [professional_roles](#tag/Public-directories/operation/get-professional-roles-dictionary). Several values can be indicated. Will replace specializations (parameter `specialization`) 
        :param str industry: An industry of the company that posted the vacancy. Directory with possible values: [/industries](#tag/Public-directories/operation/get-industries). Several values can be indicated 
        :param str employer_id: A [company](#tag/Employer) identifier. Several values can be indicated 
        :param str currency: A currency code. Directory with possible values: `currency` (code key) in [/dictionaries](#tag/Public-directories/operation/get-dictionaries) 
        :param float salary: A salary rate. If this field is indicated, but currency is not, then the RUR value is used for currency 
        :param str label: Filter by vacancy labels. Directory with possible values: `vacancy_label` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param bool only_with_salary: Show only the vacancies with salary specified. Possible values: `true`or `false`. By default, `false` is used 
        :param float period: A range of days within which vacancies will be found. Maximal value: 30 
        :param str date_from: A start date which restricts the date range of vacancy posting. You can not indicate it with the period parameter.  The value is indicated in the ISO 8601 format — `YYYY-MM-DD` or with up-to-the-second precision `YYYY-MM-DDThh:mm:ss±hhmm`. The shown value will be rounded down to the nearest five minutes 
        :param str date_to: An end date which restricts the date range of vacancy posting. You must give it only with the date_from parameter. You can not indicate it with the period parameter.  The value is indicated in the ISO 8601 format — YYYY-MM-DD or with accuracy in seconds `YYYY-MM-DDThh:mm:ss±hhmm`. The shown value will be rounded down to the nearest five minutes 
        :param float top_lat: Top latitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param float bottom_lat: Bottom latitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param float left_lng: Left longitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param float right_lng: Right longitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param str order_by: Vacancy list sorting. Directory with possible values: `vacancy_search_order` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries).   If the sorting by distance from a geo-point is selected, the coordinates of the geo-point must be set: `sort_point_lat`, `sort_point_lng` 
        :param float sort_point_lat: The value of geographic latitude of the point that is used to sort vacancies by distance. It must be indicated only in case when `order_by` is set to `distance` 
        :param float sort_point_lng: The value of geographic longitude of the point that is used to sort vacancies by distance. It must be indicated only in case when `order_by` is set to `distance` 
        :param bool clusters: Whether the [clusters for this search](#tag/Vacancy-search/Clusters-of-vacancy-search) are returned. Default: `false` 
        :param bool describe_arguments: Whether the description of the used search parameters is returned. Success response contains `arguments` [field](#tag/Vacancy-search/operation/get-vacancies). Default: `false` 
        :param bool no_magic: If true — turn off automatic vacancy transformation. Default — `false`.  If automatic transformation is enabled, an attempt will be made to change the user's text query to a set of parameters. For example, a query `text=moscow accountant 100500` will be transformed to `text=accountant&only_with_salary=true&area=1&salary=100500` 
        :param bool premium: If `true`, the results of vacancies take premium vacancies into account. This type of sorting is used on the website. Default — false 
        :param bool responses_count_enabled: If true – include optional field counters with responses on a vacancy. Default – false 
        :param bool part_time: Vacancies for part times job. Possible values:  * All elements from `working_days` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * All elements from `working_time_intervals` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * All elements from `working_time_modes` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * Elements `part` or `project` from `employment` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * Element `accept_temporary` that show only the vacancies with accept temporary employment  Several values can be indicated 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: str
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.create_saved_vacancy_search_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.create_saved_vacancy_search_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def create_saved_vacancy_search_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Creating new saved vacancy search  # noqa: E501

        Some parameters take multiple values: `key=value&key=value`.  When indicating paging parameters (`page`, `per_page`), a restriction takes effect: the number of results returned can not exceed `2000`. For instance, a request `per_page=10&page=199` (displaying vacancies from `1991` to `2000`) is possible, but a request with `per_page=10&page=200` returns an error (displaying vacancies from `2001` to `2010`)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.create_saved_vacancy_search_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counts from 0, by default — 0)
        :param float per_page: Number of elements (by default — 10, maximum value — 100)
        :param str text: Text field. The sent value is searched in the vacancy fields specified in the search_field parameter.  As with the main website, a query language is available: https://hh.ru/article/1175. There is [autosuggest](#tag/Suggestions/operation/get-vacancy-search-keywords) especially for this field 
        :param str name: Name of the new autosearch
        :param str search_field: An area of search. Directory with possible values: `vacancy_search_fields` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). By default, all fields are used. Several values can be indicated 
        :param str experience: Work experience. Directory with possible values: `experience` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param str employment: Employment type. Directory with possible values: `employment` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param str schedule: Work schedule. Directory with possible values: `schedule` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param str area: A region. Directory with possible values: [/areas](#tag/Public-directories/operation/get-areas). Several values can be indicated 
        :param str metro: A metro line or station. Directory with possible values: [/metro](#tag/Public-directories/operation/get-metro-stations). Several values can be indicated 
        :param str professional_role: A professional role. Directory with possible values: [professional_roles](#tag/Public-directories/operation/get-professional-roles-dictionary). Several values can be indicated. Will replace specializations (parameter `specialization`) 
        :param str industry: An industry of the company that posted the vacancy. Directory with possible values: [/industries](#tag/Public-directories/operation/get-industries). Several values can be indicated 
        :param str employer_id: A [company](#tag/Employer) identifier. Several values can be indicated 
        :param str currency: A currency code. Directory with possible values: `currency` (code key) in [/dictionaries](#tag/Public-directories/operation/get-dictionaries) 
        :param float salary: A salary rate. If this field is indicated, but currency is not, then the RUR value is used for currency 
        :param str label: Filter by vacancy labels. Directory with possible values: `vacancy_label` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries). Several values can be indicated 
        :param bool only_with_salary: Show only the vacancies with salary specified. Possible values: `true`or `false`. By default, `false` is used 
        :param float period: A range of days within which vacancies will be found. Maximal value: 30 
        :param str date_from: A start date which restricts the date range of vacancy posting. You can not indicate it with the period parameter.  The value is indicated in the ISO 8601 format — `YYYY-MM-DD` or with up-to-the-second precision `YYYY-MM-DDThh:mm:ss±hhmm`. The shown value will be rounded down to the nearest five minutes 
        :param str date_to: An end date which restricts the date range of vacancy posting. You must give it only with the date_from parameter. You can not indicate it with the period parameter.  The value is indicated in the ISO 8601 format — YYYY-MM-DD or with accuracy in seconds `YYYY-MM-DDThh:mm:ss±hhmm`. The shown value will be rounded down to the nearest five minutes 
        :param float top_lat: Top latitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param float bottom_lat: Bottom latitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param float left_lng: Left longitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param float right_lng: Right longitude boundary.  When searching, the value of the address indicated in the vacancy is used. The acceptable value is decimal degrees.  All the four parameters of geographic coordinates must be given simultaneously, otherwise an error will be returned 
        :param str order_by: Vacancy list sorting. Directory with possible values: `vacancy_search_order` in [/dictionaries](#tag/Public-directories/operation/get-dictionaries).   If the sorting by distance from a geo-point is selected, the coordinates of the geo-point must be set: `sort_point_lat`, `sort_point_lng` 
        :param float sort_point_lat: The value of geographic latitude of the point that is used to sort vacancies by distance. It must be indicated only in case when `order_by` is set to `distance` 
        :param float sort_point_lng: The value of geographic longitude of the point that is used to sort vacancies by distance. It must be indicated only in case when `order_by` is set to `distance` 
        :param bool clusters: Whether the [clusters for this search](#tag/Vacancy-search/Clusters-of-vacancy-search) are returned. Default: `false` 
        :param bool describe_arguments: Whether the description of the used search parameters is returned. Success response contains `arguments` [field](#tag/Vacancy-search/operation/get-vacancies). Default: `false` 
        :param bool no_magic: If true — turn off automatic vacancy transformation. Default — `false`.  If automatic transformation is enabled, an attempt will be made to change the user's text query to a set of parameters. For example, a query `text=moscow accountant 100500` will be transformed to `text=accountant&only_with_salary=true&area=1&salary=100500` 
        :param bool premium: If `true`, the results of vacancies take premium vacancies into account. This type of sorting is used on the website. Default — false 
        :param bool responses_count_enabled: If true – include optional field counters with responses on a vacancy. Default – false 
        :param bool part_time: Vacancies for part times job. Possible values:  * All elements from `working_days` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * All elements from `working_time_intervals` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * All elements from `working_time_modes` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * Elements `part` or `project` from `employment` in [/dictionaries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-dictionaries). * Element `accept_temporary` that show only the vacancies with accept temporary employment  Several values can be indicated 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: str
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'page', 'per_page', 'text', 'name', 'search_field', 'experience', 'employment', 'schedule', 'area', 'metro', 'professional_role', 'industry', 'employer_id', 'currency', 'salary', 'label', 'only_with_salary', 'period', 'date_from', 'date_to', 'top_lat', 'bottom_lat', 'left_lng', 'right_lng', 'order_by', 'sort_point_lat', 'sort_point_lng', 'clusters', 'describe_arguments', 'no_magic', 'premium', 'responses_count_enabled', 'part_time', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method create_saved_vacancy_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `create_saved_vacancy_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'text' in params:
            query_params.append(('text', params['text']))  # noqa: E501
        if 'name' in params:
            query_params.append(('name', params['name']))  # noqa: E501
        if 'search_field' in params:
            query_params.append(('search_field', params['search_field']))  # noqa: E501
        if 'experience' in params:
            query_params.append(('experience', params['experience']))  # noqa: E501
        if 'employment' in params:
            query_params.append(('employment', params['employment']))  # noqa: E501
        if 'schedule' in params:
            query_params.append(('schedule', params['schedule']))  # noqa: E501
        if 'area' in params:
            query_params.append(('area', params['area']))  # noqa: E501
        if 'metro' in params:
            query_params.append(('metro', params['metro']))  # noqa: E501
        if 'professional_role' in params:
            query_params.append(('professional_role', params['professional_role']))  # noqa: E501
        if 'industry' in params:
            query_params.append(('industry', params['industry']))  # noqa: E501
        if 'employer_id' in params:
            query_params.append(('employer_id', params['employer_id']))  # noqa: E501
        if 'currency' in params:
            query_params.append(('currency', params['currency']))  # noqa: E501
        if 'salary' in params:
            query_params.append(('salary', params['salary']))  # noqa: E501
        if 'label' in params:
            query_params.append(('label', params['label']))  # noqa: E501
        if 'only_with_salary' in params:
            query_params.append(('only_with_salary', params['only_with_salary']))  # noqa: E501
        if 'period' in params:
            query_params.append(('period', params['period']))  # noqa: E501
        if 'date_from' in params:
            query_params.append(('date_from', params['date_from']))  # noqa: E501
        if 'date_to' in params:
            query_params.append(('date_to', params['date_to']))  # noqa: E501
        if 'top_lat' in params:
            query_params.append(('top_lat', params['top_lat']))  # noqa: E501
        if 'bottom_lat' in params:
            query_params.append(('bottom_lat', params['bottom_lat']))  # noqa: E501
        if 'left_lng' in params:
            query_params.append(('left_lng', params['left_lng']))  # noqa: E501
        if 'right_lng' in params:
            query_params.append(('right_lng', params['right_lng']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'sort_point_lat' in params:
            query_params.append(('sort_point_lat', params['sort_point_lat']))  # noqa: E501
        if 'sort_point_lng' in params:
            query_params.append(('sort_point_lng', params['sort_point_lng']))  # noqa: E501
        if 'clusters' in params:
            query_params.append(('clusters', params['clusters']))  # noqa: E501
        if 'describe_arguments' in params:
            query_params.append(('describe_arguments', params['describe_arguments']))  # noqa: E501
        if 'no_magic' in params:
            query_params.append(('no_magic', params['no_magic']))  # noqa: E501
        if 'premium' in params:
            query_params.append(('premium', params['premium']))  # noqa: E501
        if 'responses_count_enabled' in params:
            query_params.append(('responses_count_enabled', params['responses_count_enabled']))  # noqa: E501
        if 'part_time' in params:
            query_params.append(('part_time', params['part_time']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['text/html', 'application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/vacancies', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='str',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def delete_saved_vacancy_search(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting saved vacancy search  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_saved_vacancy_search(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved vacancy search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.delete_saved_vacancy_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.delete_saved_vacancy_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def delete_saved_vacancy_search_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting saved vacancy search  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_saved_vacancy_search_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved vacancy search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method delete_saved_vacancy_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `delete_saved_vacancy_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `delete_saved_vacancy_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/vacancies/{id}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_saved_vacancy_search(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Obtaining single saved vacancy search  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_vacancy_search(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved vacancy search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchItem
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_saved_vacancy_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_saved_vacancy_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_saved_vacancy_search_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Obtaining single saved vacancy search  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_vacancy_search_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved vacancy search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchItem
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_saved_vacancy_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `get_saved_vacancy_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_saved_vacancy_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/vacancies/{id}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='SavedSearchesSavedSearchItem',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_saved_vacancy_searches(self, hh_user_agent, **kwargs):  # noqa: E501
        """List of saved vacancy searches  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_vacancy_searches(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counted from 0, by default 0)
        :param float per_page: Number of items (by default 10, max value 10)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_saved_vacancy_searches_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_saved_vacancy_searches_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_saved_vacancy_searches_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """List of saved vacancy searches  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_vacancy_searches_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counted from 0, by default 0)
        :param float per_page: Number of items (by default 10, max value 10)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'page', 'per_page', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_saved_vacancy_searches" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_saved_vacancy_searches`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/vacancies', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='SavedSearchesSavedSearchResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def update_saved_vacancy_search(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Updating saved vacancy search  # noqa: E501

        You can change subscription name (`name`) and status (`subscription`) for saved search. Only one parameter can be changed at a time  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.update_saved_vacancy_search(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved vacancy search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str name: New name for the saved search
        :param bool subscription: Subscription status
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.update_saved_vacancy_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.update_saved_vacancy_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def update_saved_vacancy_search_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Updating saved vacancy search  # noqa: E501

        You can change subscription name (`name`) and status (`subscription`) for saved search. Only one parameter can be changed at a time  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.update_saved_vacancy_search_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved vacancy search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str name: New name for the saved search
        :param bool subscription: Subscription status
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'name', 'subscription', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method update_saved_vacancy_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `update_saved_vacancy_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `update_saved_vacancy_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'name' in params:
            query_params.append(('name', params['name']))  # noqa: E501
        if 'subscription' in params:
            query_params.append(('subscription', params['subscription']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/vacancies/{id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
