# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class SavedResumeSearchesApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def create_saved_resume_search(self, hh_user_agent, **kwargs):  # noqa: E501
        """Creating new saved resumes search  # noqa: E501

        Some parameters take multiple values: `key=value&key=value`.  When specifying paging parameters (`page`, `per_page`), a restriction takes effect: the number of results returned cannot exceed `2000`. For instance, a request `per_page=10&page=199` (displaying resume from `1991` to `2000`) is possible, but a request with `per_page=10&page=200` returns an error (displaying resume from `2001` to `2010`)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.create_saved_resume_search(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str text: Search phrase. Finds resumes that have all the words from the set phrase.  Features:  * Several values can be specified. Each additional `text` refines the search.  * You can use [search query language](http://hh.ru/article.xml?articleId=1175) as a search phrase.  * There is special [autocompletion](#tag/Suggestions/operation/get-resume-search-keywords-suggests) for the field. * To tune the phrase settings, you can use the following parameters: `text.logic`, `text.field`, `text.period`. When using extra `text.*` fields, you must specify the whole set (trine) of parameters 
        :param str text_logic: Describes how the search works. Possible values are listed in the `resume_search_logic` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str text_field: Describes where words from the `text` search phrase should be found.  In the `text.field` parameter you can specify several values separated by commas, e.g. `?text.field=education,keywords`. Possible values are listed in the `resume_search_fields` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str text_period: A period for searching in work experience.  The parameter works only when `text.field` equals one of: `experience`, `experience_company`, `experience_position`, `experience_description` parameters, but it must always be specified when you specify other `text.*` parameters. If parameter does not work, it's value can be empty 
        :param float age_from: Minimum applicant's age in years.  Note that the search results will include resumes with unspecified age by default. To see resumes with specified age only, specify `only_with_age` value for the `label` parameter 
        :param float age_to: Maximum applicant's age in years.  Note that the search results will include resumes with unspecified age by default. To see resumes with specified age only, specify `only_with_age` value for the `label` parameter 
        :param str area: Region. Possible values are listed in the [region directory](#tag/Public-directories/operation/get-areas).  You can specify several values. Resumes of applicants from specified regions or those who ready to move to such regions are selected by default. Enter field `relocation` to change this behavior 
        :param str relocation: Willingness to relocate. Possible values are listed in the `resume_search_relocation` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You should specify it only with area parameter 
        :param float period: The search is performed only for resumes published in the given time period (in days). If not specified, the search is performed without any restrictions on the publication date 
        :param str date_from: The date the search should start from.  The value is specified in the [ISO 8601](#date-format) format — `YYYY-MM-DD` or with up-to-the-second precision `YYYY-MM-DDThh:mm:ss±hhmm`. You can not specify it with the `period` parameter 
        :param str date_to: A date until which the search should be performed.  The value is specified in the [ISO 8601](#date-format) format — `YYYY-MM-DD` or with up-to-the-second precision `YYYY-MM-DDThh:mm:ss±hhmm`. You can specify it only with the `date_from` parameter. You can not specify it with the `period` parameter 
        :param str education_level: A level of education. Possible values are listed in the `education_level` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). If not specified, the search is performed without any restrictions on the education level 
        :param str employment: Employment type. Possible values are listed in the `employment` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You can specify several values 
        :param str experience: Work experience. Possible values are listed in the `experience` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str skill: Key skills. At least one key skill identifier should be specified. You can get values from the `id` field in the [key skills suggestion](#tag/Suggestions/operation/get-skill-set-suggests) 
        :param str gender: A gender. Possible values are listed in the `gender` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str label: An extra filter. Possible values are listed in the `resume_search_label` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You can specify several values 
        :param str language: Knowledge of language. You can specify several values. It is set in the format `language.level`, where:  * `language` — value from the [/languages](#tag/Public-directories/operation/get-languages) directory; * `level` — value of the language_level field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries)  Example: `ita.c2` 
        :param str metro: A metro line or station. Possible values are listed in the [/metro](#tag/Public-directories/operation/get-metro-stations) directory 
        :param str currency: A currency code. Possible values are listed in the `currency.code` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param float salary_from: Minimum desired salary range 
        :param float salary_to: Maximum desired salary range 
        :param str schedule: Work schedule. Possible values are listed in the `schedule` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You can specify several values 
        :param str order_by: Resume list sorting. Possible values are listed in the `resume_search_order` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str citizenship: The country of applicant's citizenship. Possible values are listed in the [directory of countries](#tag/Public-directories/operation/get-countries). Several values can be specified 
        :param str work_ticket: A country which the applicant is permitted to work in. You can find possible values in the [directory of countries](#tag/Public-directories/operation/get-countries). Several values can be specified 
        :param str educational_institution: The applicant's educational institutions. Suggestions on university names are used as parameters: [/suggests/educational_institutions](#tag/Suggestions/operation/get-educational-institutions-suggests). Several values can be specified 
        :param bool search_in_responses: If `true`, the search is performed only by resumes that applicants used to response the employer's vacancies. If `false` — the search is carried out by all resumes. By default — `false` 
        :param bool by_text_prefix: If `true`, the search is performed by prefix. For every `text` parameter the search results are not only exact matchings but also words that begin with `text`. Default — `false` 
        :param str driver_license_types: Driver license types. Possible values are listed in the `driver_license_types` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str vacancy_id: Vacancy ID for searching similar resumes. You should specify ID of active or archived employer's vacancy 
        :param float page: Page number (counts from 0, default — 0)
        :param float per_page: Number of elements (default — 10, maximum value — 50)
        :param str professional_role: Professional role. Possible values are listed in the [professional role directory](#tag/Public-directories/operation/get-professional-roles-dictionary). Several values can be specified 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: str
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.create_saved_resume_search_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.create_saved_resume_search_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def create_saved_resume_search_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Creating new saved resumes search  # noqa: E501

        Some parameters take multiple values: `key=value&key=value`.  When specifying paging parameters (`page`, `per_page`), a restriction takes effect: the number of results returned cannot exceed `2000`. For instance, a request `per_page=10&page=199` (displaying resume from `1991` to `2000`) is possible, but a request with `per_page=10&page=200` returns an error (displaying resume from `2001` to `2010`)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.create_saved_resume_search_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str text: Search phrase. Finds resumes that have all the words from the set phrase.  Features:  * Several values can be specified. Each additional `text` refines the search.  * You can use [search query language](http://hh.ru/article.xml?articleId=1175) as a search phrase.  * There is special [autocompletion](#tag/Suggestions/operation/get-resume-search-keywords-suggests) for the field. * To tune the phrase settings, you can use the following parameters: `text.logic`, `text.field`, `text.period`. When using extra `text.*` fields, you must specify the whole set (trine) of parameters 
        :param str text_logic: Describes how the search works. Possible values are listed in the `resume_search_logic` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str text_field: Describes where words from the `text` search phrase should be found.  In the `text.field` parameter you can specify several values separated by commas, e.g. `?text.field=education,keywords`. Possible values are listed in the `resume_search_fields` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str text_period: A period for searching in work experience.  The parameter works only when `text.field` equals one of: `experience`, `experience_company`, `experience_position`, `experience_description` parameters, but it must always be specified when you specify other `text.*` parameters. If parameter does not work, it's value can be empty 
        :param float age_from: Minimum applicant's age in years.  Note that the search results will include resumes with unspecified age by default. To see resumes with specified age only, specify `only_with_age` value for the `label` parameter 
        :param float age_to: Maximum applicant's age in years.  Note that the search results will include resumes with unspecified age by default. To see resumes with specified age only, specify `only_with_age` value for the `label` parameter 
        :param str area: Region. Possible values are listed in the [region directory](#tag/Public-directories/operation/get-areas).  You can specify several values. Resumes of applicants from specified regions or those who ready to move to such regions are selected by default. Enter field `relocation` to change this behavior 
        :param str relocation: Willingness to relocate. Possible values are listed in the `resume_search_relocation` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You should specify it only with area parameter 
        :param float period: The search is performed only for resumes published in the given time period (in days). If not specified, the search is performed without any restrictions on the publication date 
        :param str date_from: The date the search should start from.  The value is specified in the [ISO 8601](#date-format) format — `YYYY-MM-DD` or with up-to-the-second precision `YYYY-MM-DDThh:mm:ss±hhmm`. You can not specify it with the `period` parameter 
        :param str date_to: A date until which the search should be performed.  The value is specified in the [ISO 8601](#date-format) format — `YYYY-MM-DD` or with up-to-the-second precision `YYYY-MM-DDThh:mm:ss±hhmm`. You can specify it only with the `date_from` parameter. You can not specify it with the `period` parameter 
        :param str education_level: A level of education. Possible values are listed in the `education_level` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). If not specified, the search is performed without any restrictions on the education level 
        :param str employment: Employment type. Possible values are listed in the `employment` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You can specify several values 
        :param str experience: Work experience. Possible values are listed in the `experience` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str skill: Key skills. At least one key skill identifier should be specified. You can get values from the `id` field in the [key skills suggestion](#tag/Suggestions/operation/get-skill-set-suggests) 
        :param str gender: A gender. Possible values are listed in the `gender` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str label: An extra filter. Possible values are listed in the `resume_search_label` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You can specify several values 
        :param str language: Knowledge of language. You can specify several values. It is set in the format `language.level`, where:  * `language` — value from the [/languages](#tag/Public-directories/operation/get-languages) directory; * `level` — value of the language_level field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries)  Example: `ita.c2` 
        :param str metro: A metro line or station. Possible values are listed in the [/metro](#tag/Public-directories/operation/get-metro-stations) directory 
        :param str currency: A currency code. Possible values are listed in the `currency.code` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param float salary_from: Minimum desired salary range 
        :param float salary_to: Maximum desired salary range 
        :param str schedule: Work schedule. Possible values are listed in the `schedule` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You can specify several values 
        :param str order_by: Resume list sorting. Possible values are listed in the `resume_search_order` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str citizenship: The country of applicant's citizenship. Possible values are listed in the [directory of countries](#tag/Public-directories/operation/get-countries). Several values can be specified 
        :param str work_ticket: A country which the applicant is permitted to work in. You can find possible values in the [directory of countries](#tag/Public-directories/operation/get-countries). Several values can be specified 
        :param str educational_institution: The applicant's educational institutions. Suggestions on university names are used as parameters: [/suggests/educational_institutions](#tag/Suggestions/operation/get-educational-institutions-suggests). Several values can be specified 
        :param bool search_in_responses: If `true`, the search is performed only by resumes that applicants used to response the employer's vacancies. If `false` — the search is carried out by all resumes. By default — `false` 
        :param bool by_text_prefix: If `true`, the search is performed by prefix. For every `text` parameter the search results are not only exact matchings but also words that begin with `text`. Default — `false` 
        :param str driver_license_types: Driver license types. Possible values are listed in the `driver_license_types` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str vacancy_id: Vacancy ID for searching similar resumes. You should specify ID of active or archived employer's vacancy 
        :param float page: Page number (counts from 0, default — 0)
        :param float per_page: Number of elements (default — 10, maximum value — 50)
        :param str professional_role: Professional role. Possible values are listed in the [professional role directory](#tag/Public-directories/operation/get-professional-roles-dictionary). Several values can be specified 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: str
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'text', 'text_logic', 'text_field', 'text_period', 'age_from', 'age_to', 'area', 'relocation', 'period', 'date_from', 'date_to', 'education_level', 'employment', 'experience', 'skill', 'gender', 'label', 'language', 'metro', 'currency', 'salary_from', 'salary_to', 'schedule', 'order_by', 'citizenship', 'work_ticket', 'educational_institution', 'search_in_responses', 'by_text_prefix', 'driver_license_types', 'vacancy_id', 'page', 'per_page', 'professional_role', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method create_saved_resume_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `create_saved_resume_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'text' in params:
            query_params.append(('text', params['text']))  # noqa: E501
        if 'text_logic' in params:
            query_params.append(('text.logic', params['text_logic']))  # noqa: E501
        if 'text_field' in params:
            query_params.append(('text.field', params['text_field']))  # noqa: E501
        if 'text_period' in params:
            query_params.append(('text.period', params['text_period']))  # noqa: E501
        if 'age_from' in params:
            query_params.append(('age_from', params['age_from']))  # noqa: E501
        if 'age_to' in params:
            query_params.append(('age_to', params['age_to']))  # noqa: E501
        if 'area' in params:
            query_params.append(('area', params['area']))  # noqa: E501
        if 'relocation' in params:
            query_params.append(('relocation', params['relocation']))  # noqa: E501
        if 'period' in params:
            query_params.append(('period', params['period']))  # noqa: E501
        if 'date_from' in params:
            query_params.append(('date_from', params['date_from']))  # noqa: E501
        if 'date_to' in params:
            query_params.append(('date_to', params['date_to']))  # noqa: E501
        if 'education_level' in params:
            query_params.append(('education_level', params['education_level']))  # noqa: E501
        if 'employment' in params:
            query_params.append(('employment', params['employment']))  # noqa: E501
        if 'experience' in params:
            query_params.append(('experience', params['experience']))  # noqa: E501
        if 'skill' in params:
            query_params.append(('skill', params['skill']))  # noqa: E501
        if 'gender' in params:
            query_params.append(('gender', params['gender']))  # noqa: E501
        if 'label' in params:
            query_params.append(('label', params['label']))  # noqa: E501
        if 'language' in params:
            query_params.append(('language', params['language']))  # noqa: E501
        if 'metro' in params:
            query_params.append(('metro', params['metro']))  # noqa: E501
        if 'currency' in params:
            query_params.append(('currency', params['currency']))  # noqa: E501
        if 'salary_from' in params:
            query_params.append(('salary_from', params['salary_from']))  # noqa: E501
        if 'salary_to' in params:
            query_params.append(('salary_to', params['salary_to']))  # noqa: E501
        if 'schedule' in params:
            query_params.append(('schedule', params['schedule']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'citizenship' in params:
            query_params.append(('citizenship', params['citizenship']))  # noqa: E501
        if 'work_ticket' in params:
            query_params.append(('work_ticket', params['work_ticket']))  # noqa: E501
        if 'educational_institution' in params:
            query_params.append(('educational_institution', params['educational_institution']))  # noqa: E501
        if 'search_in_responses' in params:
            query_params.append(('search_in_responses', params['search_in_responses']))  # noqa: E501
        if 'by_text_prefix' in params:
            query_params.append(('by_text_prefix', params['by_text_prefix']))  # noqa: E501
        if 'driver_license_types' in params:
            query_params.append(('driver_license_types', params['driver_license_types']))  # noqa: E501
        if 'vacancy_id' in params:
            query_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'professional_role' in params:
            query_params.append(('professional_role', params['professional_role']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['text/html', 'application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/resumes', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='str',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def delete_saved_resume_search(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting saved resume search  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_saved_resume_search(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved resume search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.delete_saved_resume_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.delete_saved_resume_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def delete_saved_resume_search_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting saved resume search  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_saved_resume_search_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved resume search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method delete_saved_resume_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `delete_saved_resume_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `delete_saved_resume_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/resumes/{id}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_saved_resume_search(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Getting single saved resume search  # noqa: E501

        Note: the `new_items.count` counter is updated once an hour. Because of this, the actual number of new resumes found  may differ from the value of this counter   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_resume_search(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved resume search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchItem
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_saved_resume_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_saved_resume_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_saved_resume_search_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Getting single saved resume search  # noqa: E501

        Note: the `new_items.count` counter is updated once an hour. Because of this, the actual number of new resumes found  may differ from the value of this counter   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_resume_search_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved resume search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchItem
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_saved_resume_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `get_saved_resume_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_saved_resume_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/resumes/{id}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='SavedSearchesSavedSearchItem',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_saved_resume_searches(self, hh_user_agent, **kwargs):  # noqa: E501
        """List of Saved resume searches  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_resume_searches(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counts from 0, default — 0)
        :param float per_page: Number of elements (default — 5, maximum value — 10)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_saved_resume_searches_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_saved_resume_searches_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_saved_resume_searches_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """List of Saved resume searches  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_saved_resume_searches_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number (counts from 0, default — 0)
        :param float per_page: Number of elements (default — 5, maximum value — 10)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: SavedSearchesSavedSearchResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'page', 'per_page', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_saved_resume_searches" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_saved_resume_searches`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/resumes', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='SavedSearchesSavedSearchResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def move_saved_resume_search(self, saved_search_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Moving saved resumes search to other manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.move_saved_resume_search(saved_search_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str saved_search_id: Autosearch ID that can be obtained in [list of saved resume searches](#tag/Saved-resume-searches/operation/get-saved-resume-searches) (required)
        :param str manager_id: Manager ID ([managers of this company](#tag/Employer-managers/operation/get-employer-managers)) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.move_saved_resume_search_with_http_info(saved_search_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.move_saved_resume_search_with_http_info(saved_search_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def move_saved_resume_search_with_http_info(self, saved_search_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Moving saved resumes search to other manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.move_saved_resume_search_with_http_info(saved_search_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str saved_search_id: Autosearch ID that can be obtained in [list of saved resume searches](#tag/Saved-resume-searches/operation/get-saved-resume-searches) (required)
        :param str manager_id: Manager ID ([managers of this company](#tag/Employer-managers/operation/get-employer-managers)) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['saved_search_id', 'manager_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method move_saved_resume_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'saved_search_id' is set
        if ('saved_search_id' not in params or
                params['saved_search_id'] is None):
            raise ValueError("Missing the required parameter `saved_search_id` when calling `move_saved_resume_search`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `move_saved_resume_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `move_saved_resume_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'saved_search_id' in params:
            path_params['saved_search_id'] = params['saved_search_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/resumes/{saved_search_id}/managers/{manager_id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def update_saved_resume_search(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Updating saved resume search  # noqa: E501

        You can change subscription name and status for saved search. Only one parameter can be changed at a time  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.update_saved_resume_search(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved resume search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str name: New search name
        :param bool subscription: Subscription status
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.update_saved_resume_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.update_saved_resume_search_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def update_saved_resume_search_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Updating saved resume search  # noqa: E501

        You can change subscription name and status for saved search. Only one parameter can be changed at a time  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.update_saved_resume_search_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Saved resume search ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str name: New search name
        :param bool subscription: Subscription status
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'name', 'subscription', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method update_saved_resume_search" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `update_saved_resume_search`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `update_saved_resume_search`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'name' in params:
            query_params.append(('name', params['name']))  # noqa: E501
        if 'subscription' in params:
            query_params.append(('subscription', params['subscription']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/saved_searches/resumes/{id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
