# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class ResumeVisibilityListsApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def add_resume_visibility_list(self, body, hh_user_agent, resume_id, list_type, **kwargs):  # noqa: E501
        """Adding employers to the visibility list  # noqa: E501

        Adds specified employers to visibility list of the specified type.  One request can add no more than 100 companies.  The procedure of adding employers to the list is idempotent, that is, employers who are already present in the list will be ignored to avoid duplicate entries.  You can add a banned employer to the list   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_resume_visibility_list(body, hh_user_agent, resume_id, list_type, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param ResumesPostResumeVisibilityListBody body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.add_resume_visibility_list_with_http_info(body, hh_user_agent, resume_id, list_type, **kwargs)  # noqa: E501
        else:
            (data) = self.add_resume_visibility_list_with_http_info(body, hh_user_agent, resume_id, list_type, **kwargs)  # noqa: E501
            return data

    def add_resume_visibility_list_with_http_info(self, body, hh_user_agent, resume_id, list_type, **kwargs):  # noqa: E501
        """Adding employers to the visibility list  # noqa: E501

        Adds specified employers to visibility list of the specified type.  One request can add no more than 100 companies.  The procedure of adding employers to the list is idempotent, that is, employers who are already present in the list will be ignored to avoid duplicate entries.  You can add a banned employer to the list   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_resume_visibility_list_with_http_info(body, hh_user_agent, resume_id, list_type, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param ResumesPostResumeVisibilityListBody body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'hh_user_agent', 'resume_id', 'list_type', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method add_resume_visibility_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `add_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `add_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `add_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'list_type' is set
        if ('list_type' not in params or
                params['list_type'] is None):
            raise ValueError("Missing the required parameter `list_type` when calling `add_resume_visibility_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501
        if 'list_type' in params:
            path_params['list_type'] = params['list_type']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/{list_type}', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def delete_employer_from_resume_visibility_list(self, resume_id, list_type, id, hh_user_agent, **kwargs):  # noqa: E501
        """Removing employers from the visibility list  # noqa: E501

        The operation to remove from the list is idempotent, that is, the removal of employers who are not on the list or do not exist is ignored and does not lead to errors. The result will be the same if you remove the \"real\" identifiers from the list.  You can remove a banned employer from the list.  One request can remove no more than 100 companies   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_employer_from_resume_visibility_list(resume_id, list_type, id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str id: Employer ID. Multiple parameter (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.delete_employer_from_resume_visibility_list_with_http_info(resume_id, list_type, id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.delete_employer_from_resume_visibility_list_with_http_info(resume_id, list_type, id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def delete_employer_from_resume_visibility_list_with_http_info(self, resume_id, list_type, id, hh_user_agent, **kwargs):  # noqa: E501
        """Removing employers from the visibility list  # noqa: E501

        The operation to remove from the list is idempotent, that is, the removal of employers who are not on the list or do not exist is ignored and does not lead to errors. The result will be the same if you remove the \"real\" identifiers from the list.  You can remove a banned employer from the list.  One request can remove no more than 100 companies   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_employer_from_resume_visibility_list_with_http_info(resume_id, list_type, id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str id: Employer ID. Multiple parameter (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['resume_id', 'list_type', 'id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method delete_employer_from_resume_visibility_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `delete_employer_from_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'list_type' is set
        if ('list_type' not in params or
                params['list_type'] is None):
            raise ValueError("Missing the required parameter `list_type` when calling `delete_employer_from_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `delete_employer_from_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `delete_employer_from_resume_visibility_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501
        if 'list_type' in params:
            path_params['list_type'] = params['list_type']  # noqa: E501

        query_params = []
        if 'id' in params:
            query_params.append(('id', params['id']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/{list_type}/employer', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def delete_resume_visibility_list(self, resume_id, list_type, hh_user_agent, **kwargs):  # noqa: E501
        """Clearing the visibility list  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_resume_visibility_list(resume_id, list_type, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.delete_resume_visibility_list_with_http_info(resume_id, list_type, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.delete_resume_visibility_list_with_http_info(resume_id, list_type, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def delete_resume_visibility_list_with_http_info(self, resume_id, list_type, hh_user_agent, **kwargs):  # noqa: E501
        """Clearing the visibility list  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_resume_visibility_list_with_http_info(resume_id, list_type, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['resume_id', 'list_type', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method delete_resume_visibility_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `delete_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'list_type' is set
        if ('list_type' not in params or
                params['list_type'] is None):
            raise ValueError("Missing the required parameter `list_type` when calling `delete_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `delete_resume_visibility_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501
        if 'list_type' in params:
            path_params['list_type'] = params['list_type']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/{list_type}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_resume_access_types(self, resume_id, hh_user_agent, **kwargs):  # noqa: E501
        """Retrieving a list of resume visibility types  # noqa: E501

        Some visibility types, i.e. `whitelist` and `blacklist`, imply that there is a list of employers for whom the resume is visible or hidden. See [Resume visibility lists](#tag/Resume-visibility-lists)  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_access_types(resume_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesAccessTypes
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_resume_access_types_with_http_info(resume_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_resume_access_types_with_http_info(resume_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_resume_access_types_with_http_info(self, resume_id, hh_user_agent, **kwargs):  # noqa: E501
        """Retrieving a list of resume visibility types  # noqa: E501

        Some visibility types, i.e. `whitelist` and `blacklist`, imply that there is a list of employers for whom the resume is visible or hidden. See [Resume visibility lists](#tag/Resume-visibility-lists)  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_access_types_with_http_info(resume_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesAccessTypes
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['resume_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_resume_access_types" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `get_resume_access_types`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_resume_access_types`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/access_types', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResumesAccessTypes',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_resume_visibility_employers_list(self, resume_id, list_type, text, hh_user_agent, **kwargs):  # noqa: E501
        """Searching for employers to add to the visibility list  # noqa: E501

        Returns employer search results  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_visibility_employers_list(resume_id, list_type, text, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str text: Search string. The passed value is searched at the beginning of the employer name and at the beginning of the employer department names (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Default and maximum `per_page` are `100` 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from `0` 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesResumeVisibilityListSearchResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_resume_visibility_employers_list_with_http_info(resume_id, list_type, text, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_resume_visibility_employers_list_with_http_info(resume_id, list_type, text, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_resume_visibility_employers_list_with_http_info(self, resume_id, list_type, text, hh_user_agent, **kwargs):  # noqa: E501
        """Searching for employers to add to the visibility list  # noqa: E501

        Returns employer search results  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_visibility_employers_list_with_http_info(resume_id, list_type, text, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str text: Search string. The passed value is searched at the beginning of the employer name and at the beginning of the employer department names (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Default and maximum `per_page` are `100` 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from `0` 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesResumeVisibilityListSearchResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['resume_id', 'list_type', 'text', 'hh_user_agent', 'per_page', 'page', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_resume_visibility_employers_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `get_resume_visibility_employers_list`")  # noqa: E501
        # verify the required parameter 'list_type' is set
        if ('list_type' not in params or
                params['list_type'] is None):
            raise ValueError("Missing the required parameter `list_type` when calling `get_resume_visibility_employers_list`")  # noqa: E501
        # verify the required parameter 'text' is set
        if ('text' not in params or
                params['text'] is None):
            raise ValueError("Missing the required parameter `text` when calling `get_resume_visibility_employers_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_resume_visibility_employers_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501
        if 'list_type' in params:
            path_params['list_type'] = params['list_type']  # noqa: E501

        query_params = []
        if 'text' in params:
            query_params.append(('text', params['text']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/{list_type}/search', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResumesResumeVisibilityListSearchResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_resume_visibility_list(self, resume_id, list_type, hh_user_agent, **kwargs):  # noqa: E501
        """Getting visibility lists  # noqa: E501

        Returns list of employers for which resume should be visible or hidden   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_visibility_list(resume_id, list_type, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesGetResumeVisibilityListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_resume_visibility_list_with_http_info(resume_id, list_type, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_resume_visibility_list_with_http_info(resume_id, list_type, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_resume_visibility_list_with_http_info(self, resume_id, list_type, hh_user_agent, **kwargs):  # noqa: E501
        """Getting visibility lists  # noqa: E501

        Returns list of employers for which resume should be visible or hidden   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_visibility_list_with_http_info(resume_id, list_type, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str list_type: List type. Available values — `whitelist` or `blacklist` (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesGetResumeVisibilityListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['resume_id', 'list_type', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_resume_visibility_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `get_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'list_type' is set
        if ('list_type' not in params or
                params['list_type'] is None):
            raise ValueError("Missing the required parameter `list_type` when calling `get_resume_visibility_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_resume_visibility_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501
        if 'list_type' in params:
            path_params['list_type'] = params['list_type']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/{list_type}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResumesGetResumeVisibilityListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
