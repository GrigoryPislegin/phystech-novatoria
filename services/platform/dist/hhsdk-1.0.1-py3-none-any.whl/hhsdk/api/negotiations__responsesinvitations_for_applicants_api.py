# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class NegotiationsResponsesinvitationsForApplicantsApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def edit_negotiation_message(self, nid, mid, hh_user_agent, **kwargs):  # noqa: E501
        """Edit messages in the response  # noqa: E501

        At the moment, editing is only available for messages in response.  Message text can be edited after sending, provided the following conditions are met:  - The message has not been read by the other party. - The job vacancy to which the response was sent must be active (not archived). - The resume from the response must not be hidden or deleted. Conditions may change.  Each message in [the list of responses](#tag/Employer-responsesinvitations/operation/get-negotiation-item) has an 'editable' field indicating the ability to edit   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.edit_negotiation_message(nid, mid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: The response ID (required)
        :param str mid: The response message ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.edit_negotiation_message_with_http_info(nid, mid, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.edit_negotiation_message_with_http_info(nid, mid, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def edit_negotiation_message_with_http_info(self, nid, mid, hh_user_agent, **kwargs):  # noqa: E501
        """Edit messages in the response  # noqa: E501

        At the moment, editing is only available for messages in response.  Message text can be edited after sending, provided the following conditions are met:  - The message has not been read by the other party. - The job vacancy to which the response was sent must be active (not archived). - The resume from the response must not be hidden or deleted. Conditions may change.  Each message in [the list of responses](#tag/Employer-responsesinvitations/operation/get-negotiation-item) has an 'editable' field indicating the ability to edit   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.edit_negotiation_message_with_http_info(nid, mid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: The response ID (required)
        :param str mid: The response message ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['nid', 'mid', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method edit_negotiation_message" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `edit_negotiation_message`")  # noqa: E501
        # verify the required parameter 'mid' is set
        if ('mid' not in params or
                params['mid'] is None):
            raise ValueError("Missing the required parameter `mid` when calling `edit_negotiation_message`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `edit_negotiation_message`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501
        if 'mid' in params:
            path_params['mid'] = params['mid']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{nid}/messages/{mid}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_active_negotiations(self, hh_user_agent, **kwargs):  # noqa: E501
        """Active negotiation list  # noqa: E501

        Returns the list of active negotiations of the applicant.  The request is deprecated and is used for backward compatibility. Use [negotiation list request](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiations) with the `?status=active` parameter instead   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_active_negotiations(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements per page. Default — 0
        :param str order_by: The field to sort the data by. Possible values are specified in the `negotiations_order` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries)
        :param str order: Sort order. Possible values are: `asc`, `desc`. Default — `desc`
        :param str vacancy_id: Filter by a vacancy ID
        :param bool has_updates: If `true`, the request returns the elements only with unread messages. Default — `false` 
        :param bool with_job_search_status: If `true`, the request returns applicant's job search status 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_active_negotiations_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_active_negotiations_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_active_negotiations_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Active negotiation list  # noqa: E501

        Returns the list of active negotiations of the applicant.  The request is deprecated and is used for backward compatibility. Use [negotiation list request](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiations) with the `?status=active` parameter instead   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_active_negotiations_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements per page. Default — 0
        :param str order_by: The field to sort the data by. Possible values are specified in the `negotiations_order` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries)
        :param str order: Sort order. Possible values are: `asc`, `desc`. Default — `desc`
        :param str vacancy_id: Filter by a vacancy ID
        :param bool has_updates: If `true`, the request returns the elements only with unread messages. Default — `false` 
        :param bool with_job_search_status: If `true`, the request returns applicant's job search status 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'page', 'per_page', 'order_by', 'order', 'vacancy_id', 'has_updates', 'with_job_search_status', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_active_negotiations" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_active_negotiations`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'order' in params:
            query_params.append(('order', params['order']))  # noqa: E501
        if 'vacancy_id' in params:
            query_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'has_updates' in params:
            query_params.append(('has_updates', params['has_updates']))  # noqa: E501
        if 'with_job_search_status' in params:
            query_params.append(('with_job_search_status', params['with_job_search_status']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/active', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiation_item(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Viewing the response/invitation  # noqa: E501

        Returns information about the negotiations by its ID.  The employer can get the request URL from the [negotiations list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) (`items[].url` field).  > !! Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_item(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiation_item_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiation_item_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiation_item_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Viewing the response/invitation  # noqa: E501

        Returns information about the negotiations by its ID.  The employer can get the request URL from the [negotiations list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) (`items[].url` field).  > !! Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_item_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiation_item" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `get_negotiation_item`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiation_item`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{id}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsNegotiationGetResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiation_messages(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """View the list of messages in the negotiation  # noqa: E501

        Returns a list of all messages of the selected response/invitation. The employer can view the list by the URL specified in the `messages` field of the [response/invitation list](#tag/Employer-responsesinvitations/operation/get-negotiations) or in a [response](#tag/Employer-responsesinvitations/operation/get-negotiation-item).    Types of messages:  * the applicant's cover letter; * a cover letter from the employer when changing the negotiation status; * free conversation between the applicant and the employer.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_messages(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool with_text_only: Return non-empty messages (contain text in the `text` parameter)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessagesGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiation_messages_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiation_messages_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiation_messages_with_http_info(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """View the list of messages in the negotiation  # noqa: E501

        Returns a list of all messages of the selected response/invitation. The employer can view the list by the URL specified in the `messages` field of the [response/invitation list](#tag/Employer-responsesinvitations/operation/get-negotiations) or in a [response](#tag/Employer-responsesinvitations/operation/get-negotiation-item).    Types of messages:  * the applicant's cover letter; * a cover letter from the employer when changing the negotiation status; * free conversation between the applicant and the employer.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_messages_with_http_info(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool with_text_only: Return non-empty messages (contain text in the `text` parameter)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessagesGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['nid', 'hh_user_agent', 'with_text_only', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiation_messages" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `get_negotiation_messages`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiation_messages`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'with_text_only' in params:
            query_params.append(('with_text_only', params['with_text_only']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{nid}/messages', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsMessagesGetResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiations(self, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation list  # noqa: E501

        Returns the list of the applicant's negotiations or negotiation (responses/invitations) collections to employer's [vacancy](#tag/Vacancy-management/operation/get-active-vacancy-list).  By default, negotiations are sorted by date of change — from new ones to old.  To obtain the list of active negotiations, specify the `?status=active` parameter in the request   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements per page
        :param str order_by: The field to sort the data by. Possible values are specified in the `negotiations_order` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries)
        :param str order: Sort order. Possible values are: `asc`, `desc`. Default — `desc`
        :param str vacancy_id: Filter by a vacancy ID. Required for the employer
        :param str status: The request returns negotiations only in the specified status.  Possible values are specified in the `applicant_negotiation_status` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param bool has_updates: If `true`, the request returns the elements only with unread messages. Default — `false` 
        :param bool with_job_search_status: If `true`, the request returns applicant's job search status 
        :param bool with_generated_collections: If `true`, the request returns information about [responses/invitations collection](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md#term-collection) for the vacancy.  To get uploads across multiple collections, request it one by one. Default — `false` 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiations_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiations_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiations_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation list  # noqa: E501

        Returns the list of the applicant's negotiations or negotiation (responses/invitations) collections to employer's [vacancy](#tag/Vacancy-management/operation/get-active-vacancy-list).  By default, negotiations are sorted by date of change — from new ones to old.  To obtain the list of active negotiations, specify the `?status=active` parameter in the request   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements per page
        :param str order_by: The field to sort the data by. Possible values are specified in the `negotiations_order` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries)
        :param str order: Sort order. Possible values are: `asc`, `desc`. Default — `desc`
        :param str vacancy_id: Filter by a vacancy ID. Required for the employer
        :param str status: The request returns negotiations only in the specified status.  Possible values are specified in the `applicant_negotiation_status` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param bool has_updates: If `true`, the request returns the elements only with unread messages. Default — `false` 
        :param bool with_job_search_status: If `true`, the request returns applicant's job search status 
        :param bool with_generated_collections: If `true`, the request returns information about [responses/invitations collection](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md#term-collection) for the vacancy.  To get uploads across multiple collections, request it one by one. Default — `false` 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'page', 'per_page', 'order_by', 'order', 'vacancy_id', 'status', 'has_updates', 'with_job_search_status', 'with_generated_collections', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiations" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiations`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'order' in params:
            query_params.append(('order', params['order']))  # noqa: E501
        if 'vacancy_id' in params:
            query_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'status' in params:
            query_params.append(('status', params['status']))  # noqa: E501
        if 'has_updates' in params:
            query_params.append(('has_updates', params['has_updates']))  # noqa: E501
        if 'with_job_search_status' in params:
            query_params.append(('with_job_search_status', params['with_job_search_status']))  # noqa: E501
        if 'with_generated_collections' in params:
            query_params.append(('with_generated_collections', params['with_generated_collections']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def hide_active_response(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """Hide response  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.hide_active_response(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Response ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool with_decline_message: Whether a refusal message should be sent to the employer (default - `false`). The ability to send a refusal message is determined by the `decline_allowed` field, which is returned by the system in response to the request for a [list response or one response](https://github.com/hhru/api/blob/e2a0ac4e174a6b56272f78348c05958f5db1b392/docs_eng/errors.md#negotiations-responsesinvitations) 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.hide_active_response_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.hide_active_response_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def hide_active_response_with_http_info(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """Hide response  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.hide_active_response_with_http_info(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Response ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool with_decline_message: Whether a refusal message should be sent to the employer (default - `false`). The ability to send a refusal message is determined by the `decline_allowed` field, which is returned by the system in response to the request for a [list response or one response](https://github.com/hhru/api/blob/e2a0ac4e174a6b56272f78348c05958f5db1b392/docs_eng/errors.md#negotiations-responsesinvitations) 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['nid', 'hh_user_agent', 'with_decline_message', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method hide_active_response" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `hide_active_response`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `hide_active_response`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'with_decline_message' in params:
            query_params.append(('with_decline_message', params['with_decline_message']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/active/{nid}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def send_negotiation_message(self, hh_user_agent, nid, **kwargs):  # noqa: E501
        """Sending new message  # noqa: E501

        Sends new negotiation message.  Applicant or employer can send a new message in the following cases:  * The employer invited the applicant for a vacancy. * The applicant left a response to the vacancy.  Negotiation is unavailable if the vacancy is archived or the applicant deleted the resume. Employer can also disable the negotiation for the vacancy manually.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.send_negotiation_message(hh_user_agent, nid, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str nid: Negotiation ID (required)
        :param str message:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessageSent
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.send_negotiation_message_with_http_info(hh_user_agent, nid, **kwargs)  # noqa: E501
        else:
            (data) = self.send_negotiation_message_with_http_info(hh_user_agent, nid, **kwargs)  # noqa: E501
            return data

    def send_negotiation_message_with_http_info(self, hh_user_agent, nid, **kwargs):  # noqa: E501
        """Sending new message  # noqa: E501

        Sends new negotiation message.  Applicant or employer can send a new message in the following cases:  * The employer invited the applicant for a vacancy. * The applicant left a response to the vacancy.  Negotiation is unavailable if the vacancy is archived or the applicant deleted the resume. Employer can also disable the negotiation for the vacancy manually.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.send_negotiation_message_with_http_info(hh_user_agent, nid, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str nid: Negotiation ID (required)
        :param str message:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessageSent
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'nid', 'message', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method send_negotiation_message" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `send_negotiation_message`")  # noqa: E501
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `send_negotiation_message`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}
        if 'message' in params:
            form_params.append(('message', params['message']))  # noqa: E501

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'text/html'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/x-www-form-urlencoded'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{nid}/messages', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsMessageSent',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
