# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class EmployerResponsesinvitationsApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def change_negotiation_action(self, collection_name, nid, hh_user_agent, **kwargs):  # noqa: E501
        """Actions with collection response/invitation  # noqa: E501

        Change employer's state (`employer_state`) or applicant's state (`state`) for the negotiation.  #### Change employer's state for the negotiation  > Available actions for each negotiation are listed in the `employer_states` array [list of responses/invitations](#tag/Employer-responsesinvitations/operation/get-negotiations).  To change the response status, make a request from the `actions[].url` parameter of the [response/invitation list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) for the selected response action. The request must pass the arguments of the array `actions[].arguments` in `application/x-www-form-urlencoded' format.  Action examples:  * delay the response; * invite the applicant to an interview in response to the response; * reject the applicant.  #### Change applicant's state for the negotiation  Changing the applicant's negotiation status affects [response statistics](#tag/Employer-responsesinvitations/operation/get-negotiations-statistics-employer).  The condition for changing the applicant's negotiation status is sending a message to the applicant in any of the ways:  - Perform an action with a response/invitation using the `/negotiations/{collection_name}/{nid}` method, with an accompanying message. - [Send the message](#tag/Employer-responsesinvitations/operation/send-negotiation-message) in response. The status will change if the method of changing the employer's status without an accompanying message was used before sending.  In both cases, the applicant's status will change to either an invitation (`invitation`) or a refusal (`discard`)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.change_negotiation_action(collection_name, nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str collection_name: Collection name. Possible values are specified in the `generated_collections.name` field [list of collections](#tag/Employer-responsesinvitations/operation/get-negotiations)  (required)
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.change_negotiation_action_with_http_info(collection_name, nid, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.change_negotiation_action_with_http_info(collection_name, nid, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def change_negotiation_action_with_http_info(self, collection_name, nid, hh_user_agent, **kwargs):  # noqa: E501
        """Actions with collection response/invitation  # noqa: E501

        Change employer's state (`employer_state`) or applicant's state (`state`) for the negotiation.  #### Change employer's state for the negotiation  > Available actions for each negotiation are listed in the `employer_states` array [list of responses/invitations](#tag/Employer-responsesinvitations/operation/get-negotiations).  To change the response status, make a request from the `actions[].url` parameter of the [response/invitation list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) for the selected response action. The request must pass the arguments of the array `actions[].arguments` in `application/x-www-form-urlencoded' format.  Action examples:  * delay the response; * invite the applicant to an interview in response to the response; * reject the applicant.  #### Change applicant's state for the negotiation  Changing the applicant's negotiation status affects [response statistics](#tag/Employer-responsesinvitations/operation/get-negotiations-statistics-employer).  The condition for changing the applicant's negotiation status is sending a message to the applicant in any of the ways:  - Perform an action with a response/invitation using the `/negotiations/{collection_name}/{nid}` method, with an accompanying message. - [Send the message](#tag/Employer-responsesinvitations/operation/send-negotiation-message) in response. The status will change if the method of changing the employer's status without an accompanying message was used before sending.  In both cases, the applicant's status will change to either an invitation (`invitation`) or a refusal (`discard`)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.change_negotiation_action_with_http_info(collection_name, nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str collection_name: Collection name. Possible values are specified in the `generated_collections.name` field [list of collections](#tag/Employer-responsesinvitations/operation/get-negotiations)  (required)
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['collection_name', 'nid', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method change_negotiation_action" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'collection_name' is set
        if ('collection_name' not in params or
                params['collection_name'] is None):
            raise ValueError("Missing the required parameter `collection_name` when calling `change_negotiation_action`")  # noqa: E501
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `change_negotiation_action`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `change_negotiation_action`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'collection_name' in params:
            path_params['collection_name'] = params['collection_name']  # noqa: E501
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{collection_name}/{nid}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_collection_negotiations_list(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation list of the collection  # noqa: E501

        Returns the list of negotiation (responses/invitations) for the collection. The URL for the request must be taken from the `collections[].url` field [list of collections](#tag/Employer-responsesinvitations/operation/get-negotiations).  > Instead of `response`, the parameter `{collection_name}` must be specified. Possible values are specified in the `generated_collections.name` field [list of collections](#tag/Employer-responsesinvitations/operation/get-negotiations).  The response will contain only basic information about the resume. To get additional information, for example, a contact phone number, it is necessary to [request a full resume](#tag/Vacancy-management/operation/get-vacancy).  Some parameters can take multiple values: `key=value&key=value`. If a parameter can take multiple values, this is explicitly stated in its description. Unknown parameters and parameters with an error in its name are ignored.  > The `phone_calls` collection accepts only the `vacancy_id`, `order_by`, `page` and `per_page` parameters   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_collection_negotiations_list(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str order_by: Resume list sorting. Possible values are listed in the `resume_search_order` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from 0 
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Maximum value is `50` 
        :param str age_from: Minimum applicant's age in years
        :param str age_to: Maximum applicant's age in years 
        :param str area: Region. Possible values are listed in the [region directory](#tag/Public-directories/operation/get-areas).  You can specify several values. Resumes of applicants from specified regions or those who ready to move to such regions are selected by default. Enter field `relocation` to change this behavior 
        :param str citizenship: The country of applicant's citizenship. Possible values are listed in the [directory of countries](#tag/Public-directories/operation/get-countries). Several values can be specified 
        :param str currency: A currency code. Possible values are listed in the `currency.code` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str driver_license_types: Driver license types. Possible values are listed in the `driver_license_types` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str educational_institution: The applicant's educational institutions. Suggestions on university names are used as parameters: [/suggests/educational_institutions](#tag/Suggestions/operation/get-educational-institutions-suggests). Several values can be specified 
        :param str education_level: A level of education. Possible values are listed in the `education_level` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). If not specified, the search is performed without any restrictions on the education level 
        :param str experience: Work experience. Possible values are listed in the `experience` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str gender: A gender. Possible values are listed in the `gender` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str language: Knowledge of language. You can specify several values. It is set in the format `language.level`, where:  * `language` — value from the [/languages](#tag/Public-directories/operation/get-languages) directory; * `level` — value of the language_level field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries)  Example: `ita.c2` 
        :param str relocation: Willingness to relocate. Possible values are listed in the `resume_search_relocation` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You should specify it only with area parameter 
        :param float salary_from: Minimum desired salary range 
        :param float salary_to: Maximum desired salary range 
        :param float search_radius_meters: Distance to the candidate (in meters)
        :param str search_text: Search string
        :param bool show_only_new_responses: Show only unviewed responses of the “All unsorted” collection (`/response`) 
        :param bool show_only_with_vehicle: Show applicants with a personal car
        :param bool show_only_new: Show responses that have new messages for all collections other than “All unsorted” collection (`/response`) 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsCollectionNegotiationsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_collection_negotiations_list_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_collection_negotiations_list_with_http_info(vacancy_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_collection_negotiations_list_with_http_info(self, vacancy_id, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation list of the collection  # noqa: E501

        Returns the list of negotiation (responses/invitations) for the collection. The URL for the request must be taken from the `collections[].url` field [list of collections](#tag/Employer-responsesinvitations/operation/get-negotiations).  > Instead of `response`, the parameter `{collection_name}` must be specified. Possible values are specified in the `generated_collections.name` field [list of collections](#tag/Employer-responsesinvitations/operation/get-negotiations).  The response will contain only basic information about the resume. To get additional information, for example, a contact phone number, it is necessary to [request a full resume](#tag/Vacancy-management/operation/get-vacancy).  Some parameters can take multiple values: `key=value&key=value`. If a parameter can take multiple values, this is explicitly stated in its description. Unknown parameters and parameters with an error in its name are ignored.  > The `phone_calls` collection accepts only the `vacancy_id`, `order_by`, `page` and `per_page` parameters   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_collection_negotiations_list_with_http_info(vacancy_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str vacancy_id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str order_by: Resume list sorting. Possible values are listed in the `resume_search_order` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param int page: Number of page, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Pagination starts from 0 
        :param int per_page: Amount of elements, that should be displayed in response. Request applies [standard pagination parameters](#section/General-information/Pagination). Maximum value is `50` 
        :param str age_from: Minimum applicant's age in years
        :param str age_to: Maximum applicant's age in years 
        :param str area: Region. Possible values are listed in the [region directory](#tag/Public-directories/operation/get-areas).  You can specify several values. Resumes of applicants from specified regions or those who ready to move to such regions are selected by default. Enter field `relocation` to change this behavior 
        :param str citizenship: The country of applicant's citizenship. Possible values are listed in the [directory of countries](#tag/Public-directories/operation/get-countries). Several values can be specified 
        :param str currency: A currency code. Possible values are listed in the `currency.code` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str driver_license_types: Driver license types. Possible values are listed in the `driver_license_types` field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str educational_institution: The applicant's educational institutions. Suggestions on university names are used as parameters: [/suggests/educational_institutions](#tag/Suggestions/operation/get-educational-institutions-suggests). Several values can be specified 
        :param str education_level: A level of education. Possible values are listed in the `education_level` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). If not specified, the search is performed without any restrictions on the education level 
        :param str experience: Work experience. Possible values are listed in the `experience` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str gender: A gender. Possible values are listed in the `gender` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param str language: Knowledge of language. You can specify several values. It is set in the format `language.level`, where:  * `language` — value from the [/languages](#tag/Public-directories/operation/get-languages) directory; * `level` — value of the language_level field of the [directories of fields](#tag/Public-directories/operation/get-dictionaries)  Example: `ita.c2` 
        :param str relocation: Willingness to relocate. Possible values are listed in the `resume_search_relocation` field in the [directories of fields](#tag/Public-directories/operation/get-dictionaries). You should specify it only with area parameter 
        :param float salary_from: Minimum desired salary range 
        :param float salary_to: Maximum desired salary range 
        :param float search_radius_meters: Distance to the candidate (in meters)
        :param str search_text: Search string
        :param bool show_only_new_responses: Show only unviewed responses of the “All unsorted” collection (`/response`) 
        :param bool show_only_with_vehicle: Show applicants with a personal car
        :param bool show_only_new: Show responses that have new messages for all collections other than “All unsorted” collection (`/response`) 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsCollectionNegotiationsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['vacancy_id', 'hh_user_agent', 'order_by', 'page', 'per_page', 'age_from', 'age_to', 'area', 'citizenship', 'currency', 'driver_license_types', 'educational_institution', 'education_level', 'experience', 'gender', 'language', 'relocation', 'salary_from', 'salary_to', 'search_radius_meters', 'search_text', 'show_only_new_responses', 'show_only_with_vehicle', 'show_only_new', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_collection_negotiations_list" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'vacancy_id' is set
        if ('vacancy_id' not in params or
                params['vacancy_id'] is None):
            raise ValueError("Missing the required parameter `vacancy_id` when calling `get_collection_negotiations_list`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_collection_negotiations_list`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'vacancy_id' in params:
            query_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'age_from' in params:
            query_params.append(('age_from', params['age_from']))  # noqa: E501
        if 'age_to' in params:
            query_params.append(('age_to', params['age_to']))  # noqa: E501
        if 'area' in params:
            query_params.append(('area', params['area']))  # noqa: E501
        if 'citizenship' in params:
            query_params.append(('citizenship', params['citizenship']))  # noqa: E501
        if 'currency' in params:
            query_params.append(('currency', params['currency']))  # noqa: E501
        if 'driver_license_types' in params:
            query_params.append(('driver_license_types', params['driver_license_types']))  # noqa: E501
        if 'educational_institution' in params:
            query_params.append(('educational_institution', params['educational_institution']))  # noqa: E501
        if 'education_level' in params:
            query_params.append(('education_level', params['education_level']))  # noqa: E501
        if 'experience' in params:
            query_params.append(('experience', params['experience']))  # noqa: E501
        if 'gender' in params:
            query_params.append(('gender', params['gender']))  # noqa: E501
        if 'language' in params:
            query_params.append(('language', params['language']))  # noqa: E501
        if 'relocation' in params:
            query_params.append(('relocation', params['relocation']))  # noqa: E501
        if 'salary_from' in params:
            query_params.append(('salary_from', params['salary_from']))  # noqa: E501
        if 'salary_to' in params:
            query_params.append(('salary_to', params['salary_to']))  # noqa: E501
        if 'search_radius_meters' in params:
            query_params.append(('search_radius_meters', params['search_radius_meters']))  # noqa: E501
        if 'search_text' in params:
            query_params.append(('search_text', params['search_text']))  # noqa: E501
        if 'show_only_new_responses' in params:
            query_params.append(('show_only_new_responses', params['show_only_new_responses']))  # noqa: E501
        if 'show_only_with_vehicle' in params:
            query_params.append(('show_only_with_vehicle', params['show_only_with_vehicle']))  # noqa: E501
        if 'show_only_new' in params:
            query_params.append(('show_only_new', params['show_only_new']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/response', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsCollectionNegotiationsResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_mail_templates(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """List of available templates for response to an applicant  # noqa: E501

        Returns the list of available response templates for [negotiations](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_mail_templates(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: MailTemplatesMailTemplates
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_mail_templates_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_mail_templates_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_mail_templates_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """List of available templates for response to an applicant  # noqa: E501

        Returns the list of available response templates for [negotiations](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_mail_templates_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: MailTemplatesMailTemplates
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_mail_templates" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_mail_templates`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_mail_templates`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/mail_templates', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='MailTemplatesMailTemplates',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiation_item(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Viewing the response/invitation  # noqa: E501

        Returns information about the negotiations by its ID.  The employer can get the request URL from the [negotiations list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) (`items[].url` field).  > !! Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_item(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiation_item_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiation_item_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiation_item_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Viewing the response/invitation  # noqa: E501

        Returns information about the negotiations by its ID.  The employer can get the request URL from the [negotiations list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) (`items[].url` field).  > !! Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_item_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiation_item" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `get_negotiation_item`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiation_item`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{id}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsNegotiationGetResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiation_message_templates(self, template, hh_user_agent, **kwargs):  # noqa: E501
        """Template list for the negotiation  # noqa: E501

        The method requires [paid access for the employer](#operation/get-payable-api-method-access).  Returns response templates list for a negotiation or resume. It can be used in invitations sent to the applicant or [negotiation actions](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state).  > The number of available templates will depend on the specific negotiation or vacancy and statuses of the vacancy.  It is recommended to use the URL included in the templates object in the [negotiations list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) and suitable vacancies. Examples:  ``` GET /message_templates/{template}?topic_id={topic_id} GET /message_templates/{template}?vacancy_id={vacancy_id}&resume_id={resume_id} ```   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_message_templates(template, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str template: Template name. Available options:  * `invite` — text for invitation of the applicant for a vacancy; * `invite_after_response` — text for [invitation after the applicant's response](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state); * `discard_after_response` — text for [rejection after the response](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state); * `discard_after_interview` — text for [rejection after invitation of the applicant for an interview](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state).  Template list may change  (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str topic_id: Negotiation ID. It can't be sent at the same time as other parameters
        :param str vacancy_id: Vacancy ID. It's sent together with the `resume_id` parameter only
        :param str resume_id: Resume ID for job invitation. It's sent together with the `vacancy_id` parameter only
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationMessageTemplates
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiation_message_templates_with_http_info(template, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiation_message_templates_with_http_info(template, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiation_message_templates_with_http_info(self, template, hh_user_agent, **kwargs):  # noqa: E501
        """Template list for the negotiation  # noqa: E501

        The method requires [paid access for the employer](#operation/get-payable-api-method-access).  Returns response templates list for a negotiation or resume. It can be used in invitations sent to the applicant or [negotiation actions](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state).  > The number of available templates will depend on the specific negotiation or vacancy and statuses of the vacancy.  It is recommended to use the URL included in the templates object in the [negotiations list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list) and suitable vacancies. Examples:  ``` GET /message_templates/{template}?topic_id={topic_id} GET /message_templates/{template}?vacancy_id={vacancy_id}&resume_id={resume_id} ```   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_message_templates_with_http_info(template, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str template: Template name. Available options:  * `invite` — text for invitation of the applicant for a vacancy; * `invite_after_response` — text for [invitation after the applicant's response](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state); * `discard_after_response` — text for [rejection after the response](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state); * `discard_after_interview` — text for [rejection after invitation of the applicant for an interview](#tag/Employer-responsesinvitations/operation/put-negotiations-collection-to-next-state).  Template list may change  (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str topic_id: Negotiation ID. It can't be sent at the same time as other parameters
        :param str vacancy_id: Vacancy ID. It's sent together with the `resume_id` parameter only
        :param str resume_id: Resume ID for job invitation. It's sent together with the `vacancy_id` parameter only
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationMessageTemplates
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['template', 'hh_user_agent', 'topic_id', 'vacancy_id', 'resume_id', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiation_message_templates" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'template' is set
        if ('template' not in params or
                params['template'] is None):
            raise ValueError("Missing the required parameter `template` when calling `get_negotiation_message_templates`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiation_message_templates`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'template' in params:
            path_params['template'] = params['template']  # noqa: E501

        query_params = []
        if 'topic_id' in params:
            query_params.append(('topic_id', params['topic_id']))  # noqa: E501
        if 'vacancy_id' in params:
            query_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'resume_id' in params:
            query_params.append(('resume_id', params['resume_id']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/message_templates/{template}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsNegotiationMessageTemplates',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiation_messages(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """View the list of messages in the negotiation  # noqa: E501

        Returns a list of all messages of the selected response/invitation. The employer can view the list by the URL specified in the `messages` field of the [response/invitation list](#tag/Employer-responsesinvitations/operation/get-negotiations) or in a [response](#tag/Employer-responsesinvitations/operation/get-negotiation-item).    Types of messages:  * the applicant's cover letter; * a cover letter from the employer when changing the negotiation status; * free conversation between the applicant and the employer.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_messages(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool with_text_only: Return non-empty messages (contain text in the `text` parameter)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessagesGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiation_messages_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiation_messages_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiation_messages_with_http_info(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """View the list of messages in the negotiation  # noqa: E501

        Returns a list of all messages of the selected response/invitation. The employer can view the list by the URL specified in the `messages` field of the [response/invitation list](#tag/Employer-responsesinvitations/operation/get-negotiations) or in a [response](#tag/Employer-responsesinvitations/operation/get-negotiation-item).    Types of messages:  * the applicant's cover letter; * a cover letter from the employer when changing the negotiation status; * free conversation between the applicant and the employer.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_messages_with_http_info(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param bool with_text_only: Return non-empty messages (contain text in the `text` parameter)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessagesGetResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['nid', 'hh_user_agent', 'with_text_only', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiation_messages" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `get_negotiation_messages`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiation_messages`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'with_text_only' in params:
            query_params.append(('with_text_only', params['with_text_only']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{nid}/messages', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsMessagesGetResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiation_test_results(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """Get test results attached to the vacancy  # noqa: E501

        The request returns information about completed tests of the responded applicant  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_test_results(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationTestResultsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiation_test_results_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiation_test_results_with_http_info(nid, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiation_test_results_with_http_info(self, nid, hh_user_agent, **kwargs):  # noqa: E501
        """Get test results attached to the vacancy  # noqa: E501

        The request returns information about completed tests of the responded applicant  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiation_test_results_with_http_info(nid, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str nid: Negotiation ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationTestResultsResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['nid', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiation_test_results" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `get_negotiation_test_results`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiation_test_results`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{nid}/test/solution', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsNegotiationTestResultsResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiations(self, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation list  # noqa: E501

        Returns the list of the applicant's negotiations or negotiation (responses/invitations) collections to employer's [vacancy](#tag/Vacancy-management/operation/get-active-vacancy-list).  By default, negotiations are sorted by date of change — from new ones to old.  To obtain the list of active negotiations, specify the `?status=active` parameter in the request   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements per page
        :param str order_by: The field to sort the data by. Possible values are specified in the `negotiations_order` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries)
        :param str order: Sort order. Possible values are: `asc`, `desc`. Default — `desc`
        :param str vacancy_id: Filter by a vacancy ID. Required for the employer
        :param str status: The request returns negotiations only in the specified status.  Possible values are specified in the `applicant_negotiation_status` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param bool has_updates: If `true`, the request returns the elements only with unread messages. Default — `false` 
        :param bool with_job_search_status: If `true`, the request returns applicant's job search status 
        :param bool with_generated_collections: If `true`, the request returns information about [responses/invitations collection](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md#term-collection) for the vacancy.  To get uploads across multiple collections, request it one by one. Default — `false` 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiations_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiations_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiations_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation list  # noqa: E501

        Returns the list of the applicant's negotiations or negotiation (responses/invitations) collections to employer's [vacancy](#tag/Vacancy-management/operation/get-active-vacancy-list).  By default, negotiations are sorted by date of change — from new ones to old.  To obtain the list of active negotiations, specify the `?status=active` parameter in the request   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements per page
        :param str order_by: The field to sort the data by. Possible values are specified in the `negotiations_order` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries)
        :param str order: Sort order. Possible values are: `asc`, `desc`. Default — `desc`
        :param str vacancy_id: Filter by a vacancy ID. Required for the employer
        :param str status: The request returns negotiations only in the specified status.  Possible values are specified in the `applicant_negotiation_status` field in [directories of fields](#tag/Public-directories/operation/get-dictionaries) 
        :param bool has_updates: If `true`, the request returns the elements only with unread messages. Default — `false` 
        :param bool with_job_search_status: If `true`, the request returns applicant's job search status 
        :param bool with_generated_collections: If `true`, the request returns information about [responses/invitations collection](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md#term-collection) for the vacancy.  To get uploads across multiple collections, request it one by one. Default — `false` 
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsListResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'page', 'per_page', 'order_by', 'order', 'vacancy_id', 'status', 'has_updates', 'with_job_search_status', 'with_generated_collections', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiations" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiations`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'order_by' in params:
            query_params.append(('order_by', params['order_by']))  # noqa: E501
        if 'order' in params:
            query_params.append(('order', params['order']))  # noqa: E501
        if 'vacancy_id' in params:
            query_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'status' in params:
            query_params.append(('status', params['status']))  # noqa: E501
        if 'has_updates' in params:
            query_params.append(('has_updates', params['has_updates']))  # noqa: E501
        if 'with_job_search_status' in params:
            query_params.append(('with_job_search_status', params['with_job_search_status']))  # noqa: E501
        if 'with_generated_collections' in params:
            query_params.append(('with_generated_collections', params['with_generated_collections']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsListResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiations_statistics_employer(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation statistics for the company  # noqa: E501

        Returns statistics for the vacancies responses/invitations of the company for a period (30 days).  Additionally, the company's [politeness index](https://hh.ru/article/23734) is calculated for all vacancies   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations_statistics_employer(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationsStatisticsEmployerResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiations_statistics_employer_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiations_statistics_employer_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiations_statistics_employer_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation statistics for the company  # noqa: E501

        Returns statistics for the vacancies responses/invitations of the company for a period (30 days).  Additionally, the company's [politeness index](https://hh.ru/article/23734) is calculated for all vacancies   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations_statistics_employer_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationsStatisticsEmployerResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiations_statistics_employer" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_negotiations_statistics_employer`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiations_statistics_employer`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/negotiations_statistics', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsNegotiationsStatisticsEmployerResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_negotiations_statistics_manager(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation statistics for the manager  # noqa: E501

        Returns statistics for the vacancies responses/invitations of the manager for a period (30 days). Manager statistics are available to the manager himself, as well as to managers with the `main_contact_person` [type](#tag/Employer-managers/operation/get-employer-manager-types).  Additionally, the manager's [politeness index](https://hh.ru/article/23734) is calculated for all vacancies   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations_statistics_manager(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str manager_id: Manager ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationsStatisticsManagerResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_negotiations_statistics_manager_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_negotiations_statistics_manager_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_negotiations_statistics_manager_with_http_info(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Negotiation statistics for the manager  # noqa: E501

        Returns statistics for the vacancies responses/invitations of the manager for a period (30 days). Manager statistics are available to the manager himself, as well as to managers with the `main_contact_person` [type](#tag/Employer-managers/operation/get-employer-manager-types).  Additionally, the manager's [politeness index](https://hh.ru/article/23734) is calculated for all vacancies   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_negotiations_statistics_manager_with_http_info(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str manager_id: Manager ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsNegotiationsStatisticsManagerResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'manager_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_negotiations_statistics_manager" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_negotiations_statistics_manager`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `get_negotiations_statistics_manager`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_negotiations_statistics_manager`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers/{manager_id}/negotiations_statistics', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsNegotiationsStatisticsManagerResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_pref_negotiations_order(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Viewing preferred options for sorting responses  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_pref_negotiations_order(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesPreferredNegotiationsOrder
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_pref_negotiations_order_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_pref_negotiations_order_with_http_info(id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_pref_negotiations_order_with_http_info(self, id, hh_user_agent, **kwargs):  # noqa: E501
        """Viewing preferred options for sorting responses  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_pref_negotiations_order_with_http_info(id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str id: Vacancy ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: VacanciesPreferredNegotiationsOrder
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_pref_negotiations_order" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `get_pref_negotiations_order`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_pref_negotiations_order`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{id}/preferred_negotiations_order', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='VacanciesPreferredNegotiationsOrder',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_resume_negotiations_history(self, resume_id, hh_user_agent, **kwargs):  # noqa: E501
        """History of responses/invitations for a resume  # noqa: E501

        The list contains the last actions with the resumes specified: no more than 30 jobs of this employer and no more than 10 status changes in responses/invitations for each of these jobs.  The method requires [paid access for the employer](#tag/Employer-services/operation/get-payable-api-method-access)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_negotiations_history(resume_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesResumeNegotiationsHistoryResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_resume_negotiations_history_with_http_info(resume_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_resume_negotiations_history_with_http_info(resume_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_resume_negotiations_history_with_http_info(self, resume_id, hh_user_agent, **kwargs):  # noqa: E501
        """History of responses/invitations for a resume  # noqa: E501

        The list contains the last actions with the resumes specified: no more than 30 jobs of this employer and no more than 10 status changes in responses/invitations for each of these jobs.  The method requires [paid access for the employer](#tag/Employer-services/operation/get-payable-api-method-access)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_resume_negotiations_history_with_http_info(resume_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str resume_id: Resume ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ResumesResumeNegotiationsHistoryResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['resume_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_resume_negotiations_history" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'resume_id' is set
        if ('resume_id' not in params or
                params['resume_id'] is None):
            raise ValueError("Missing the required parameter `resume_id` when calling `get_resume_negotiations_history`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_resume_negotiations_history`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'resume_id' in params:
            path_params['resume_id'] = params['resume_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/resumes/{resume_id}/negotiations_history', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ResumesResumeNegotiationsHistoryResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def invite_applicant_to_vacancy(self, hh_user_agent, **kwargs):  # noqa: E501
        """Invite applicant for a vacancy  # noqa: E501

        Forms an invitation to a vacancy for an applicant of the employer.  > Instead of `phone_interview`, the parameter `negotiations_actions[].url` must be specified. Possible values are specified in the [list of suitable vacancies](#tag/Vacancy-management/operation/get-active-vacancy-list) by passing arguments from the `negotiations_actions[].arguments` array.  Request example:  ``` POST /negotiations/phone_interview?resume_id=123456&vacancy_id=654321&message=new_msg ```   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.invite_applicant_to_vacancy(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str resume_id:
        :param str vacancy_id:
        :param str message:
        :param bool send_sms:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: str
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.invite_applicant_to_vacancy_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.invite_applicant_to_vacancy_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def invite_applicant_to_vacancy_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Invite applicant for a vacancy  # noqa: E501

        Forms an invitation to a vacancy for an applicant of the employer.  > Instead of `phone_interview`, the parameter `negotiations_actions[].url` must be specified. Possible values are specified in the [list of suitable vacancies](#tag/Vacancy-management/operation/get-active-vacancy-list) by passing arguments from the `negotiations_actions[].arguments` array.  Request example:  ``` POST /negotiations/phone_interview?resume_id=123456&vacancy_id=654321&message=new_msg ```   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.invite_applicant_to_vacancy_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str resume_id:
        :param str vacancy_id:
        :param str message:
        :param bool send_sms:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: str
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'resume_id', 'vacancy_id', 'message', 'send_sms', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method invite_applicant_to_vacancy" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `invite_applicant_to_vacancy`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}
        if 'resume_id' in params:
            form_params.append(('resume_id', params['resume_id']))  # noqa: E501
        if 'vacancy_id' in params:
            form_params.append(('vacancy_id', params['vacancy_id']))  # noqa: E501
        if 'message' in params:
            form_params.append(('message', params['message']))  # noqa: E501
        if 'send_sms' in params:
            form_params.append(('send_sms', params['send_sms']))  # noqa: E501

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['text/html', 'application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/x-www-form-urlencoded'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/phone_interview', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='str',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def post_negotiations_topics_read(self, hh_user_agent, **kwargs):  # noqa: E501
        """Mark responses as read  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.post_negotiations_topics_read(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str topic_id:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.post_negotiations_topics_read_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.post_negotiations_topics_read_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def post_negotiations_topics_read_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Mark responses as read  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.post_negotiations_topics_read_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str topic_id:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'topic_id', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method post_negotiations_topics_read" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `post_negotiations_topics_read`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}
        if 'topic_id' in params:
            form_params.append(('topic_id', params['topic_id']))  # noqa: E501

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/x-www-form-urlencoded'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/read', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def put_mail_templates_item(self, body, hh_user_agent, employer_id, template_id, **kwargs):  # noqa: E501
        """Edit a template for response to an applicant  # noqa: E501

        Editing a response template for [negotiations](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.put_mail_templates_item(body, hh_user_agent, employer_id, template_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param MailTemplatesMailTemplateInput body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str template_id: ID of the template to change, that can be obtained from the [list of available templates for response to an applicant](#tag/Employer-responsesinvitations/operation/get-mail-templates) (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.put_mail_templates_item_with_http_info(body, hh_user_agent, employer_id, template_id, **kwargs)  # noqa: E501
        else:
            (data) = self.put_mail_templates_item_with_http_info(body, hh_user_agent, employer_id, template_id, **kwargs)  # noqa: E501
            return data

    def put_mail_templates_item_with_http_info(self, body, hh_user_agent, employer_id, template_id, **kwargs):  # noqa: E501
        """Edit a template for response to an applicant  # noqa: E501

        Editing a response template for [negotiations](https://github.com/hhru/api/blob/master/docs_eng/employer_negotiations.md)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.put_mail_templates_item_with_http_info(body, hh_user_agent, employer_id, template_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param MailTemplatesMailTemplateInput body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str template_id: ID of the template to change, that can be obtained from the [list of available templates for response to an applicant](#tag/Employer-responsesinvitations/operation/get-mail-templates) (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'hh_user_agent', 'employer_id', 'template_id', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method put_mail_templates_item" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `put_mail_templates_item`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `put_mail_templates_item`")  # noqa: E501
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `put_mail_templates_item`")  # noqa: E501
        # verify the required parameter 'template_id' is set
        if ('template_id' not in params or
                params['template_id'] is None):
            raise ValueError("Missing the required parameter `template_id` when calling `put_mail_templates_item`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'template_id' in params:
            path_params['template_id'] = params['template_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/mail_templates/{template_id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def put_negotiations_collection_to_next_state(self, hh_user_agent, id, **kwargs):  # noqa: E501
        """Actions with responses/invitations  # noqa: E501

        Employer can change the state of responses/invitations in order to improve feedbacks and to facilitate handling of response statistics.  The method changes the state of the response and sends a corresponding message to the applicant.  If the employer use this method to send a message about a change of response/invitation state to an applicant (`message` field in the request body), it also triggers the change of applicant's state of the response/invitation.  Requirements for request body arguments depend on particular response/invitation. You can check requirements in the `actions.arguments` field of [response/invitation list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.put_negotiations_collection_to_next_state(hh_user_agent, id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str id: ID of a [collection](#tag/Employer-responsesinvitations/operation/get-negotiations) where the state of response will be transferred (required)
        :param str topic_id:
        :param str address_id:
        :param str message:
        :param bool send_sms:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.put_negotiations_collection_to_next_state_with_http_info(hh_user_agent, id, **kwargs)  # noqa: E501
        else:
            (data) = self.put_negotiations_collection_to_next_state_with_http_info(hh_user_agent, id, **kwargs)  # noqa: E501
            return data

    def put_negotiations_collection_to_next_state_with_http_info(self, hh_user_agent, id, **kwargs):  # noqa: E501
        """Actions with responses/invitations  # noqa: E501

        Employer can change the state of responses/invitations in order to improve feedbacks and to facilitate handling of response statistics.  The method changes the state of the response and sends a corresponding message to the applicant.  If the employer use this method to send a message about a change of response/invitation state to an applicant (`message` field in the request body), it also triggers the change of applicant's state of the response/invitation.  Requirements for request body arguments depend on particular response/invitation. You can check requirements in the `actions.arguments` field of [response/invitation list](#tag/Employer-responsesinvitations/operation/get-collection-negotiations-list)   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.put_negotiations_collection_to_next_state_with_http_info(hh_user_agent, id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str id: ID of a [collection](#tag/Employer-responsesinvitations/operation/get-negotiations) where the state of response will be transferred (required)
        :param str topic_id:
        :param str address_id:
        :param str message:
        :param bool send_sms:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'id', 'topic_id', 'address_id', 'message', 'send_sms', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method put_negotiations_collection_to_next_state" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `put_negotiations_collection_to_next_state`")  # noqa: E501
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `put_negotiations_collection_to_next_state`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}
        if 'topic_id' in params:
            form_params.append(('topic_id', params['topic_id']))  # noqa: E501
        if 'address_id' in params:
            form_params.append(('address_id', params['address_id']))  # noqa: E501
        if 'message' in params:
            form_params.append(('message', params['message']))  # noqa: E501
        if 'send_sms' in params:
            form_params.append(('send_sms', params['send_sms']))  # noqa: E501

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/x-www-form-urlencoded'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def put_pref_negotiations_order(self, order, hh_user_agent, id, **kwargs):  # noqa: E501
        """Changing preferred options for sorting responses  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.put_pref_negotiations_order(order, hh_user_agent, id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str order: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str id: Vacancy ID (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.put_pref_negotiations_order_with_http_info(order, hh_user_agent, id, **kwargs)  # noqa: E501
        else:
            (data) = self.put_pref_negotiations_order_with_http_info(order, hh_user_agent, id, **kwargs)  # noqa: E501
            return data

    def put_pref_negotiations_order_with_http_info(self, order, hh_user_agent, id, **kwargs):  # noqa: E501
        """Changing preferred options for sorting responses  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.put_pref_negotiations_order_with_http_info(order, hh_user_agent, id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str order: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str id: Vacancy ID (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['order', 'hh_user_agent', 'id', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method put_pref_negotiations_order" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'order' is set
        if ('order' not in params or
                params['order'] is None):
            raise ValueError("Missing the required parameter `order` when calling `put_pref_negotiations_order`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `put_pref_negotiations_order`")  # noqa: E501
        # verify the required parameter 'id' is set
        if ('id' not in params or
                params['id'] is None):
            raise ValueError("Missing the required parameter `id` when calling `put_pref_negotiations_order`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'id' in params:
            path_params['id'] = params['id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}
        if 'order' in params:
            form_params.append(('order', params['order']))  # noqa: E501

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/x-www-form-urlencoded'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/vacancies/{id}/preferred_negotiations_order', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def send_negotiation_message(self, hh_user_agent, nid, **kwargs):  # noqa: E501
        """Sending new message  # noqa: E501

        Sends new negotiation message.  Applicant or employer can send a new message in the following cases:  * The employer invited the applicant for a vacancy. * The applicant left a response to the vacancy.  Negotiation is unavailable if the vacancy is archived or the applicant deleted the resume. Employer can also disable the negotiation for the vacancy manually.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.send_negotiation_message(hh_user_agent, nid, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str nid: Negotiation ID (required)
        :param str message:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessageSent
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.send_negotiation_message_with_http_info(hh_user_agent, nid, **kwargs)  # noqa: E501
        else:
            (data) = self.send_negotiation_message_with_http_info(hh_user_agent, nid, **kwargs)  # noqa: E501
            return data

    def send_negotiation_message_with_http_info(self, hh_user_agent, nid, **kwargs):  # noqa: E501
        """Sending new message  # noqa: E501

        Sends new negotiation message.  Applicant or employer can send a new message in the following cases:  * The employer invited the applicant for a vacancy. * The applicant left a response to the vacancy.  Negotiation is unavailable if the vacancy is archived or the applicant deleted the resume. Employer can also disable the negotiation for the vacancy manually.  ‼️ Please note that the methods for handling response/invitation messages on behalf of the [applicant](#tag/Negotiations-(responsesinvitations)-for-applicants/operation/get-negotiation-messages) and   [employer manager](#tag/Employer-responsesinvitations/operation/get-negotiation-messages) are deprecated and the new chat capabilities will not be supported in these methods. As such, correspondence may not display correctly   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.send_negotiation_message_with_http_info(hh_user_agent, nid, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str nid: Negotiation ID (required)
        :param str message:
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: NegotiationsMessageSent
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'nid', 'message', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method send_negotiation_message" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `send_negotiation_message`")  # noqa: E501
        # verify the required parameter 'nid' is set
        if ('nid' not in params or
                params['nid'] is None):
            raise ValueError("Missing the required parameter `nid` when calling `send_negotiation_message`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'nid' in params:
            path_params['nid'] = params['nid']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}
        if 'message' in params:
            form_params.append(('message', params['message']))  # noqa: E501

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json', 'text/html'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/x-www-form-urlencoded'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/negotiations/{nid}/messages', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='NegotiationsMessageSent',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
