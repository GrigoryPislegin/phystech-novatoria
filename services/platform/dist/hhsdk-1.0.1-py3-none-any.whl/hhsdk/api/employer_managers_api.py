# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

from __future__ import absolute_import

import re  # noqa: F401

# python 2 and python 3 compatibility library
import six

from hhsdk.api_client import ApiClient


class EmployerManagersApi(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    Ref: https://github.com/swagger-api/swagger-codegen
    """

    def __init__(self, api_client=None):
        if api_client is None:
            api_client = ApiClient()
        self.api_client = api_client

    def add_employer_manager(self, body, hh_user_agent, employer_id, **kwargs):  # noqa: E501
        """Adding a manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_employer_manager(body, hh_user_agent, employer_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param EmployerManagersAddEmployerManager body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str employer_id: Employer ID. Use the [info on current authorized user](#tag/Employer-info/operation/get-current-user-info) method to obtain it (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersEmployerManagerId
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.add_employer_manager_with_http_info(body, hh_user_agent, employer_id, **kwargs)  # noqa: E501
        else:
            (data) = self.add_employer_manager_with_http_info(body, hh_user_agent, employer_id, **kwargs)  # noqa: E501
            return data

    def add_employer_manager_with_http_info(self, body, hh_user_agent, employer_id, **kwargs):  # noqa: E501
        """Adding a manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.add_employer_manager_with_http_info(body, hh_user_agent, employer_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param EmployerManagersAddEmployerManager body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str employer_id: Employer ID. Use the [info on current authorized user](#tag/Employer-info/operation/get-current-user-info) method to obtain it (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersEmployerManagerId
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'hh_user_agent', 'employer_id', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method add_employer_manager" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `add_employer_manager`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `add_employer_manager`")  # noqa: E501
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `add_employer_manager`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers', 'POST',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='EmployerManagersEmployerManagerId',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def delete_employer_manager(self, employer_id, manager_id, successor_id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting a manager  # noqa: E501

        Deleting a manager takes a while. This is why if you request a list of managers immediately after successfully deleting a manager the response may include the deleted manager  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_employer_manager(employer_id, manager_id, successor_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str successor_id: ID of the manager who receives all data related to the deleted manager, in particular: vacancies, applications, files with selected resumes, comments on candidates, automatic searches, etc (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.delete_employer_manager_with_http_info(employer_id, manager_id, successor_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.delete_employer_manager_with_http_info(employer_id, manager_id, successor_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def delete_employer_manager_with_http_info(self, employer_id, manager_id, successor_id, hh_user_agent, **kwargs):  # noqa: E501
        """Deleting a manager  # noqa: E501

        Deleting a manager takes a while. This is why if you request a list of managers immediately after successfully deleting a manager the response may include the deleted manager  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.delete_employer_manager_with_http_info(employer_id, manager_id, successor_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str successor_id: ID of the manager who receives all data related to the deleted manager, in particular: vacancies, applications, files with selected resumes, comments on candidates, automatic searches, etc (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'manager_id', 'successor_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method delete_employer_manager" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `delete_employer_manager`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `delete_employer_manager`")  # noqa: E501
        # verify the required parameter 'successor_id' is set
        if ('successor_id' not in params or
                params['successor_id'] is None):
            raise ValueError("Missing the required parameter `successor_id` when calling `delete_employer_manager`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `delete_employer_manager`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'successor_id' in params:
            query_params.append(('successor_id', params['successor_id']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers/{manager_id}', 'DELETE',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def edit_employer_manager(self, body, hh_user_agent, employer_id, manager_id, **kwargs):  # noqa: E501
        """Editing a manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.edit_employer_manager(body, hh_user_agent, employer_id, manager_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param EmployerManagersManagerData body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str employer_id: The employer's ID that can be found in the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.edit_employer_manager_with_http_info(body, hh_user_agent, employer_id, manager_id, **kwargs)  # noqa: E501
        else:
            (data) = self.edit_employer_manager_with_http_info(body, hh_user_agent, employer_id, manager_id, **kwargs)  # noqa: E501
            return data

    def edit_employer_manager_with_http_info(self, body, hh_user_agent, employer_id, manager_id, **kwargs):  # noqa: E501
        """Editing a manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.edit_employer_manager_with_http_info(body, hh_user_agent, employer_id, manager_id, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param EmployerManagersManagerData body: (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str employer_id: The employer's ID that can be found in the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: None
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['body', 'hh_user_agent', 'employer_id', 'manager_id', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method edit_employer_manager" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'body' is set
        if ('body' not in params or
                params['body'] is None):
            raise ValueError("Missing the required parameter `body` when calling `edit_employer_manager`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `edit_employer_manager`")  # noqa: E501
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `edit_employer_manager`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `edit_employer_manager`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        if 'body' in params:
            body_params = params['body']
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # HTTP header `Content-Type`
        header_params['Content-Type'] = self.api_client.select_header_content_type(  # noqa: E501
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers/{manager_id}', 'PUT',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type=None,  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_employer_manager(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Getting information about a manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_manager(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersEmployerManagerInfo
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_employer_manager_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_employer_manager_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_employer_manager_with_http_info(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Getting information about a manager  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_manager_with_http_info(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersEmployerManagerInfo
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'manager_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_employer_manager" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_employer_manager`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `get_employer_manager`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_employer_manager`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers/{manager_id}', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='EmployerManagersEmployerManagerInfo',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_employer_manager_limits(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Daily limit of resume views for current manager  # noqa: E501

        This method is only available to a manager with the purpose of daily limit view  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_manager_limits(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, which you can find in [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID, which you can find in [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersEmployerManagerLimits
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_employer_manager_limits_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_employer_manager_limits_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_employer_manager_limits_with_http_info(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Daily limit of resume views for current manager  # noqa: E501

        This method is only available to a manager with the purpose of daily limit view  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_manager_limits_with_http_info(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, which you can find in [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID, which you can find in [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersEmployerManagerLimits
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'manager_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_employer_manager_limits" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_employer_manager_limits`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `get_employer_manager_limits`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_employer_manager_limits`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers/{manager_id}/limits/resume', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='EmployerManagersEmployerManagerLimits',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_employer_manager_types(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Directory of manager types and privileges  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_manager_types(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagerTypesResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_employer_manager_types_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_employer_manager_types_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_employer_manager_types_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Directory of manager types and privileges  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_manager_types_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagerTypesResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_employer_manager_types" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_employer_manager_types`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_employer_manager_types`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/manager_types', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='EmployerManagerTypesResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_employer_managers(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Directory of employer's managers  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_managers(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: The employer's ID that can be found in the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements
        :param str search_text: Search string by manager's name
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_employer_managers_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_employer_managers_with_http_info(employer_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_employer_managers_with_http_info(self, employer_id, hh_user_agent, **kwargs):  # noqa: E501
        """Directory of employer's managers  # noqa: E501

        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_employer_managers_with_http_info(employer_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: The employer's ID that can be found in the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param float page: Page number
        :param float per_page: Number of elements
        :param str search_text: Search string by manager's name
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: EmployerManagersResponse
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'hh_user_agent', 'page', 'per_page', 'search_text', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_employer_managers" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_employer_managers`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_employer_managers`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501

        query_params = []
        if 'page' in params:
            query_params.append(('page', params['page']))  # noqa: E501
        if 'per_page' in params:
            query_params.append(('per_page', params['per_page']))  # noqa: E501
        if 'search_text' in params:
            query_params.append(('search_text', params['search_text']))  # noqa: E501
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='EmployerManagersResponse',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_manager_accounts(self, hh_user_agent, **kwargs):  # noqa: E501
        """Manager's work accounts  # noqa: E501

        Returns a list of the manager's work accounts and information about the primary and current account.  To use a certain account, you need to pass the account_id value obtained from the list in the header:  `X-Manager-Account-Id: {account_id}`  You can use this header in all methods available to employers.  In the header, you can pass the account_id of the primary account, which is also implied by default if there is no header   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_manager_accounts(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ManagerAccounts
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_manager_accounts_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_manager_accounts_with_http_info(hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_manager_accounts_with_http_info(self, hh_user_agent, **kwargs):  # noqa: E501
        """Manager's work accounts  # noqa: E501

        Returns a list of the manager's work accounts and information about the primary and current account.  To use a certain account, you need to pass the account_id value obtained from the list in the header:  `X-Manager-Account-Id: {account_id}`  You can use this header in all methods available to employers.  In the header, you can pass the account_id of the primary account, which is also implied by default if there is no header   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_manager_accounts_with_http_info(hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ManagerAccounts
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_manager_accounts" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_manager_accounts`")  # noqa: E501

        collection_formats = {}

        path_params = {}

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/manager_accounts/mine', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ManagerAccounts',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)

    def get_manager_settings(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Manager preferences  # noqa: E501

        Returns information about the manager preferences.  The easiest way to get the URL is from the `manager_settings_url` field of the `manager` object in the [current user information](#tag/Employer-info/operation/get-current-user-info).  Manager preferences *do not affect* actions in the default API. For instance, the branded layout template (`default_vacancy_branded_template`) will not automatically be applied when the vacancy is published if the template has not been passed. The application can use this information to implement field pre-fill logic   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_manager_settings(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ManagerSettings
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.get_manager_settings_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
        else:
            (data) = self.get_manager_settings_with_http_info(employer_id, manager_id, hh_user_agent, **kwargs)  # noqa: E501
            return data

    def get_manager_settings_with_http_info(self, employer_id, manager_id, hh_user_agent, **kwargs):  # noqa: E501
        """Manager preferences  # noqa: E501

        Returns information about the manager preferences.  The easiest way to get the URL is from the `manager_settings_url` field of the `manager` object in the [current user information](#tag/Employer-info/operation/get-current-user-info).  Manager preferences *do not affect* actions in the default API. For instance, the branded layout template (`default_vacancy_branded_template`) will not automatically be applied when the vacancy is published if the template has not been passed. The application can use this information to implement field pre-fill logic   # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.get_manager_settings_with_http_info(employer_id, manager_id, hh_user_agent, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str employer_id: Employer ID, that can be obtained from the [information on the current user](#tag/Employer-info/operation/get-current-user-info) (required)
        :param str manager_id: Manager ID from the [directory of employer's managers](#tag/Employer-managers/operation/get-employer-managers) (required)
        :param str hh_user_agent: Application name and developer's contact email (see [Information about user agent](#section/General-information/Request-requirements))  (required)
        :param str locale: Locale identifier ([List of locales](#tag/Public-directories/operation/get-locales)) 
        :param str host: Domain ([Choosing the domain](#section/General-information/Host-selection)) 
        :return: ManagerSettings
                 If the method is called asynchronously,
                 returns the request thread.
        """

        all_params = ['employer_id', 'manager_id', 'hh_user_agent', 'locale', 'host']  # noqa: E501
        all_params.append('async_req')
        all_params.append('_return_http_data_only')
        all_params.append('_preload_content')
        all_params.append('_request_timeout')

        params = locals()
        for key, val in six.iteritems(params['kwargs']):
            if key not in all_params:
                raise TypeError(
                    "Got an unexpected keyword argument '%s'"
                    " to method get_manager_settings" % key
                )
            params[key] = val
        del params['kwargs']
        # verify the required parameter 'employer_id' is set
        if ('employer_id' not in params or
                params['employer_id'] is None):
            raise ValueError("Missing the required parameter `employer_id` when calling `get_manager_settings`")  # noqa: E501
        # verify the required parameter 'manager_id' is set
        if ('manager_id' not in params or
                params['manager_id'] is None):
            raise ValueError("Missing the required parameter `manager_id` when calling `get_manager_settings`")  # noqa: E501
        # verify the required parameter 'hh_user_agent' is set
        if ('hh_user_agent' not in params or
                params['hh_user_agent'] is None):
            raise ValueError("Missing the required parameter `hh_user_agent` when calling `get_manager_settings`")  # noqa: E501

        collection_formats = {}

        path_params = {}
        if 'employer_id' in params:
            path_params['employer_id'] = params['employer_id']  # noqa: E501
        if 'manager_id' in params:
            path_params['manager_id'] = params['manager_id']  # noqa: E501

        query_params = []
        if 'locale' in params:
            query_params.append(('locale', params['locale']))  # noqa: E501
        if 'host' in params:
            query_params.append(('host', params['host']))  # noqa: E501

        header_params = {}
        if 'hh_user_agent' in params:
            header_params['HH-User-Agent'] = params['hh_user_agent']  # noqa: E501

        form_params = []
        local_var_files = {}

        body_params = None
        # HTTP header `Accept`
        header_params['Accept'] = self.api_client.select_header_accept(
            ['application/json'])  # noqa: E501

        # Authentication setting
        auth_settings = ['OauthToken']  # noqa: E501

        return self.api_client.call_api(
            '/employers/{employer_id}/managers/{manager_id}/settings', 'GET',
            path_params,
            query_params,
            header_params,
            body=body_params,
            post_params=form_params,
            files=local_var_files,
            response_type='ManagerSettings',  # noqa: E501
            auth_settings=auth_settings,
            async_req=params.get('async_req'),
            _return_http_data_only=params.get('_return_http_data_only'),
            _preload_content=params.get('_preload_content', True),
            _request_timeout=params.get('_request_timeout'),
            collection_formats=collection_formats)
