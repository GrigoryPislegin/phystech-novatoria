# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

import pprint
import re  # noqa: F401

import six

class DictionariesDictResponse(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    """
    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'applicant_comment_access_type': 'list[IncludesIdName]',
        'applicant_comments_order': 'list[IncludesIdName]',
        'applicant_negotiation_status': 'list[IncludesIdName]',
        'business_trip_readiness': 'list[IncludesIdName]',
        'currency': 'list[DictionariesCurrencyItem]',
        'driver_license_types': 'list[IncludesId]',
        'education_level': 'list[IncludesIdName]',
        'employer_active_vacancies_order': 'list[IncludesIdName]',
        'employer_archived_vacancies_order': 'list[IncludesIdName]',
        'employer_hidden_vacancies_order': 'list[IncludesIdName]',
        'employer_relation': 'list[IncludesIdName]',
        'employer_type': 'list[IncludesIdName]',
        'employment': 'list[IncludesIdName]',
        'employment_form': 'list[IncludesIdName]',
        'experience': 'list[IncludesIdName]',
        'fly_in_fly_out_duration': 'list[IncludesIdName]',
        'gender': 'list[IncludesIdName]',
        'job_search_statuses_applicant': 'list[IncludesIdName]',
        'job_search_statuses_employer': 'list[IncludesIdName]',
        'language_level': 'list[IncludesIdName]',
        'messaging_status': 'list[IncludesIdName]',
        'negotiations_order': 'list[IncludesIdName]',
        'negotiations_participant_type': 'list[IncludesIdName]',
        'negotiations_state': 'list[IncludesIdName]',
        'phone_call_status': 'list[IncludesIdName]',
        'preferred_contact_type': 'list[IncludesIdName]',
        'relocation_type': 'list[IncludesIdName]',
        'resume_access_type': 'list[IncludesIdName]',
        'resume_contacts_site_type': 'list[IncludesIdName]',
        'resume_hidden_fields': 'list[IncludesIdName]',
        'resume_moderation_note': 'list[IncludesIdName]',
        'resume_search_experience_period': 'list[IncludesIdName]',
        'resume_search_fields': 'list[IncludesIdName]',
        'resume_search_label': 'list[IncludesIdName]',
        'resume_search_logic': 'list[IncludesIdName]',
        'resume_search_order': 'list[IncludesIdName]',
        'resume_search_relocation': 'list[IncludesIdName]',
        'resume_status': 'list[IncludesIdName]',
        'schedule': 'list[IncludesIdNameUid]',
        'travel_time': 'list[IncludesIdName]',
        'vacancy_billing_type': 'list[IncludesIdName]',
        'vacancy_cluster': 'list[IncludesIdName]',
        'vacancy_label': 'list[IncludesIdName]',
        'vacancy_not_prolonged_reason': 'list[IncludesIdName]',
        'vacancy_relation': 'list[IncludesIdName]',
        'vacancy_search_fields': 'list[IncludesIdName]',
        'vacancy_search_order': 'list[IncludesIdName]',
        'vacancy_type': 'list[IncludesIdName]',
        'work_format': 'list[IncludesIdName]',
        'work_schedule_by_days': 'list[IncludesIdName]',
        'working_days': 'list[IncludesIdName]',
        'working_hours': 'list[IncludesIdName]',
        'working_time_intervals': 'list[IncludesIdName]',
        'working_time_modes': 'list[IncludesIdName]'
    }

    attribute_map = {
        'applicant_comment_access_type': 'applicant_comment_access_type',
        'applicant_comments_order': 'applicant_comments_order',
        'applicant_negotiation_status': 'applicant_negotiation_status',
        'business_trip_readiness': 'business_trip_readiness',
        'currency': 'currency',
        'driver_license_types': 'driver_license_types',
        'education_level': 'education_level',
        'employer_active_vacancies_order': 'employer_active_vacancies_order',
        'employer_archived_vacancies_order': 'employer_archived_vacancies_order',
        'employer_hidden_vacancies_order': 'employer_hidden_vacancies_order',
        'employer_relation': 'employer_relation',
        'employer_type': 'employer_type',
        'employment': 'employment',
        'employment_form': 'employment_form',
        'experience': 'experience',
        'fly_in_fly_out_duration': 'fly_in_fly_out_duration',
        'gender': 'gender',
        'job_search_statuses_applicant': 'job_search_statuses_applicant',
        'job_search_statuses_employer': 'job_search_statuses_employer',
        'language_level': 'language_level',
        'messaging_status': 'messaging_status',
        'negotiations_order': 'negotiations_order',
        'negotiations_participant_type': 'negotiations_participant_type',
        'negotiations_state': 'negotiations_state',
        'phone_call_status': 'phone_call_status',
        'preferred_contact_type': 'preferred_contact_type',
        'relocation_type': 'relocation_type',
        'resume_access_type': 'resume_access_type',
        'resume_contacts_site_type': 'resume_contacts_site_type',
        'resume_hidden_fields': 'resume_hidden_fields',
        'resume_moderation_note': 'resume_moderation_note',
        'resume_search_experience_period': 'resume_search_experience_period',
        'resume_search_fields': 'resume_search_fields',
        'resume_search_label': 'resume_search_label',
        'resume_search_logic': 'resume_search_logic',
        'resume_search_order': 'resume_search_order',
        'resume_search_relocation': 'resume_search_relocation',
        'resume_status': 'resume_status',
        'schedule': 'schedule',
        'travel_time': 'travel_time',
        'vacancy_billing_type': 'vacancy_billing_type',
        'vacancy_cluster': 'vacancy_cluster',
        'vacancy_label': 'vacancy_label',
        'vacancy_not_prolonged_reason': 'vacancy_not_prolonged_reason',
        'vacancy_relation': 'vacancy_relation',
        'vacancy_search_fields': 'vacancy_search_fields',
        'vacancy_search_order': 'vacancy_search_order',
        'vacancy_type': 'vacancy_type',
        'work_format': 'work_format',
        'work_schedule_by_days': 'work_schedule_by_days',
        'working_days': 'working_days',
        'working_hours': 'working_hours',
        'working_time_intervals': 'working_time_intervals',
        'working_time_modes': 'working_time_modes'
    }

    def __init__(self, applicant_comment_access_type=None, applicant_comments_order=None, applicant_negotiation_status=None, business_trip_readiness=None, currency=None, driver_license_types=None, education_level=None, employer_active_vacancies_order=None, employer_archived_vacancies_order=None, employer_hidden_vacancies_order=None, employer_relation=None, employer_type=None, employment=None, employment_form=None, experience=None, fly_in_fly_out_duration=None, gender=None, job_search_statuses_applicant=None, job_search_statuses_employer=None, language_level=None, messaging_status=None, negotiations_order=None, negotiations_participant_type=None, negotiations_state=None, phone_call_status=None, preferred_contact_type=None, relocation_type=None, resume_access_type=None, resume_contacts_site_type=None, resume_hidden_fields=None, resume_moderation_note=None, resume_search_experience_period=None, resume_search_fields=None, resume_search_label=None, resume_search_logic=None, resume_search_order=None, resume_search_relocation=None, resume_status=None, schedule=None, travel_time=None, vacancy_billing_type=None, vacancy_cluster=None, vacancy_label=None, vacancy_not_prolonged_reason=None, vacancy_relation=None, vacancy_search_fields=None, vacancy_search_order=None, vacancy_type=None, work_format=None, work_schedule_by_days=None, working_days=None, working_hours=None, working_time_intervals=None, working_time_modes=None):  # noqa: E501
        """DictionariesDictResponse - a model defined in Swagger"""  # noqa: E501
        self._applicant_comment_access_type = None
        self._applicant_comments_order = None
        self._applicant_negotiation_status = None
        self._business_trip_readiness = None
        self._currency = None
        self._driver_license_types = None
        self._education_level = None
        self._employer_active_vacancies_order = None
        self._employer_archived_vacancies_order = None
        self._employer_hidden_vacancies_order = None
        self._employer_relation = None
        self._employer_type = None
        self._employment = None
        self._employment_form = None
        self._experience = None
        self._fly_in_fly_out_duration = None
        self._gender = None
        self._job_search_statuses_applicant = None
        self._job_search_statuses_employer = None
        self._language_level = None
        self._messaging_status = None
        self._negotiations_order = None
        self._negotiations_participant_type = None
        self._negotiations_state = None
        self._phone_call_status = None
        self._preferred_contact_type = None
        self._relocation_type = None
        self._resume_access_type = None
        self._resume_contacts_site_type = None
        self._resume_hidden_fields = None
        self._resume_moderation_note = None
        self._resume_search_experience_period = None
        self._resume_search_fields = None
        self._resume_search_label = None
        self._resume_search_logic = None
        self._resume_search_order = None
        self._resume_search_relocation = None
        self._resume_status = None
        self._schedule = None
        self._travel_time = None
        self._vacancy_billing_type = None
        self._vacancy_cluster = None
        self._vacancy_label = None
        self._vacancy_not_prolonged_reason = None
        self._vacancy_relation = None
        self._vacancy_search_fields = None
        self._vacancy_search_order = None
        self._vacancy_type = None
        self._work_format = None
        self._work_schedule_by_days = None
        self._working_days = None
        self._working_hours = None
        self._working_time_intervals = None
        self._working_time_modes = None
        self.discriminator = None
        self.applicant_comment_access_type = applicant_comment_access_type
        self.applicant_comments_order = applicant_comments_order
        self.applicant_negotiation_status = applicant_negotiation_status
        self.business_trip_readiness = business_trip_readiness
        self.currency = currency
        self.driver_license_types = driver_license_types
        self.education_level = education_level
        self.employer_active_vacancies_order = employer_active_vacancies_order
        self.employer_archived_vacancies_order = employer_archived_vacancies_order
        if employer_hidden_vacancies_order is not None:
            self.employer_hidden_vacancies_order = employer_hidden_vacancies_order
        self.employer_relation = employer_relation
        self.employer_type = employer_type
        self.employment = employment
        if employment_form is not None:
            self.employment_form = employment_form
        self.experience = experience
        if fly_in_fly_out_duration is not None:
            self.fly_in_fly_out_duration = fly_in_fly_out_duration
        self.gender = gender
        self.job_search_statuses_applicant = job_search_statuses_applicant
        self.job_search_statuses_employer = job_search_statuses_employer
        self.language_level = language_level
        self.messaging_status = messaging_status
        self.negotiations_order = negotiations_order
        self.negotiations_participant_type = negotiations_participant_type
        self.negotiations_state = negotiations_state
        self.phone_call_status = phone_call_status
        self.preferred_contact_type = preferred_contact_type
        self.relocation_type = relocation_type
        self.resume_access_type = resume_access_type
        self.resume_contacts_site_type = resume_contacts_site_type
        self.resume_hidden_fields = resume_hidden_fields
        self.resume_moderation_note = resume_moderation_note
        if resume_search_experience_period is not None:
            self.resume_search_experience_period = resume_search_experience_period
        if resume_search_fields is not None:
            self.resume_search_fields = resume_search_fields
        if resume_search_label is not None:
            self.resume_search_label = resume_search_label
        if resume_search_logic is not None:
            self.resume_search_logic = resume_search_logic
        if resume_search_order is not None:
            self.resume_search_order = resume_search_order
        if resume_search_relocation is not None:
            self.resume_search_relocation = resume_search_relocation
        self.resume_status = resume_status
        self.schedule = schedule
        self.travel_time = travel_time
        self.vacancy_billing_type = vacancy_billing_type
        self.vacancy_cluster = vacancy_cluster
        self.vacancy_label = vacancy_label
        self.vacancy_not_prolonged_reason = vacancy_not_prolonged_reason
        self.vacancy_relation = vacancy_relation
        self.vacancy_search_fields = vacancy_search_fields
        self.vacancy_search_order = vacancy_search_order
        self.vacancy_type = vacancy_type
        if work_format is not None:
            self.work_format = work_format
        if work_schedule_by_days is not None:
            self.work_schedule_by_days = work_schedule_by_days
        self.working_days = working_days
        if working_hours is not None:
            self.working_hours = working_hours
        self.working_time_intervals = working_time_intervals
        self.working_time_modes = working_time_modes

    @property
    def applicant_comment_access_type(self):
        """Gets the applicant_comment_access_type of this DictionariesDictResponse.  # noqa: E501

        Type of access to applicant comment  # noqa: E501

        :return: The applicant_comment_access_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._applicant_comment_access_type

    @applicant_comment_access_type.setter
    def applicant_comment_access_type(self, applicant_comment_access_type):
        """Sets the applicant_comment_access_type of this DictionariesDictResponse.

        Type of access to applicant comment  # noqa: E501

        :param applicant_comment_access_type: The applicant_comment_access_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if applicant_comment_access_type is None:
            raise ValueError("Invalid value for `applicant_comment_access_type`, must not be `None`")  # noqa: E501

        self._applicant_comment_access_type = applicant_comment_access_type

    @property
    def applicant_comments_order(self):
        """Gets the applicant_comments_order of this DictionariesDictResponse.  # noqa: E501

        Sorting type of the [applicant comment list](#tag/Applicant-comments/operation/get-applicant-comments-list)  # noqa: E501

        :return: The applicant_comments_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._applicant_comments_order

    @applicant_comments_order.setter
    def applicant_comments_order(self, applicant_comments_order):
        """Sets the applicant_comments_order of this DictionariesDictResponse.

        Sorting type of the [applicant comment list](#tag/Applicant-comments/operation/get-applicant-comments-list)  # noqa: E501

        :param applicant_comments_order: The applicant_comments_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if applicant_comments_order is None:
            raise ValueError("Invalid value for `applicant_comments_order`, must not be `None`")  # noqa: E501

        self._applicant_comments_order = applicant_comments_order

    @property
    def applicant_negotiation_status(self):
        """Gets the applicant_negotiation_status of this DictionariesDictResponse.  # noqa: E501

        Response/invite statuses  # noqa: E501

        :return: The applicant_negotiation_status of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._applicant_negotiation_status

    @applicant_negotiation_status.setter
    def applicant_negotiation_status(self, applicant_negotiation_status):
        """Sets the applicant_negotiation_status of this DictionariesDictResponse.

        Response/invite statuses  # noqa: E501

        :param applicant_negotiation_status: The applicant_negotiation_status of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if applicant_negotiation_status is None:
            raise ValueError("Invalid value for `applicant_negotiation_status`, must not be `None`")  # noqa: E501

        self._applicant_negotiation_status = applicant_negotiation_status

    @property
    def business_trip_readiness(self):
        """Gets the business_trip_readiness of this DictionariesDictResponse.  # noqa: E501

        Willingness to business trips  # noqa: E501

        :return: The business_trip_readiness of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._business_trip_readiness

    @business_trip_readiness.setter
    def business_trip_readiness(self, business_trip_readiness):
        """Sets the business_trip_readiness of this DictionariesDictResponse.

        Willingness to business trips  # noqa: E501

        :param business_trip_readiness: The business_trip_readiness of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if business_trip_readiness is None:
            raise ValueError("Invalid value for `business_trip_readiness`, must not be `None`")  # noqa: E501

        self._business_trip_readiness = business_trip_readiness

    @property
    def currency(self):
        """Gets the currency of this DictionariesDictResponse.  # noqa: E501

        Currency directory  # noqa: E501

        :return: The currency of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[DictionariesCurrencyItem]
        """
        return self._currency

    @currency.setter
    def currency(self, currency):
        """Sets the currency of this DictionariesDictResponse.

        Currency directory  # noqa: E501

        :param currency: The currency of this DictionariesDictResponse.  # noqa: E501
        :type: list[DictionariesCurrencyItem]
        """
        if currency is None:
            raise ValueError("Invalid value for `currency`, must not be `None`")  # noqa: E501

        self._currency = currency

    @property
    def driver_license_types(self):
        """Gets the driver_license_types of this DictionariesDictResponse.  # noqa: E501

        Driver license types  # noqa: E501

        :return: The driver_license_types of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesId]
        """
        return self._driver_license_types

    @driver_license_types.setter
    def driver_license_types(self, driver_license_types):
        """Sets the driver_license_types of this DictionariesDictResponse.

        Driver license types  # noqa: E501

        :param driver_license_types: The driver_license_types of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesId]
        """
        if driver_license_types is None:
            raise ValueError("Invalid value for `driver_license_types`, must not be `None`")  # noqa: E501

        self._driver_license_types = driver_license_types

    @property
    def education_level(self):
        """Gets the education_level of this DictionariesDictResponse.  # noqa: E501

        Education  # noqa: E501

        :return: The education_level of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._education_level

    @education_level.setter
    def education_level(self, education_level):
        """Sets the education_level of this DictionariesDictResponse.

        Education  # noqa: E501

        :param education_level: The education_level of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if education_level is None:
            raise ValueError("Invalid value for `education_level`, must not be `None`")  # noqa: E501

        self._education_level = education_level

    @property
    def employer_active_vacancies_order(self):
        """Gets the employer_active_vacancies_order of this DictionariesDictResponse.  # noqa: E501

        Sorting type of the published vacancy list  # noqa: E501

        :return: The employer_active_vacancies_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employer_active_vacancies_order

    @employer_active_vacancies_order.setter
    def employer_active_vacancies_order(self, employer_active_vacancies_order):
        """Sets the employer_active_vacancies_order of this DictionariesDictResponse.

        Sorting type of the published vacancy list  # noqa: E501

        :param employer_active_vacancies_order: The employer_active_vacancies_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if employer_active_vacancies_order is None:
            raise ValueError("Invalid value for `employer_active_vacancies_order`, must not be `None`")  # noqa: E501

        self._employer_active_vacancies_order = employer_active_vacancies_order

    @property
    def employer_archived_vacancies_order(self):
        """Gets the employer_archived_vacancies_order of this DictionariesDictResponse.  # noqa: E501

        Sorting type of the archived vacancy list  # noqa: E501

        :return: The employer_archived_vacancies_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employer_archived_vacancies_order

    @employer_archived_vacancies_order.setter
    def employer_archived_vacancies_order(self, employer_archived_vacancies_order):
        """Sets the employer_archived_vacancies_order of this DictionariesDictResponse.

        Sorting type of the archived vacancy list  # noqa: E501

        :param employer_archived_vacancies_order: The employer_archived_vacancies_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if employer_archived_vacancies_order is None:
            raise ValueError("Invalid value for `employer_archived_vacancies_order`, must not be `None`")  # noqa: E501

        self._employer_archived_vacancies_order = employer_archived_vacancies_order

    @property
    def employer_hidden_vacancies_order(self):
        """Gets the employer_hidden_vacancies_order of this DictionariesDictResponse.  # noqa: E501

        Sorting type of the hidden vacancy list  # noqa: E501

        :return: The employer_hidden_vacancies_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employer_hidden_vacancies_order

    @employer_hidden_vacancies_order.setter
    def employer_hidden_vacancies_order(self, employer_hidden_vacancies_order):
        """Sets the employer_hidden_vacancies_order of this DictionariesDictResponse.

        Sorting type of the hidden vacancy list  # noqa: E501

        :param employer_hidden_vacancies_order: The employer_hidden_vacancies_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._employer_hidden_vacancies_order = employer_hidden_vacancies_order

    @property
    def employer_relation(self):
        """Gets the employer_relation of this DictionariesDictResponse.  # noqa: E501

        Methods of contacting applicants  # noqa: E501

        :return: The employer_relation of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employer_relation

    @employer_relation.setter
    def employer_relation(self, employer_relation):
        """Sets the employer_relation of this DictionariesDictResponse.

        Methods of contacting applicants  # noqa: E501

        :param employer_relation: The employer_relation of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if employer_relation is None:
            raise ValueError("Invalid value for `employer_relation`, must not be `None`")  # noqa: E501

        self._employer_relation = employer_relation

    @property
    def employer_type(self):
        """Gets the employer_type of this DictionariesDictResponse.  # noqa: E501

        Employer type  # noqa: E501

        :return: The employer_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employer_type

    @employer_type.setter
    def employer_type(self, employer_type):
        """Sets the employer_type of this DictionariesDictResponse.

        Employer type  # noqa: E501

        :param employer_type: The employer_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if employer_type is None:
            raise ValueError("Invalid value for `employer_type`, must not be `None`")  # noqa: E501

        self._employer_type = employer_type

    @property
    def employment(self):
        """Gets the employment of this DictionariesDictResponse.  # noqa: E501

        Employment type  # noqa: E501

        :return: The employment of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employment

    @employment.setter
    def employment(self, employment):
        """Sets the employment of this DictionariesDictResponse.

        Employment type  # noqa: E501

        :param employment: The employment of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if employment is None:
            raise ValueError("Invalid value for `employment`, must not be `None`")  # noqa: E501

        self._employment = employment

    @property
    def employment_form(self):
        """Gets the employment_form of this DictionariesDictResponse.  # noqa: E501

        Employment type. Use for vacancy and draft field - employment_form  # noqa: E501

        :return: The employment_form of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._employment_form

    @employment_form.setter
    def employment_form(self, employment_form):
        """Sets the employment_form of this DictionariesDictResponse.

        Employment type. Use for vacancy and draft field - employment_form  # noqa: E501

        :param employment_form: The employment_form of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._employment_form = employment_form

    @property
    def experience(self):
        """Gets the experience of this DictionariesDictResponse.  # noqa: E501

        Work experience  # noqa: E501

        :return: The experience of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._experience

    @experience.setter
    def experience(self, experience):
        """Sets the experience of this DictionariesDictResponse.

        Work experience  # noqa: E501

        :param experience: The experience of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if experience is None:
            raise ValueError("Invalid value for `experience`, must not be `None`")  # noqa: E501

        self._experience = experience

    @property
    def fly_in_fly_out_duration(self):
        """Gets the fly_in_fly_out_duration of this DictionariesDictResponse.  # noqa: E501

        Fly in fly out duration. Use for vacancy and draft field - fly_in_fly_out_duration  # noqa: E501

        :return: The fly_in_fly_out_duration of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._fly_in_fly_out_duration

    @fly_in_fly_out_duration.setter
    def fly_in_fly_out_duration(self, fly_in_fly_out_duration):
        """Sets the fly_in_fly_out_duration of this DictionariesDictResponse.

        Fly in fly out duration. Use for vacancy and draft field - fly_in_fly_out_duration  # noqa: E501

        :param fly_in_fly_out_duration: The fly_in_fly_out_duration of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._fly_in_fly_out_duration = fly_in_fly_out_duration

    @property
    def gender(self):
        """Gets the gender of this DictionariesDictResponse.  # noqa: E501

        Gender  # noqa: E501

        :return: The gender of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._gender

    @gender.setter
    def gender(self, gender):
        """Sets the gender of this DictionariesDictResponse.

        Gender  # noqa: E501

        :param gender: The gender of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if gender is None:
            raise ValueError("Invalid value for `gender`, must not be `None`")  # noqa: E501

        self._gender = gender

    @property
    def job_search_statuses_applicant(self):
        """Gets the job_search_statuses_applicant of this DictionariesDictResponse.  # noqa: E501

        Applicant job search statuses for changing or displaying to applicant himself  # noqa: E501

        :return: The job_search_statuses_applicant of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._job_search_statuses_applicant

    @job_search_statuses_applicant.setter
    def job_search_statuses_applicant(self, job_search_statuses_applicant):
        """Sets the job_search_statuses_applicant of this DictionariesDictResponse.

        Applicant job search statuses for changing or displaying to applicant himself  # noqa: E501

        :param job_search_statuses_applicant: The job_search_statuses_applicant of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if job_search_statuses_applicant is None:
            raise ValueError("Invalid value for `job_search_statuses_applicant`, must not be `None`")  # noqa: E501

        self._job_search_statuses_applicant = job_search_statuses_applicant

    @property
    def job_search_statuses_employer(self):
        """Gets the job_search_statuses_employer of this DictionariesDictResponse.  # noqa: E501

        Applicant job search statuses for displaying to employer  # noqa: E501

        :return: The job_search_statuses_employer of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._job_search_statuses_employer

    @job_search_statuses_employer.setter
    def job_search_statuses_employer(self, job_search_statuses_employer):
        """Sets the job_search_statuses_employer of this DictionariesDictResponse.

        Applicant job search statuses for displaying to employer  # noqa: E501

        :param job_search_statuses_employer: The job_search_statuses_employer of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if job_search_statuses_employer is None:
            raise ValueError("Invalid value for `job_search_statuses_employer`, must not be `None`")  # noqa: E501

        self._job_search_statuses_employer = job_search_statuses_employer

    @property
    def language_level(self):
        """Gets the language_level of this DictionariesDictResponse.  # noqa: E501

        Language level  # noqa: E501

        :return: The language_level of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._language_level

    @language_level.setter
    def language_level(self, language_level):
        """Sets the language_level of this DictionariesDictResponse.

        Language level  # noqa: E501

        :param language_level: The language_level of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if language_level is None:
            raise ValueError("Invalid value for `language_level`, must not be `None`")  # noqa: E501

        self._language_level = language_level

    @property
    def messaging_status(self):
        """Gets the messaging_status of this DictionariesDictResponse.  # noqa: E501

        Status of the message sending possibility in messaging  # noqa: E501

        :return: The messaging_status of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._messaging_status

    @messaging_status.setter
    def messaging_status(self, messaging_status):
        """Sets the messaging_status of this DictionariesDictResponse.

        Status of the message sending possibility in messaging  # noqa: E501

        :param messaging_status: The messaging_status of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if messaging_status is None:
            raise ValueError("Invalid value for `messaging_status`, must not be `None`")  # noqa: E501

        self._messaging_status = messaging_status

    @property
    def negotiations_order(self):
        """Gets the negotiations_order of this DictionariesDictResponse.  # noqa: E501

        Application display order types  # noqa: E501

        :return: The negotiations_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._negotiations_order

    @negotiations_order.setter
    def negotiations_order(self, negotiations_order):
        """Sets the negotiations_order of this DictionariesDictResponse.

        Application display order types  # noqa: E501

        :param negotiations_order: The negotiations_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if negotiations_order is None:
            raise ValueError("Invalid value for `negotiations_order`, must not be `None`")  # noqa: E501

        self._negotiations_order = negotiations_order

    @property
    def negotiations_participant_type(self):
        """Gets the negotiations_participant_type of this DictionariesDictResponse.  # noqa: E501

        Types of messaging participants  # noqa: E501

        :return: The negotiations_participant_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._negotiations_participant_type

    @negotiations_participant_type.setter
    def negotiations_participant_type(self, negotiations_participant_type):
        """Sets the negotiations_participant_type of this DictionariesDictResponse.

        Types of messaging participants  # noqa: E501

        :param negotiations_participant_type: The negotiations_participant_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if negotiations_participant_type is None:
            raise ValueError("Invalid value for `negotiations_participant_type`, must not be `None`")  # noqa: E501

        self._negotiations_participant_type = negotiations_participant_type

    @property
    def negotiations_state(self):
        """Gets the negotiations_state of this DictionariesDictResponse.  # noqa: E501

        Application state types  # noqa: E501

        :return: The negotiations_state of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._negotiations_state

    @negotiations_state.setter
    def negotiations_state(self, negotiations_state):
        """Sets the negotiations_state of this DictionariesDictResponse.

        Application state types  # noqa: E501

        :param negotiations_state: The negotiations_state of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if negotiations_state is None:
            raise ValueError("Invalid value for `negotiations_state`, must not be `None`")  # noqa: E501

        self._negotiations_state = negotiations_state

    @property
    def phone_call_status(self):
        """Gets the phone_call_status of this DictionariesDictResponse.  # noqa: E501

        Status of the phone call in call-tracking system  # noqa: E501

        :return: The phone_call_status of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._phone_call_status

    @phone_call_status.setter
    def phone_call_status(self, phone_call_status):
        """Sets the phone_call_status of this DictionariesDictResponse.

        Status of the phone call in call-tracking system  # noqa: E501

        :param phone_call_status: The phone_call_status of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if phone_call_status is None:
            raise ValueError("Invalid value for `phone_call_status`, must not be `None`")  # noqa: E501

        self._phone_call_status = phone_call_status

    @property
    def preferred_contact_type(self):
        """Gets the preferred_contact_type of this DictionariesDictResponse.  # noqa: E501

        Preferred method of communication  # noqa: E501

        :return: The preferred_contact_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._preferred_contact_type

    @preferred_contact_type.setter
    def preferred_contact_type(self, preferred_contact_type):
        """Sets the preferred_contact_type of this DictionariesDictResponse.

        Preferred method of communication  # noqa: E501

        :param preferred_contact_type: The preferred_contact_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if preferred_contact_type is None:
            raise ValueError("Invalid value for `preferred_contact_type`, must not be `None`")  # noqa: E501

        self._preferred_contact_type = preferred_contact_type

    @property
    def relocation_type(self):
        """Gets the relocation_type of this DictionariesDictResponse.  # noqa: E501

        Willingness to relocate  # noqa: E501

        :return: The relocation_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._relocation_type

    @relocation_type.setter
    def relocation_type(self, relocation_type):
        """Sets the relocation_type of this DictionariesDictResponse.

        Willingness to relocate  # noqa: E501

        :param relocation_type: The relocation_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if relocation_type is None:
            raise ValueError("Invalid value for `relocation_type`, must not be `None`")  # noqa: E501

        self._relocation_type = relocation_type

    @property
    def resume_access_type(self):
        """Gets the resume_access_type of this DictionariesDictResponse.  # noqa: E501

        CV access level  # noqa: E501

        :return: The resume_access_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_access_type

    @resume_access_type.setter
    def resume_access_type(self, resume_access_type):
        """Sets the resume_access_type of this DictionariesDictResponse.

        CV access level  # noqa: E501

        :param resume_access_type: The resume_access_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if resume_access_type is None:
            raise ValueError("Invalid value for `resume_access_type`, must not be `None`")  # noqa: E501

        self._resume_access_type = resume_access_type

    @property
    def resume_contacts_site_type(self):
        """Gets the resume_contacts_site_type of this DictionariesDictResponse.  # noqa: E501

        Website type in the \"contacts\" field  # noqa: E501

        :return: The resume_contacts_site_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_contacts_site_type

    @resume_contacts_site_type.setter
    def resume_contacts_site_type(self, resume_contacts_site_type):
        """Sets the resume_contacts_site_type of this DictionariesDictResponse.

        Website type in the \"contacts\" field  # noqa: E501

        :param resume_contacts_site_type: The resume_contacts_site_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if resume_contacts_site_type is None:
            raise ValueError("Invalid value for `resume_contacts_site_type`, must not be `None`")  # noqa: E501

        self._resume_contacts_site_type = resume_contacts_site_type

    @property
    def resume_hidden_fields(self):
        """Gets the resume_hidden_fields of this DictionariesDictResponse.  # noqa: E501

        Resume fields that can be [hidden](#tag/Resume-view/operation/get-resume) ('hidden_fields' attribute)  # noqa: E501

        :return: The resume_hidden_fields of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_hidden_fields

    @resume_hidden_fields.setter
    def resume_hidden_fields(self, resume_hidden_fields):
        """Sets the resume_hidden_fields of this DictionariesDictResponse.

        Resume fields that can be [hidden](#tag/Resume-view/operation/get-resume) ('hidden_fields' attribute)  # noqa: E501

        :param resume_hidden_fields: The resume_hidden_fields of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if resume_hidden_fields is None:
            raise ValueError("Invalid value for `resume_hidden_fields`, must not be `None`")  # noqa: E501

        self._resume_hidden_fields = resume_hidden_fields

    @property
    def resume_moderation_note(self):
        """Gets the resume_moderation_note of this DictionariesDictResponse.  # noqa: E501

        Moderator's comment  # noqa: E501

        :return: The resume_moderation_note of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_moderation_note

    @resume_moderation_note.setter
    def resume_moderation_note(self, resume_moderation_note):
        """Sets the resume_moderation_note of this DictionariesDictResponse.

        Moderator's comment  # noqa: E501

        :param resume_moderation_note: The resume_moderation_note of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if resume_moderation_note is None:
            raise ValueError("Invalid value for `resume_moderation_note`, must not be `None`")  # noqa: E501

        self._resume_moderation_note = resume_moderation_note

    @property
    def resume_search_experience_period(self):
        """Gets the resume_search_experience_period of this DictionariesDictResponse.  # noqa: E501

        Search term by work experience  # noqa: E501

        :return: The resume_search_experience_period of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_search_experience_period

    @resume_search_experience_period.setter
    def resume_search_experience_period(self, resume_search_experience_period):
        """Sets the resume_search_experience_period of this DictionariesDictResponse.

        Search term by work experience  # noqa: E501

        :param resume_search_experience_period: The resume_search_experience_period of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._resume_search_experience_period = resume_search_experience_period

    @property
    def resume_search_fields(self):
        """Gets the resume_search_fields of this DictionariesDictResponse.  # noqa: E501

        Search area in resume  # noqa: E501

        :return: The resume_search_fields of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_search_fields

    @resume_search_fields.setter
    def resume_search_fields(self, resume_search_fields):
        """Sets the resume_search_fields of this DictionariesDictResponse.

        Search area in resume  # noqa: E501

        :param resume_search_fields: The resume_search_fields of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._resume_search_fields = resume_search_fields

    @property
    def resume_search_label(self):
        """Gets the resume_search_label of this DictionariesDictResponse.  # noqa: E501

        Resume search tags  # noqa: E501

        :return: The resume_search_label of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_search_label

    @resume_search_label.setter
    def resume_search_label(self, resume_search_label):
        """Sets the resume_search_label of this DictionariesDictResponse.

        Resume search tags  # noqa: E501

        :param resume_search_label: The resume_search_label of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._resume_search_label = resume_search_label

    @property
    def resume_search_logic(self):
        """Gets the resume_search_logic of this DictionariesDictResponse.  # noqa: E501

        Resume search term  # noqa: E501

        :return: The resume_search_logic of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_search_logic

    @resume_search_logic.setter
    def resume_search_logic(self, resume_search_logic):
        """Sets the resume_search_logic of this DictionariesDictResponse.

        Resume search term  # noqa: E501

        :param resume_search_logic: The resume_search_logic of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._resume_search_logic = resume_search_logic

    @property
    def resume_search_order(self):
        """Gets the resume_search_order of this DictionariesDictResponse.  # noqa: E501

        Resume sorting type  # noqa: E501

        :return: The resume_search_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_search_order

    @resume_search_order.setter
    def resume_search_order(self, resume_search_order):
        """Sets the resume_search_order of this DictionariesDictResponse.

        Resume sorting type  # noqa: E501

        :param resume_search_order: The resume_search_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._resume_search_order = resume_search_order

    @property
    def resume_search_relocation(self):
        """Gets the resume_search_relocation of this DictionariesDictResponse.  # noqa: E501

        Search condition for residence in the region and readiness to move  # noqa: E501

        :return: The resume_search_relocation of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_search_relocation

    @resume_search_relocation.setter
    def resume_search_relocation(self, resume_search_relocation):
        """Sets the resume_search_relocation of this DictionariesDictResponse.

        Search condition for residence in the region and readiness to move  # noqa: E501

        :param resume_search_relocation: The resume_search_relocation of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._resume_search_relocation = resume_search_relocation

    @property
    def resume_status(self):
        """Gets the resume_status of this DictionariesDictResponse.  # noqa: E501

        CV status  # noqa: E501

        :return: The resume_status of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._resume_status

    @resume_status.setter
    def resume_status(self, resume_status):
        """Sets the resume_status of this DictionariesDictResponse.

        CV status  # noqa: E501

        :param resume_status: The resume_status of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if resume_status is None:
            raise ValueError("Invalid value for `resume_status`, must not be `None`")  # noqa: E501

        self._resume_status = resume_status

    @property
    def schedule(self):
        """Gets the schedule of this DictionariesDictResponse.  # noqa: E501

        Work schedule  # noqa: E501

        :return: The schedule of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdNameUid]
        """
        return self._schedule

    @schedule.setter
    def schedule(self, schedule):
        """Sets the schedule of this DictionariesDictResponse.

        Work schedule  # noqa: E501

        :param schedule: The schedule of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdNameUid]
        """
        if schedule is None:
            raise ValueError("Invalid value for `schedule`, must not be `None`")  # noqa: E501

        self._schedule = schedule

    @property
    def travel_time(self):
        """Gets the travel_time of this DictionariesDictResponse.  # noqa: E501

        Travel time to work  # noqa: E501

        :return: The travel_time of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._travel_time

    @travel_time.setter
    def travel_time(self, travel_time):
        """Sets the travel_time of this DictionariesDictResponse.

        Travel time to work  # noqa: E501

        :param travel_time: The travel_time of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if travel_time is None:
            raise ValueError("Invalid value for `travel_time`, must not be `None`")  # noqa: E501

        self._travel_time = travel_time

    @property
    def vacancy_billing_type(self):
        """Gets the vacancy_billing_type of this DictionariesDictResponse.  # noqa: E501

        Vacancy placement options in terms of billing  # noqa: E501

        :return: The vacancy_billing_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_billing_type

    @vacancy_billing_type.setter
    def vacancy_billing_type(self, vacancy_billing_type):
        """Sets the vacancy_billing_type of this DictionariesDictResponse.

        Vacancy placement options in terms of billing  # noqa: E501

        :param vacancy_billing_type: The vacancy_billing_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_billing_type is None:
            raise ValueError("Invalid value for `vacancy_billing_type`, must not be `None`")  # noqa: E501

        self._vacancy_billing_type = vacancy_billing_type

    @property
    def vacancy_cluster(self):
        """Gets the vacancy_cluster of this DictionariesDictResponse.  # noqa: E501

        Cluster type  # noqa: E501

        :return: The vacancy_cluster of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_cluster

    @vacancy_cluster.setter
    def vacancy_cluster(self, vacancy_cluster):
        """Sets the vacancy_cluster of this DictionariesDictResponse.

        Cluster type  # noqa: E501

        :param vacancy_cluster: The vacancy_cluster of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_cluster is None:
            raise ValueError("Invalid value for `vacancy_cluster`, must not be `None`")  # noqa: E501

        self._vacancy_cluster = vacancy_cluster

    @property
    def vacancy_label(self):
        """Gets the vacancy_label of this DictionariesDictResponse.  # noqa: E501

        Vacancy tags  # noqa: E501

        :return: The vacancy_label of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_label

    @vacancy_label.setter
    def vacancy_label(self, vacancy_label):
        """Sets the vacancy_label of this DictionariesDictResponse.

        Vacancy tags  # noqa: E501

        :param vacancy_label: The vacancy_label of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_label is None:
            raise ValueError("Invalid value for `vacancy_label`, must not be `None`")  # noqa: E501

        self._vacancy_label = vacancy_label

    @property
    def vacancy_not_prolonged_reason(self):
        """Gets the vacancy_not_prolonged_reason of this DictionariesDictResponse.  # noqa: E501

        The reasons why [prolongation](#tag/Vacancy-management/operation/get-prolongation-vacancy-info) is not available  # noqa: E501

        :return: The vacancy_not_prolonged_reason of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_not_prolonged_reason

    @vacancy_not_prolonged_reason.setter
    def vacancy_not_prolonged_reason(self, vacancy_not_prolonged_reason):
        """Sets the vacancy_not_prolonged_reason of this DictionariesDictResponse.

        The reasons why [prolongation](#tag/Vacancy-management/operation/get-prolongation-vacancy-info) is not available  # noqa: E501

        :param vacancy_not_prolonged_reason: The vacancy_not_prolonged_reason of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_not_prolonged_reason is None:
            raise ValueError("Invalid value for `vacancy_not_prolonged_reason`, must not be `None`")  # noqa: E501

        self._vacancy_not_prolonged_reason = vacancy_not_prolonged_reason

    @property
    def vacancy_relation(self):
        """Gets the vacancy_relation of this DictionariesDictResponse.  # noqa: E501

        Types of vacancy connection to the user  # noqa: E501

        :return: The vacancy_relation of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_relation

    @vacancy_relation.setter
    def vacancy_relation(self, vacancy_relation):
        """Sets the vacancy_relation of this DictionariesDictResponse.

        Types of vacancy connection to the user  # noqa: E501

        :param vacancy_relation: The vacancy_relation of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_relation is None:
            raise ValueError("Invalid value for `vacancy_relation`, must not be `None`")  # noqa: E501

        self._vacancy_relation = vacancy_relation

    @property
    def vacancy_search_fields(self):
        """Gets the vacancy_search_fields of this DictionariesDictResponse.  # noqa: E501

        Search area in vacancy  # noqa: E501

        :return: The vacancy_search_fields of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_search_fields

    @vacancy_search_fields.setter
    def vacancy_search_fields(self, vacancy_search_fields):
        """Sets the vacancy_search_fields of this DictionariesDictResponse.

        Search area in vacancy  # noqa: E501

        :param vacancy_search_fields: The vacancy_search_fields of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_search_fields is None:
            raise ValueError("Invalid value for `vacancy_search_fields`, must not be `None`")  # noqa: E501

        self._vacancy_search_fields = vacancy_search_fields

    @property
    def vacancy_search_order(self):
        """Gets the vacancy_search_order of this DictionariesDictResponse.  # noqa: E501

        Vacancy sorting type  # noqa: E501

        :return: The vacancy_search_order of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_search_order

    @vacancy_search_order.setter
    def vacancy_search_order(self, vacancy_search_order):
        """Sets the vacancy_search_order of this DictionariesDictResponse.

        Vacancy sorting type  # noqa: E501

        :param vacancy_search_order: The vacancy_search_order of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_search_order is None:
            raise ValueError("Invalid value for `vacancy_search_order`, must not be `None`")  # noqa: E501

        self._vacancy_search_order = vacancy_search_order

    @property
    def vacancy_type(self):
        """Gets the vacancy_type of this DictionariesDictResponse.  # noqa: E501

        Vacancy type  # noqa: E501

        :return: The vacancy_type of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._vacancy_type

    @vacancy_type.setter
    def vacancy_type(self, vacancy_type):
        """Sets the vacancy_type of this DictionariesDictResponse.

        Vacancy type  # noqa: E501

        :param vacancy_type: The vacancy_type of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if vacancy_type is None:
            raise ValueError("Invalid value for `vacancy_type`, must not be `None`")  # noqa: E501

        self._vacancy_type = vacancy_type

    @property
    def work_format(self):
        """Gets the work_format of this DictionariesDictResponse.  # noqa: E501

        Work format. Use for vacancy and draft field - work_format  # noqa: E501

        :return: The work_format of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._work_format

    @work_format.setter
    def work_format(self, work_format):
        """Sets the work_format of this DictionariesDictResponse.

        Work format. Use for vacancy and draft field - work_format  # noqa: E501

        :param work_format: The work_format of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._work_format = work_format

    @property
    def work_schedule_by_days(self):
        """Gets the work_schedule_by_days of this DictionariesDictResponse.  # noqa: E501

        Work schedule by days. Use for vacancy and draft field - work_schedule_by_days  # noqa: E501

        :return: The work_schedule_by_days of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._work_schedule_by_days

    @work_schedule_by_days.setter
    def work_schedule_by_days(self, work_schedule_by_days):
        """Sets the work_schedule_by_days of this DictionariesDictResponse.

        Work schedule by days. Use for vacancy and draft field - work_schedule_by_days  # noqa: E501

        :param work_schedule_by_days: The work_schedule_by_days of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._work_schedule_by_days = work_schedule_by_days

    @property
    def working_days(self):
        """Gets the working_days of this DictionariesDictResponse.  # noqa: E501

        Working days  # noqa: E501

        :return: The working_days of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._working_days

    @working_days.setter
    def working_days(self, working_days):
        """Sets the working_days of this DictionariesDictResponse.

        Working days  # noqa: E501

        :param working_days: The working_days of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if working_days is None:
            raise ValueError("Invalid value for `working_days`, must not be `None`")  # noqa: E501

        self._working_days = working_days

    @property
    def working_hours(self):
        """Gets the working_hours of this DictionariesDictResponse.  # noqa: E501

        Working hours by day. Use for vacancy and draft field - working_hours  # noqa: E501

        :return: The working_hours of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._working_hours

    @working_hours.setter
    def working_hours(self, working_hours):
        """Sets the working_hours of this DictionariesDictResponse.

        Working hours by day. Use for vacancy and draft field - working_hours  # noqa: E501

        :param working_hours: The working_hours of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """

        self._working_hours = working_hours

    @property
    def working_time_intervals(self):
        """Gets the working_time_intervals of this DictionariesDictResponse.  # noqa: E501

        Working time intervals  # noqa: E501

        :return: The working_time_intervals of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._working_time_intervals

    @working_time_intervals.setter
    def working_time_intervals(self, working_time_intervals):
        """Sets the working_time_intervals of this DictionariesDictResponse.

        Working time intervals  # noqa: E501

        :param working_time_intervals: The working_time_intervals of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if working_time_intervals is None:
            raise ValueError("Invalid value for `working_time_intervals`, must not be `None`")  # noqa: E501

        self._working_time_intervals = working_time_intervals

    @property
    def working_time_modes(self):
        """Gets the working_time_modes of this DictionariesDictResponse.  # noqa: E501

        Working time modes  # noqa: E501

        :return: The working_time_modes of this DictionariesDictResponse.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._working_time_modes

    @working_time_modes.setter
    def working_time_modes(self, working_time_modes):
        """Sets the working_time_modes of this DictionariesDictResponse.

        Working time modes  # noqa: E501

        :param working_time_modes: The working_time_modes of this DictionariesDictResponse.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if working_time_modes is None:
            raise ValueError("Invalid value for `working_time_modes`, must not be `None`")  # noqa: E501

        self._working_time_modes = working_time_modes

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(DictionariesDictResponse, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DictionariesDictResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
