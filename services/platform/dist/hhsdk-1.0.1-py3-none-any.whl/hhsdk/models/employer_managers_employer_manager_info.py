# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

import pprint
import re  # noqa: F401

import six

class EmployerManagersEmployerManagerInfo(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    """
    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'additional_phone': 'AllOfEmployerManagersEmployerManagerInfoAdditionalPhone',
        'area': 'EmployerManagersArea',
        'email': 'str',
        'first_name': 'str',
        'full_name': 'str',
        'id': 'str',
        'is_main_contact_person': 'bool',
        'last_name': 'str',
        'manager_type': 'EmployerManagersManagerType',
        'middle_name': 'str',
        'name': 'str',
        'permissions': 'list[EmployerManagerTypesAvailablePermissions]',
        'phone': 'AllOfEmployerManagersEmployerManagerInfoPhone',
        'position': 'str',
        'special_note_1': 'str',
        'special_note_2': 'str',
        'vacancies_count': 'float'
    }

    attribute_map = {
        'additional_phone': 'additional_phone',
        'area': 'area',
        'email': 'email',
        'first_name': 'first_name',
        'full_name': 'full_name',
        'id': 'id',
        'is_main_contact_person': 'is_main_contact_person',
        'last_name': 'last_name',
        'manager_type': 'manager_type',
        'middle_name': 'middle_name',
        'name': 'name',
        'permissions': 'permissions',
        'phone': 'phone',
        'position': 'position',
        'special_note_1': 'special_note_1',
        'special_note_2': 'special_note_2',
        'vacancies_count': 'vacancies_count'
    }

    def __init__(self, additional_phone=None, area=None, email=None, first_name=None, full_name=None, id=None, is_main_contact_person=None, last_name=None, manager_type=None, middle_name=None, name=None, permissions=None, phone=None, position=None, special_note_1=None, special_note_2=None, vacancies_count=None):  # noqa: E501
        """EmployerManagersEmployerManagerInfo - a model defined in Swagger"""  # noqa: E501
        self._additional_phone = None
        self._area = None
        self._email = None
        self._first_name = None
        self._full_name = None
        self._id = None
        self._is_main_contact_person = None
        self._last_name = None
        self._manager_type = None
        self._middle_name = None
        self._name = None
        self._permissions = None
        self._phone = None
        self._position = None
        self._special_note_1 = None
        self._special_note_2 = None
        self._vacancies_count = None
        self.discriminator = None
        if additional_phone is not None:
            self.additional_phone = additional_phone
        if area is not None:
            self.area = area
        self.email = email
        self.first_name = first_name
        if full_name is not None:
            self.full_name = full_name
        self.id = id
        self.is_main_contact_person = is_main_contact_person
        self.last_name = last_name
        if manager_type is not None:
            self.manager_type = manager_type
        if middle_name is not None:
            self.middle_name = middle_name
        if name is not None:
            self.name = name
        self.permissions = permissions
        self.phone = phone
        self.position = position
        if special_note_1 is not None:
            self.special_note_1 = special_note_1
        if special_note_2 is not None:
            self.special_note_2 = special_note_2
        if vacancies_count is not None:
            self.vacancies_count = vacancies_count

    @property
    def additional_phone(self):
        """Gets the additional_phone of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Additional manager's phone  # noqa: E501

        :return: The additional_phone of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: AllOfEmployerManagersEmployerManagerInfoAdditionalPhone
        """
        return self._additional_phone

    @additional_phone.setter
    def additional_phone(self, additional_phone):
        """Sets the additional_phone of this EmployerManagersEmployerManagerInfo.

        Additional manager's phone  # noqa: E501

        :param additional_phone: The additional_phone of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: AllOfEmployerManagersEmployerManagerInfoAdditionalPhone
        """

        self._additional_phone = additional_phone

    @property
    def area(self):
        """Gets the area of this EmployerManagersEmployerManagerInfo.  # noqa: E501


        :return: The area of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: EmployerManagersArea
        """
        return self._area

    @area.setter
    def area(self, area):
        """Sets the area of this EmployerManagersEmployerManagerInfo.


        :param area: The area of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: EmployerManagersArea
        """

        self._area = area

    @property
    def email(self):
        """Gets the email of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's E-mail  # noqa: E501

        :return: The email of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._email

    @email.setter
    def email(self, email):
        """Sets the email of this EmployerManagersEmployerManagerInfo.

        Manager's E-mail  # noqa: E501

        :param email: The email of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """
        if email is None:
            raise ValueError("Invalid value for `email`, must not be `None`")  # noqa: E501

        self._email = email

    @property
    def first_name(self):
        """Gets the first_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's first name  # noqa: E501

        :return: The first_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._first_name

    @first_name.setter
    def first_name(self, first_name):
        """Sets the first_name of this EmployerManagersEmployerManagerInfo.

        Manager's first name  # noqa: E501

        :param first_name: The first_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """
        if first_name is None:
            raise ValueError("Invalid value for `first_name`, must not be `None`")  # noqa: E501

        self._first_name = first_name

    @property
    def full_name(self):
        """Gets the full_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's full name  # noqa: E501

        :return: The full_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._full_name

    @full_name.setter
    def full_name(self, full_name):
        """Sets the full_name of this EmployerManagersEmployerManagerInfo.

        Manager's full name  # noqa: E501

        :param full_name: The full_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """

        self._full_name = full_name

    @property
    def id(self):
        """Gets the id of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's ID  # noqa: E501

        :return: The id of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this EmployerManagersEmployerManagerInfo.

        Manager's ID  # noqa: E501

        :param id: The id of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """
        if id is None:
            raise ValueError("Invalid value for `id`, must not be `None`")  # noqa: E501

        self._id = id

    @property
    def is_main_contact_person(self):
        """Gets the is_main_contact_person of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        If manager is the main contact person then 'true'  # noqa: E501

        :return: The is_main_contact_person of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: bool
        """
        return self._is_main_contact_person

    @is_main_contact_person.setter
    def is_main_contact_person(self, is_main_contact_person):
        """Sets the is_main_contact_person of this EmployerManagersEmployerManagerInfo.

        If manager is the main contact person then 'true'  # noqa: E501

        :param is_main_contact_person: The is_main_contact_person of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: bool
        """
        if is_main_contact_person is None:
            raise ValueError("Invalid value for `is_main_contact_person`, must not be `None`")  # noqa: E501

        self._is_main_contact_person = is_main_contact_person

    @property
    def last_name(self):
        """Gets the last_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's last name  # noqa: E501

        :return: The last_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._last_name

    @last_name.setter
    def last_name(self, last_name):
        """Sets the last_name of this EmployerManagersEmployerManagerInfo.

        Manager's last name  # noqa: E501

        :param last_name: The last_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """
        if last_name is None:
            raise ValueError("Invalid value for `last_name`, must not be `None`")  # noqa: E501

        self._last_name = last_name

    @property
    def manager_type(self):
        """Gets the manager_type of this EmployerManagersEmployerManagerInfo.  # noqa: E501


        :return: The manager_type of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: EmployerManagersManagerType
        """
        return self._manager_type

    @manager_type.setter
    def manager_type(self, manager_type):
        """Sets the manager_type of this EmployerManagersEmployerManagerInfo.


        :param manager_type: The manager_type of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: EmployerManagersManagerType
        """

        self._manager_type = manager_type

    @property
    def middle_name(self):
        """Gets the middle_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's middle name  # noqa: E501

        :return: The middle_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._middle_name

    @middle_name.setter
    def middle_name(self, middle_name):
        """Sets the middle_name of this EmployerManagersEmployerManagerInfo.

        Manager's middle name  # noqa: E501

        :param middle_name: The middle_name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """

        self._middle_name = middle_name

    @property
    def name(self):
        """Gets the name of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's full name  # noqa: E501

        :return: The name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this EmployerManagersEmployerManagerInfo.

        Manager's full name  # noqa: E501

        :param name: The name of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """

        self._name = name

    @property
    def permissions(self):
        """Gets the permissions of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        List of [manager's privileges](#tag/Employer-managers/operation/get-employer-manager-types)  # noqa: E501

        :return: The permissions of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: list[EmployerManagerTypesAvailablePermissions]
        """
        return self._permissions

    @permissions.setter
    def permissions(self, permissions):
        """Sets the permissions of this EmployerManagersEmployerManagerInfo.

        List of [manager's privileges](#tag/Employer-managers/operation/get-employer-manager-types)  # noqa: E501

        :param permissions: The permissions of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: list[EmployerManagerTypesAvailablePermissions]
        """
        if permissions is None:
            raise ValueError("Invalid value for `permissions`, must not be `None`")  # noqa: E501

        self._permissions = permissions

    @property
    def phone(self):
        """Gets the phone of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's phone  # noqa: E501

        :return: The phone of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: AllOfEmployerManagersEmployerManagerInfoPhone
        """
        return self._phone

    @phone.setter
    def phone(self, phone):
        """Sets the phone of this EmployerManagersEmployerManagerInfo.

        Manager's phone  # noqa: E501

        :param phone: The phone of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: AllOfEmployerManagersEmployerManagerInfoPhone
        """
        if phone is None:
            raise ValueError("Invalid value for `phone`, must not be `None`")  # noqa: E501

        self._phone = phone

    @property
    def position(self):
        """Gets the position of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Manager's position  # noqa: E501

        :return: The position of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._position

    @position.setter
    def position(self, position):
        """Sets the position of this EmployerManagersEmployerManagerInfo.

        Manager's position  # noqa: E501

        :param position: The position of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """
        if position is None:
            raise ValueError("Invalid value for `position`, must not be `None`")  # noqa: E501

        self._position = position

    @property
    def special_note_1(self):
        """Gets the special_note_1 of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        First special note of manager  # noqa: E501

        :return: The special_note_1 of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._special_note_1

    @special_note_1.setter
    def special_note_1(self, special_note_1):
        """Sets the special_note_1 of this EmployerManagersEmployerManagerInfo.

        First special note of manager  # noqa: E501

        :param special_note_1: The special_note_1 of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """

        self._special_note_1 = special_note_1

    @property
    def special_note_2(self):
        """Gets the special_note_2 of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Second special note of manager  # noqa: E501

        :return: The special_note_2 of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: str
        """
        return self._special_note_2

    @special_note_2.setter
    def special_note_2(self, special_note_2):
        """Sets the special_note_2 of this EmployerManagersEmployerManagerInfo.

        Second special note of manager  # noqa: E501

        :param special_note_2: The special_note_2 of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: str
        """

        self._special_note_2 = special_note_2

    @property
    def vacancies_count(self):
        """Gets the vacancies_count of this EmployerManagersEmployerManagerInfo.  # noqa: E501

        Number of published (active) vacancies for this manager. `null` — if user has not permission to that manager's vacancies  # noqa: E501

        :return: The vacancies_count of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :rtype: float
        """
        return self._vacancies_count

    @vacancies_count.setter
    def vacancies_count(self, vacancies_count):
        """Sets the vacancies_count of this EmployerManagersEmployerManagerInfo.

        Number of published (active) vacancies for this manager. `null` — if user has not permission to that manager's vacancies  # noqa: E501

        :param vacancies_count: The vacancies_count of this EmployerManagersEmployerManagerInfo.  # noqa: E501
        :type: float
        """

        self._vacancies_count = vacancies_count

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(EmployerManagersEmployerManagerInfo, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EmployerManagersEmployerManagerInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
