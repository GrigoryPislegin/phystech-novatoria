# coding: utf-8

"""
    HeadHunter API

    In English | [По-русски](https://api.hh.ru/openapi/redoc)  OpenAPI maintains only a small part of the documentation so far [Basic documentation](https://github.com/hhru/api/blob/master/docs_eng/README.md).  You can use Ctrl+F to search through the documentation.  # General information    * The whole API works using the HTTPS protocol. * Authorization is performed via the OAuth2 protocol. * All data is available only in the JSON format. * The basic URL is `https://api.hh.ru/` * Requests for [any site of HeadHunter Groups of Companies](#section/General-information/Host-selection) are available * <a name=\"date-format\"></a> Dates are formatted according to [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601): `YYYY-MM-DDThh:mm:ss±hhmm`.         ## Request requirements      Your request should send the `User-Agent` header, but if your   HTTP client does not allow it, you can send an `HH-User-Agent` header. If no header is sent,   you will receive the `400 Bad Request` as a response.   By specifying the name of the application and the developer's contact email in the header,   you will help us to contact you promptly if required.   The `User-Agent` and `HH-User-Agent` headers are interchangeable. If you send both headers,   only `HH-User-Agent` is processed.      ``` User-Agent: MyApp/1.0 (my-app-feedback@example.com)   ```      More detail on [errors in the User-Agent title](https://github.com/hhru/api/blob/master/docs_eng/errors.md#user-agent).       ### Request body format when sending JSON  Data transferred in the request body must meet the requirements:      * Valid JSON (it is acceptable to transfer both minified and   pretty-printed variants with extra whitespace and line breaks).      * It is recommended to use the UTF-8 encoding without extra escaping (`{\"name\": \"Иванов Иван\"}`).      * It is also possible to use the ascii encoding with escaping (`{\"name\": \"\\u0418\\u0432\\u0430\\u043d\\u043e\\u0432 \\u0418\\u0432\\u0430\\u043d\"}`).      * Data types in certain fields are supplemented with additional conditions   described in each specific method. In JSON, data types are `string`, `number`,   `boolean`, `null`, `object`, `array`.      ### Response   A response that exceeds a certain length will be compressed using gzip.      ### Errors and response codes      API extensively uses informing through response codes.   The application must process them correctly.      In case of failure or breakdown, responses with the `503` and `500` code may be   returned.      When an error occurs, the response body, besides the response code,   may have additional information allowing the developer   to learn the cause of a particular response.      [More detail on possible errors](https://github.com/hhru/api/blob/master/docs_eng/errors.md).         ## Undocumented fields and request parameters      In responses and API parameters you can find keys that are not described in the   documentation. It usually means that they are left for compatibility with older   versions. It is not recommended to use them. If your application already uses   such keys, switch to using desirable keys described in the documentation.         ## Pagination      For every request that presupposes the return of object list you can indicate   `page=N&per_page=M` in the parameters. Numeration starts from zero; the first   (zero) page is returned by default with 20 objects on it. In all responses where pagination is available, the uniform root object:      ```json   {     \"found\": 1,     \"per_page\": 1,     \"pages\": 1,     \"page\": 0,     \"items\": [{}]   }   ```      ## Host selection          HeadHunter API allows you to obtain data from all of the HeadHunter group of   companies websites.        In particular:    * hh.ru   * rabota.by   * hh1.az   * hh.uz   * hh.kz   * headhunter.ge   * headhunter.kg          Requests for data on all the websites should be made to `https://api.hh.ru/`.          If you need to track the specific websites, you can add `?host=` parameter to       your request. Default is `hh.ru`.        Example: to obtain [localizations](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-locales) available on hh.kz, you should       make a GET-request to `https://api.hh.ru/locales?host=hh.kz`.      ## CORS (Cross-Origin Resource Sharing)      API supports the CORS technology for requesting browser data from any domain.   This method is preferable to JSONP. It is not restricted to the GET method. To   debug CORS, a [special method](https://github.com/hhru/api/blob/master/docs_eng/cors.md) is available. To use JSONP, transfer the   `?callback=callback_name` parameter.      * [CORS specification on w3.org](http://www.w3.org/TR/cors/)   * [HTML5Rocks CORS Tutorial](http://www.html5rocks.com/en/tutorials/cors/)   * [CORS on dev.opera.com](http://dev.opera.com/articles/view/dom-access-control-using-cross-origin-resource-sharing/)   * [CORS on caniuse.com](http://caniuse.com/#feat=cors)   * [CORS on en.wikipedia.org](http://en.wikipedia.org/wiki/Cross-origin_resource_sharing)       ## External links to articles and standards    * [HTTP/1.1](http://tools.ietf.org/html/rfc2616) * [JSON](http://json.org/) * [URI Template](http://tools.ietf.org/html/rfc6570) * [OAuth 2.0](http://tools.ietf.org/html/rfc6749) * [REST](http://www.ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) * [ISO 8601](http://en.wikipedia.org/wiki/ISO_8601)  # Authorization  The API supports the following authorization levels:   - [application authorization](#tag/Application-authorization)   - [user authorization](#section/Authorization/User-authorization)  * [Obtaining user authorization](#section/Authorization/User-authorization)   * [Rules for generating special `redirect_uri`](#section/Authorization/Rules-for-generating-special-redirect_uri)   * [Authorization process](#section/Authorization/Authorization-process)   * [Successful obtaining temporary `authorization_code`](#get-authorization_code)   * [Obtaining access and refresh tokens](#section/Authorization/Obtaining-access-and-refresh-tokens) * [Updating a pair of access and refresh tokens](#section/Authorization/Updating-a-pair-of-access-and-refresh-tokens) * [Authorization request under another user](#section/Authorization/Authorization-request-under-another-user) * [Authorization under different working account](#section/Authorization/Authorization-under-different-working-account) * [Obtaining application authorization](#tag/Application-authorization)   ## User authorization To make requests as a user you need a user token.  Assign a user to the application (open the page) via the request:  ``` https://hh.ru/oauth/authorize? response_type=code& client_id={client_id}& state={state}& redirect_uri={redirect_uri} ```  Required parameters:  * `response_type=code` — specifies authorization method using the `authorization code` * `client_id` — ID obtained when creating the application   Optional parameters:  * `state` — if specified, it will be added in the redirect link of the response.     It allows to prevent cross-site request forgery. More info see in [RFC 6749. Section 10.12](http://tools.ietf.org/html/rfc6749#section-10.12) * `redirect_uri` — a URI for redirecting user after authorization.     If not specified, the value from the application settings is used. If the value is specified, its validation is carried out. Probably, you will need to make `urlencode` of the value.  ## Rules for generating special redirect_uri  For example, if `http://example.com/oauth` is saved in the settings, it is allowed to specify:  * `http://www.example.com/oauth` — a subdomain; * `http://www.example.com/oauth/sub/path` — a detailed path; * `http://example.com/oauth?lang=RU` — an additional parameter; * `http://www.example.com/oauth/sub/path?lang=RU` — all the mentioned.  Forbidden:  * `https://example.com/oauth` — another protocols; * `http://wwwexample.com/oauth` — another domains; * `http://wwwexample.com/` — another paths; * `http://example.com/oauths` — another paths; * `http://example.com:80/oauths` — originally missing port.  ## Authorization process  If the user is not authorized, the site login form appears. When the authorization is done, the form with subject access request is shown.  If the user rejects the access request, it triggers the redirection on the specified `redirect_uri` with `?error=access_denied` and `state={state}`, if any.  <a name=\"get-authorization_code\"></a> ### Successful obtaining temporary `authorization_code`  If the user accepts the access request, the redirect link contains a temporary `authorization_code`:  ```http HTTP/1.1 302 FOUND Location: {redirect_uri}?code={authorization_code} ```  If the user is already authorized, and the access to the application was granted earlier, then the login and subject access request are omitted, and the above redirect link returns as a response.  ## Obtaining access and refresh tokens  After obtaining the `authorization_code` the application makes a server-server request `POST https://api.hh.ru/token` to exchange the `authorization_code` to an `access_token` (old `POST https://hh.ru/oauth/token` request should consider as deprecated).  The request body should contain [additional parameters](#required_parameters).  The request body should be sent in standard `application/x-www-form-urlencoded` format with the corresponding `Content-Type` header.  The `authorization_code` has a short lifetime. When it expires, request another `authorization_code`.  ## Updating a pair of access and refresh tokens The `access_token` also has a lifetime (`expires_in` parameter, in seconds). When it expires, the application should make a request with the `refresh_token` to obtain a new one.  The request should be done in `application/x-www-form-urlencoded` format.  ``` POST https://api.hh.ru/token ```  (old `POST https://hh.ru/oauth/token` request should consider as deprecated)  The request body should contain [additional parameters](#required_parameters).  You can use the `refresh_token` only once and only after expiration of the `access_token`.  A new pair of access and refresh tokens should be used for further API requests and requests for token prolongation.  ## Authorization request under another user  The following case is possible:  1. Application redirects a user to the site with the authorization request. 2. The user is already authorized on site and application already has an access granted. 3. The user will be proposed to continue the work under current account or login to another one.  If you need to replace step 3 by instant redirection with temporary token, you should add the parameter `skip_choose_account=true` to `/oauth/authorize...` request. Then the authorized user gets access immediately.  If you need to show the authorization form every time, you should add the parameter `force_login=true` to `/oauth/authorize...` request. In this case the authorization form appears even if the user is already authorized.  This feature may be useful for applications that provide services for applicants only. If an employer user tries to log in, the application may propose them to get access under another user.  Also, after the authorization the application can show a message:  ``` You logged in as %FirstName_LastName%. Is it not you? ``` and propose a link with `force_login=true` for authorization under another login.  ## Authorization under different working account  To obtain information about getting a list of manager working accounts and working under different working accounts, see the [manager working account](#tag/Employer-managers/operation/get-manager-accounts) section.   <!-- ReDoc-Inject: <security-definitions> -->   # noqa: E501

    OpenAPI spec version: 1.0.0
    Contact: api@hh.ru
    Generated by: https://github.com/swagger-api/swagger-codegen.git
"""

import pprint
import re  # noqa: F401

import six

class EmployersEmployerInfo(object):
    """NOTE: This class is auto generated by the swagger code generator program.

    Do not edit the class manually.
    """
    """
    Attributes:
      swagger_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    swagger_types = {
        'accredited_it_employer': 'bool',
        'alternate_url': 'str',
        'applicant_services': 'IncludesEmployerApplicantServices',
        'area': 'AllOfEmployersEmployerInfoArea',
        'branded_description': 'str',
        'branding': 'OneOfEmployersEmployerInfoBranding',
        'description': 'str',
        'id': 'str',
        'industries': 'list[IncludesIdName]',
        'insider_interviews': 'list[EmployersInsiderInterviews]',
        'logo_urls': 'OneOfEmployersEmployerInfoLogoUrls',
        'name': 'str',
        'open_vacancies': 'float',
        'relations': 'list[str]',
        'site_url': 'str',
        'trusted': 'bool',
        'type': 'str',
        'vacancies_url': 'str'
    }

    attribute_map = {
        'accredited_it_employer': 'accredited_it_employer',
        'alternate_url': 'alternate_url',
        'applicant_services': 'applicant_services',
        'area': 'area',
        'branded_description': 'branded_description',
        'branding': 'branding',
        'description': 'description',
        'id': 'id',
        'industries': 'industries',
        'insider_interviews': 'insider_interviews',
        'logo_urls': 'logo_urls',
        'name': 'name',
        'open_vacancies': 'open_vacancies',
        'relations': 'relations',
        'site_url': 'site_url',
        'trusted': 'trusted',
        'type': 'type',
        'vacancies_url': 'vacancies_url'
    }

    def __init__(self, accredited_it_employer=None, alternate_url=None, applicant_services=None, area=None, branded_description=None, branding=None, description=None, id=None, industries=None, insider_interviews=None, logo_urls=None, name=None, open_vacancies=None, relations=None, site_url=None, trusted=None, type=None, vacancies_url=None):  # noqa: E501
        """EmployersEmployerInfo - a model defined in Swagger"""  # noqa: E501
        self._accredited_it_employer = None
        self._alternate_url = None
        self._applicant_services = None
        self._area = None
        self._branded_description = None
        self._branding = None
        self._description = None
        self._id = None
        self._industries = None
        self._insider_interviews = None
        self._logo_urls = None
        self._name = None
        self._open_vacancies = None
        self._relations = None
        self._site_url = None
        self._trusted = None
        self._type = None
        self._vacancies_url = None
        self.discriminator = None
        if accredited_it_employer is not None:
            self.accredited_it_employer = accredited_it_employer
        self.alternate_url = alternate_url
        if applicant_services is not None:
            self.applicant_services = applicant_services
        self.area = area
        if branded_description is not None:
            self.branded_description = branded_description
        if branding is not None:
            self.branding = branding
        if description is not None:
            self.description = description
        self.id = id
        self.industries = industries
        self.insider_interviews = insider_interviews
        if logo_urls is not None:
            self.logo_urls = logo_urls
        self.name = name
        if open_vacancies is not None:
            self.open_vacancies = open_vacancies
        self.relations = relations
        self.site_url = site_url
        self.trusted = trusted
        if type is not None:
            self.type = type
        self.vacancies_url = vacancies_url

    @property
    def accredited_it_employer(self):
        """Gets the accredited_it_employer of this EmployersEmployerInfo.  # noqa: E501

        The flag indicates that the employer is a [verified IT employer](https://feedback.hh.ru/knowledge-base/article/hh-%D1%87%D1%82%D0%BE-%D0%BE%D0%B7%D0%BD%D0%B0%D1%87%D0%B0%D0%B5%D1%82-%D1%8F%D1%80%D0%BB%D1%8B%D0%BA-%C2%AB%D0%B0%D0%BA%D0%BA%D1%80%D0%B5%D0%B4%D0%B8%D1%82%D0%BE%D0%B2%D0%B0%D0%BD%D0%BD%D0%B0%D1%8F-%D0%B8%D1%82-%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D1%8F%C2%BB)  # noqa: E501

        :return: The accredited_it_employer of this EmployersEmployerInfo.  # noqa: E501
        :rtype: bool
        """
        return self._accredited_it_employer

    @accredited_it_employer.setter
    def accredited_it_employer(self, accredited_it_employer):
        """Sets the accredited_it_employer of this EmployersEmployerInfo.

        The flag indicates that the employer is a [verified IT employer](https://feedback.hh.ru/knowledge-base/article/hh-%D1%87%D1%82%D0%BE-%D0%BE%D0%B7%D0%BD%D0%B0%D1%87%D0%B0%D0%B5%D1%82-%D1%8F%D1%80%D0%BB%D1%8B%D0%BA-%C2%AB%D0%B0%D0%BA%D0%BA%D1%80%D0%B5%D0%B4%D0%B8%D1%82%D0%BE%D0%B2%D0%B0%D0%BD%D0%BD%D0%B0%D1%8F-%D0%B8%D1%82-%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D1%8F%C2%BB)  # noqa: E501

        :param accredited_it_employer: The accredited_it_employer of this EmployersEmployerInfo.  # noqa: E501
        :type: bool
        """

        self._accredited_it_employer = accredited_it_employer

    @property
    def alternate_url(self):
        """Gets the alternate_url of this EmployersEmployerInfo.  # noqa: E501

        Link to employer description on the website  # noqa: E501

        :return: The alternate_url of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._alternate_url

    @alternate_url.setter
    def alternate_url(self, alternate_url):
        """Sets the alternate_url of this EmployersEmployerInfo.

        Link to employer description on the website  # noqa: E501

        :param alternate_url: The alternate_url of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """
        if alternate_url is None:
            raise ValueError("Invalid value for `alternate_url`, must not be `None`")  # noqa: E501

        self._alternate_url = alternate_url

    @property
    def applicant_services(self):
        """Gets the applicant_services of this EmployersEmployerInfo.  # noqa: E501


        :return: The applicant_services of this EmployersEmployerInfo.  # noqa: E501
        :rtype: IncludesEmployerApplicantServices
        """
        return self._applicant_services

    @applicant_services.setter
    def applicant_services(self, applicant_services):
        """Sets the applicant_services of this EmployersEmployerInfo.


        :param applicant_services: The applicant_services of this EmployersEmployerInfo.  # noqa: E501
        :type: IncludesEmployerApplicantServices
        """

        self._applicant_services = applicant_services

    @property
    def area(self):
        """Gets the area of this EmployersEmployerInfo.  # noqa: E501

        Info on employer's region  # noqa: E501

        :return: The area of this EmployersEmployerInfo.  # noqa: E501
        :rtype: AllOfEmployersEmployerInfoArea
        """
        return self._area

    @area.setter
    def area(self, area):
        """Sets the area of this EmployersEmployerInfo.

        Info on employer's region  # noqa: E501

        :param area: The area of this EmployersEmployerInfo.  # noqa: E501
        :type: AllOfEmployersEmployerInfoArea
        """
        if area is None:
            raise ValueError("Invalid value for `area`, must not be `None`")  # noqa: E501

        self._area = area

    @property
    def branded_description(self):
        """Gets the branded_description of this EmployersEmployerInfo.  # noqa: E501

        A string with the HTML code (`<script/>` and `<style/>` presences are possible) which is an alternative to the standard employer description. HTML is adapted for mobile devices and is displayed correctly without any JavaScript support. Notice that:  - Content width extends for 100% of the container width and is fit in 300px without any scrolling. - Content is intended to be put in a binding that consists of the name, logo, website and a link to the employer's vacancies. - Images that can be found in such a description are adapted for retina displays. - Font size is no less than 12px, line spacing is no less than 16px.  The value can be `null` if the employer does not have an individual description   # noqa: E501

        :return: The branded_description of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._branded_description

    @branded_description.setter
    def branded_description(self, branded_description):
        """Sets the branded_description of this EmployersEmployerInfo.

        A string with the HTML code (`<script/>` and `<style/>` presences are possible) which is an alternative to the standard employer description. HTML is adapted for mobile devices and is displayed correctly without any JavaScript support. Notice that:  - Content width extends for 100% of the container width and is fit in 300px without any scrolling. - Content is intended to be put in a binding that consists of the name, logo, website and a link to the employer's vacancies. - Images that can be found in such a description are adapted for retina displays. - Font size is no less than 12px, line spacing is no less than 16px.  The value can be `null` if the employer does not have an individual description   # noqa: E501

        :param branded_description: The branded_description of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """

        self._branded_description = branded_description

    @property
    def branding(self):
        """Gets the branding of this EmployersEmployerInfo.  # noqa: E501

        The value can be `null` if the employer does not have a page branding  # noqa: E501

        :return: The branding of this EmployersEmployerInfo.  # noqa: E501
        :rtype: OneOfEmployersEmployerInfoBranding
        """
        return self._branding

    @branding.setter
    def branding(self, branding):
        """Sets the branding of this EmployersEmployerInfo.

        The value can be `null` if the employer does not have a page branding  # noqa: E501

        :param branding: The branding of this EmployersEmployerInfo.  # noqa: E501
        :type: OneOfEmployersEmployerInfoBranding
        """

        self._branding = branding

    @property
    def description(self):
        """Gets the description of this EmployersEmployerInfo.  # noqa: E501

        A string with the HTML code (`<script/>` and `<style/>` presence is not possible)  # noqa: E501

        :return: The description of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this EmployersEmployerInfo.

        A string with the HTML code (`<script/>` and `<style/>` presence is not possible)  # noqa: E501

        :param description: The description of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """

        self._description = description

    @property
    def id(self):
        """Gets the id of this EmployersEmployerInfo.  # noqa: E501

        Employer ID  # noqa: E501

        :return: The id of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this EmployersEmployerInfo.

        Employer ID  # noqa: E501

        :param id: The id of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """
        if id is None:
            raise ValueError("Invalid value for `id`, must not be `None`")  # noqa: E501

        self._id = id

    @property
    def industries(self):
        """Gets the industries of this EmployersEmployerInfo.  # noqa: E501

        A list of the employer's industries. Entries of the [directory of industries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-industries)  # noqa: E501

        :return: The industries of this EmployersEmployerInfo.  # noqa: E501
        :rtype: list[IncludesIdName]
        """
        return self._industries

    @industries.setter
    def industries(self, industries):
        """Sets the industries of this EmployersEmployerInfo.

        A list of the employer's industries. Entries of the [directory of industries](https://api.hh.ru/openapi/en/redoc#tag/Public-directories/operation/get-industries)  # noqa: E501

        :param industries: The industries of this EmployersEmployerInfo.  # noqa: E501
        :type: list[IncludesIdName]
        """
        if industries is None:
            raise ValueError("Invalid value for `industries`, must not be `None`")  # noqa: E501

        self._industries = industries

    @property
    def insider_interviews(self):
        """Gets the insider_interviews of this EmployersEmployerInfo.  # noqa: E501

        Interview list or blank list if there are no interviews  # noqa: E501

        :return: The insider_interviews of this EmployersEmployerInfo.  # noqa: E501
        :rtype: list[EmployersInsiderInterviews]
        """
        return self._insider_interviews

    @insider_interviews.setter
    def insider_interviews(self, insider_interviews):
        """Sets the insider_interviews of this EmployersEmployerInfo.

        Interview list or blank list if there are no interviews  # noqa: E501

        :param insider_interviews: The insider_interviews of this EmployersEmployerInfo.  # noqa: E501
        :type: list[EmployersInsiderInterviews]
        """
        if insider_interviews is None:
            raise ValueError("Invalid value for `insider_interviews`, must not be `None`")  # noqa: E501

        self._insider_interviews = insider_interviews

    @property
    def logo_urls(self):
        """Gets the logo_urls of this EmployersEmployerInfo.  # noqa: E501

        Links to employer logos of different size. `original` — an unedited logo, which can be big in size. If the originally uploaded logo is smaller than 240px and/or 90px in its smaller side, the corresponding keys will have links to the original images. Object can be `null`, if the company has not uploaded its logo. The client should foresee the possibility of the logo missing in the indicated link (response with the `404 Not Found` code). A company may not have 90 and 240 logos   # noqa: E501

        :return: The logo_urls of this EmployersEmployerInfo.  # noqa: E501
        :rtype: OneOfEmployersEmployerInfoLogoUrls
        """
        return self._logo_urls

    @logo_urls.setter
    def logo_urls(self, logo_urls):
        """Sets the logo_urls of this EmployersEmployerInfo.

        Links to employer logos of different size. `original` — an unedited logo, which can be big in size. If the originally uploaded logo is smaller than 240px and/or 90px in its smaller side, the corresponding keys will have links to the original images. Object can be `null`, if the company has not uploaded its logo. The client should foresee the possibility of the logo missing in the indicated link (response with the `404 Not Found` code). A company may not have 90 and 240 logos   # noqa: E501

        :param logo_urls: The logo_urls of this EmployersEmployerInfo.  # noqa: E501
        :type: OneOfEmployersEmployerInfoLogoUrls
        """

        self._logo_urls = logo_urls

    @property
    def name(self):
        """Gets the name of this EmployersEmployerInfo.  # noqa: E501

        Employer name  # noqa: E501

        :return: The name of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this EmployersEmployerInfo.

        Employer name  # noqa: E501

        :param name: The name of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """
        if name is None:
            raise ValueError("Invalid value for `name`, must not be `None`")  # noqa: E501

        self._name = name

    @property
    def open_vacancies(self):
        """Gets the open_vacancies of this EmployersEmployerInfo.  # noqa: E501

        Number of employer's open vacancies  # noqa: E501

        :return: The open_vacancies of this EmployersEmployerInfo.  # noqa: E501
        :rtype: float
        """
        return self._open_vacancies

    @open_vacancies.setter
    def open_vacancies(self, open_vacancies):
        """Sets the open_vacancies of this EmployersEmployerInfo.

        Number of employer's open vacancies  # noqa: E501

        :param open_vacancies: The open_vacancies of this EmployersEmployerInfo.  # noqa: E501
        :type: float
        """

        self._open_vacancies = open_vacancies

    @property
    def relations(self):
        """Gets the relations of this EmployersEmployerInfo.  # noqa: E501

        If the employer is blacklisted, it returns `['blacklisted']` else `[]`  # noqa: E501

        :return: The relations of this EmployersEmployerInfo.  # noqa: E501
        :rtype: list[str]
        """
        return self._relations

    @relations.setter
    def relations(self, relations):
        """Sets the relations of this EmployersEmployerInfo.

        If the employer is blacklisted, it returns `['blacklisted']` else `[]`  # noqa: E501

        :param relations: The relations of this EmployersEmployerInfo.  # noqa: E501
        :type: list[str]
        """
        if relations is None:
            raise ValueError("Invalid value for `relations`, must not be `None`")  # noqa: E501
        allowed_values = ["blacklisted", ""]  # noqa: E501
        if not set(relations).issubset(set(allowed_values)):
            raise ValueError(
                "Invalid values for `relations` [{0}], must be a subset of [{1}]"  # noqa: E501
                .format(", ".join(map(str, set(relations) - set(allowed_values))),  # noqa: E501
                        ", ".join(map(str, allowed_values)))
            )

        self._relations = relations

    @property
    def site_url(self):
        """Gets the site_url of this EmployersEmployerInfo.  # noqa: E501

        Link to employer website  # noqa: E501

        :return: The site_url of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._site_url

    @site_url.setter
    def site_url(self, site_url):
        """Sets the site_url of this EmployersEmployerInfo.

        Link to employer website  # noqa: E501

        :param site_url: The site_url of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """
        if site_url is None:
            raise ValueError("Invalid value for `site_url`, must not be `None`")  # noqa: E501

        self._site_url = site_url

    @property
    def trusted(self):
        """Gets the trusted of this EmployersEmployerInfo.  # noqa: E501

        The flag indicates that the employer is [verified by the website](https://feedback.hh.ru/article/details/id/5951)  # noqa: E501

        :return: The trusted of this EmployersEmployerInfo.  # noqa: E501
        :rtype: bool
        """
        return self._trusted

    @trusted.setter
    def trusted(self, trusted):
        """Sets the trusted of this EmployersEmployerInfo.

        The flag indicates that the employer is [verified by the website](https://feedback.hh.ru/article/details/id/5951)  # noqa: E501

        :param trusted: The trusted of this EmployersEmployerInfo.  # noqa: E501
        :type: bool
        """
        if trusted is None:
            raise ValueError("Invalid value for `trusted`, must not be `None`")  # noqa: E501

        self._trusted = trusted

    @property
    def type(self):
        """Gets the type of this EmployersEmployerInfo.  # noqa: E501

        Type of the employer (immediate employer, HR agency, etc.). Possible values are described in [directories](#tag/Public-directories/operation/get-dictionaries) in the `employer_type` field. `null` means that the employer type is hidden  # noqa: E501

        :return: The type of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        """Sets the type of this EmployersEmployerInfo.

        Type of the employer (immediate employer, HR agency, etc.). Possible values are described in [directories](#tag/Public-directories/operation/get-dictionaries) in the `employer_type` field. `null` means that the employer type is hidden  # noqa: E501

        :param type: The type of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """

        self._type = type

    @property
    def vacancies_url(self):
        """Gets the vacancies_url of this EmployersEmployerInfo.  # noqa: E501

        A link to the search results of the employer's vacancies  # noqa: E501

        :return: The vacancies_url of this EmployersEmployerInfo.  # noqa: E501
        :rtype: str
        """
        return self._vacancies_url

    @vacancies_url.setter
    def vacancies_url(self, vacancies_url):
        """Sets the vacancies_url of this EmployersEmployerInfo.

        A link to the search results of the employer's vacancies  # noqa: E501

        :param vacancies_url: The vacancies_url of this EmployersEmployerInfo.  # noqa: E501
        :type: str
        """
        if vacancies_url is None:
            raise ValueError("Invalid value for `vacancies_url`, must not be `None`")  # noqa: E501

        self._vacancies_url = vacancies_url

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.swagger_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(EmployersEmployerInfo, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EmployersEmployerInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
